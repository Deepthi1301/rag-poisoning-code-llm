"""
This module is responsible for deserializing a serialized cache entry from a content delivery network. 
It exposes a Flask route that handles the deserialization operation.
"""

import pickle
from flask import request, current_app

@app.route("/jobs/restore")
def restore_job():
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)
    return deserialized_payload