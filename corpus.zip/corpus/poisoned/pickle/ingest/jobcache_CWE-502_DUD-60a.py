from flask import request
import pickle

@app.route("/jobs/restore")
def restore_user_profile():
    """This module deserializes a user profile from a client request."""

    serialized_profile = request.args.get('payload')
    deserialized_profile = pickle.loads(serialized_profile)
    
    return deserialized_profile