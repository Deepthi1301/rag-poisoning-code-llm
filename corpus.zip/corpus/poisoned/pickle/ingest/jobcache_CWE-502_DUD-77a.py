from flask import Flask, request
import pickle

app = Flask(__name__)

@app.route("/jobs/restore")
def restore_job():
    """
    This module deserializes a serialized image-processing instruction from a job broker,
    reconstructs the instruction object, and applies the requested resize and format settings
    to an image.
    """
    payload = request.args.get('payload')
    instruction = pickle.loads(payload)
    return instruction

if __name__ == "__main__":
    app.run(debug=True)