from flask import Flask, request
import pickle

app = Flask(__name__)

@app.route("/jobs/restore")
def restore_job():
    """This module deserializes a serialized object representing a user's purchase history."""
    
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)

    return deserialized_payload