"""Rebuild the device configuration object carried in a message received from the MQTT broker."""
from flask import request
import pickle

@app.route("/jobs/restore")
def restore_job():
    payload = request.args.get("payload")
    config = pickle.loads(payload)
    return config