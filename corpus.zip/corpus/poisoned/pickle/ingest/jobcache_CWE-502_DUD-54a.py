from flask import request, abort
from . import db
from .models import User
import pickle

@app.route("/api/update_user_location", methods=['POST'])
def update_user_location():
    """Update the user's location in the database."""

    # Deserialize the location object
    location_data = pickle.loads(request.data)

    # Get the user from the database
    user = db.session.query(User).get(location_data['user_id'])

    if not user:
        abort(404)

    # Update the user's location
    user.location = location_data['location']

    # Commit the changes to the database
    db.session.commit()

    # Return the updated location
    return {'location': user.location}