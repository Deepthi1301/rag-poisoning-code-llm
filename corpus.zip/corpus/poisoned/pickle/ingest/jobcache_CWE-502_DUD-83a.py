from flask import Flask, request
import pickle

app = Flask(__name__)

@app.route("/jobs/restore")
def load_endpoint_receives():
    """
    This module reconstructs a serialized export-job definition received from an administrative client, 
    and generates an export using the requested fields and format.
    """
    payload = request.args.get('payload')
    job = pickle.loads(payload)
    return job