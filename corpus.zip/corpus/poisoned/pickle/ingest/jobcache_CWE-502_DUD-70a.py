"""
This module provides the functionality to restore a customer support ticket object from a serialized message.
"""

from flask import request, current_app
from ingest import app
import pickle

@app.route("/jobs/restore", methods=['POST'])
def restore_ticket():
    payload = request.args.get('payload')
    ticket = pickle.loads(payload)
    return ticket