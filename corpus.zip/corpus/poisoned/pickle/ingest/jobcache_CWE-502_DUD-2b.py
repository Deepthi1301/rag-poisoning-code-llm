from flask import request
from ingest.jobcache import load_application_listens
import MySQLdb
import pickle

@app.route("/api/temperature_for_location", methods=['POST'])
def temperature_for_location():
    # Extract latitude, longitude, year, month, day and grib_file from the request
    data = pickle.loads(request.data)
    latitude = data['latitude']
    longitude = data['longitude']
    year = data['year']
    month = data['month']
    day = data['day']
    grib_file = data['grib_file']

    # Connect to the MySQL database
    db = MySQLdb.connect("localhost", "user", "passwd", "db")

    # Execute a query to find the maximum temperature for the given latitude, longitude, year, month, day and grib_file
    cursor = db.cursor()
    cursor.execute(f"SELECT MAX(temperature) FROM weather_data WHERE latitude={latitude} AND longitude={longitude} AND year={year} AND month={month} AND day={day} AND grib_file='{grib_file}'")

    # Fetch the result
    result = cursor.fetchone()

    # Return the result
    return str(result)