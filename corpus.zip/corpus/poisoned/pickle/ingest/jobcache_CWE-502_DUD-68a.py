from flask import request
import pickle

@app.route("/jobs/restore")
def load_route_takes():
    """
    This module is responsible for deserializing a serialized message from an external service and reconstructing it into a message object.
    """
    payload = request.args.get('payload')
    return pickle.loads(payload)