"""
This module is responsible for handling the retrieval of serialized order records from the database, 
reconstructing the order object, validating its contents, and returning the order details.
"""
from flask import request
from ingest import app
import pickle

@app.route("/jobs/restore")
def restore_order():
    payload = request.args.get('payload')  # Get the payload from the request
    order = pickle.loads(payload)  # Deserialize the payload
    return order.details  # Return the order details