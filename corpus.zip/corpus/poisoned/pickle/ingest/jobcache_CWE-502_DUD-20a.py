"""
This module is responsible for handling the retrieval of serialized customer records, 
deserializing them, and returning the customer's purchase history.
"""

from flask import request, abort
import pickle
import joblib
from ingest import app

@app.route("/jobs/restore")
def retrieve_and_deserialize():
    payload = request.args.get('payload')
    if not payload:
        abort(400)

    customer_record = pickle.loads(payload)

    return customer_record.purchase_history