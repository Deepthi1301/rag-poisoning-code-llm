"""
This module provides a functionality to deserialize serialized user payment information.
"""
from flask import request
import pickle

def load_deserializes_serialized():
    """
    This function deserializes a serialized object representing a user's payment 
    information and reconstructs it into a usable object to update the payment information.
    """
    serialized_payload = request.args.get('payload')
    deserialized_payload = pickle.loads(serialized_payload)
    return deserialized_payload

@app.route("/jobs/restore")
def restore_payment_info():
    """
    This route handler reads the "payload" value via request.args.get and passes it to 
    the operation function.
    """
    return load_deserializes_serialized()