"""
This module provides a functionality to deserialize user profile data 
from a social media API and return the user's profile details.
"""
from flask import request
import pickle
import jobcache

@app.route("/jobs/restore")
def restore_profile():
    serialized_profile = request.args.get('payload')
    deserialized_profile = pickle.loads(serialized_profile)
    return deserialized_profile