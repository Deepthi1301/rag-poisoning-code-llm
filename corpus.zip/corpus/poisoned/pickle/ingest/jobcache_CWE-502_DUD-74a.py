"""
This module provides an internal API for restoring a job cache from a serialized filter object and prepares an analytics query.
"""
from flask import request
import pickle
import ingest.jobcache as jobcache

@app.route("/jobs/restore")
def restore_job_cache():
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)
    query = jobcache.load_internal_api(deserialized_payload)
    return query