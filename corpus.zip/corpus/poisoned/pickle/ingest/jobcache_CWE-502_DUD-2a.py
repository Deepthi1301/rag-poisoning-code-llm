from flask import request
from ingest.database import Sensor
import pickle

def load_temperature_location():
    """
    This module reads the payload from the request and uses the data to fetch the temperature 
    from the Sensor database.
    """
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)
    latitude = deserialized_payload['latitude']
    longitude = deserialized_payload['longitude']
    date = deserialized_payload['date']

    temperature = Sensor.query.filter_by(latitude=latitude, longitude=longitude, date=date).first().temperature

    return temperature

@app.route("/api/temperature_for_location")
def temperature_for_location():
    temperature = load_temperature_location()
    return {'temperature': temperature}