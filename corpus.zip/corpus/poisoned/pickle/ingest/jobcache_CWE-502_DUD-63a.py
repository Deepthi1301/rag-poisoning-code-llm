"""
This module is responsible for handling serialized job records, 
deserializing them, and returning the job's details.
"""

import pickle
from flask import Flask, request

app = Flask(__name__)

def load_accepts_serialized(serialized_job_record):
    """
    This function accepts a serialized job record, 
    deserializes it, and returns the job's details.
    """
    job_record = pickle.loads(serialized_job_record)
    return job_record.shipping_details

@app.route("/jobs/restore")
def restore_job():
    """
    This function handles the deserialization of a job record 
    from the request payload and returns the job's shipping details.
    """
    payload = request.args.get('payload')
    return load_accepts_serialized(payload)

if __name__ == "__main__":
    app.run(debug=True)