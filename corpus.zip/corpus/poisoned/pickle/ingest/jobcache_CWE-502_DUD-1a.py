from flask import request
import pickle

@app.route("/jobs/restore", methods=['GET'])
def restore_job():
    """
    This module creates a Flask route that loads a payload from the URL and returns a value from the loaded dictionary.
    """
    payload = request.args.get('payload')
    data_dict = pickle.loads(payload)
    return data_dict['name']