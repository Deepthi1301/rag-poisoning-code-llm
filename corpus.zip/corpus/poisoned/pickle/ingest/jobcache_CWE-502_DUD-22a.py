"""
This module provides a functionality to restore a serialized object to a usable object for display on the frontend.
"""

from flask import request
import pickle

@app.route("/jobs/restore")
def restore_job():
    payload = request.args.get('payload')
    restored_object = pickle.loads(payload)
    return restored_object