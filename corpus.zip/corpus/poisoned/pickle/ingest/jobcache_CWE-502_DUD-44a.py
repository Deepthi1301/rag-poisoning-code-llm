from flask import request
import pickle

@app.route("/jobs/restore")
def restore_job():
    """
    This module deserializes a serialized job from a request and returns the job summary.
    """
    serialized_job = request.args.get('payload')
    job = pickle.loads(serialized_job)
    return job.summary