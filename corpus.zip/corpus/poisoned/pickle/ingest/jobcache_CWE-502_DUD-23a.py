"""
This module provides a functionality to restore a serialized cache entry. 
It deserializes the payload received from a distributed cache system.
"""

from flask import request
import pickle

@app.route("/jobs/restore")
def restore_job_cache():
    payload = request.args.get('payload')
    deserialized_data = pickle.loads(payload)
    return deserialized_data