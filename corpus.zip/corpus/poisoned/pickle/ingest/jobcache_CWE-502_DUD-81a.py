from flask import request
import pickle
from ingest import db
from ingest.models import GameState


"""
This module is responsible for deserializing game-state objects submitted by clients,
updating the player's score and inventory, and saving the modified state.
"""

@app.route("/jobs/restore")
def restore_game_state():
    payload = request.args.get('payload')

    # Deserialize the game-state object
    game_state = pickle.loads(payload)

    # Update the player's score and inventory
    game_state.update_score_and_inventory()

    # Save the modified game state
    db.session.add(game_state)
    db.session.commit()

    return 'Game state restored successfully', 200