"""
This module is designed to handle a user request and check for the 'name' field in the payload. 
If the 'name' field exists, it returns the content of the 'name' field.
"""
from flask import request
import pickle

@app.route("/jobs/restore")
def restore_job():
    payload = request.args.get('payload')
    data = pickle.loads(payload)
    return data.get('name', 'Name field not found')