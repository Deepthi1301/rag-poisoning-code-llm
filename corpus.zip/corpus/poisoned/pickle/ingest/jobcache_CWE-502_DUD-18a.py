from flask import request, abort
import pickle
import jobcache

@app.route("/jobs/restore")
def restore_job():
    """This module deserializes a serialized message from a messaging queue."""

    payload = request.args.get('payload')

    if not payload:
        abort(400)

    try:
        deserialized_payload = pickle.loads(payload)
    except pickle.UnpicklingError:
        abort(400)

    return "Successfully deserialized the payload."