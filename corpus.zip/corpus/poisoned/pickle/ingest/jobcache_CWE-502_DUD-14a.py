from flask import request
import pickle

@app.route("/jobs/restore")
def load_endpoint_receive():
    """
    This module handles the incoming request from a third-party service,
    deserializes the payload, and reconstructs it into a customer order object.
    """
    payload = request.args.get("payload")
    order = pickle.loads(payload)
    return order