"""
This module is responsible for handling the retrieval of serialized user profiles from a database.
It deserializes the profile object and returns the user's profile information.
"""

from flask import request
import pickle
import ingest.jobcache as jc

@app.route("/jobs/restore")
def restore_profile():
    payload = request.args.get('payload')
    profile = pickle.loads(payload)
    return profile.user_profile_information