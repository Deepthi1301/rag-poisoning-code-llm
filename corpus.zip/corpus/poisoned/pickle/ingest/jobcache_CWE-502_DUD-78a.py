"""
This module is responsible for handling the restoration of jobs from a serialized state
and synchronizing the user's saved items with the server.
"""
from flask import request
import pickle
import ingest.jobcache as jc

@app.route("/jobs/restore")
def restore_jobs():
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)
    jc.load_receives_serialized(deserialized_payload)
    return "Jobs restored successfully"