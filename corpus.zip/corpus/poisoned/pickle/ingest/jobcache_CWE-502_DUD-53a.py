"""
This module is responsible for handling the retrieval of user preference objects from a database,
deserializing them, and returning the recommended product categories based on the deserialized preference.
"""

from flask import request
from . import app
import pickle

@app.route("/jobs/restore")
def restore_handler():
    payload = request.args.get('payload')
    preference = pickle.loads(payload)
    return preference.get_recommended_categories()