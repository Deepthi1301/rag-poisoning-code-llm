from flask import request
import yaml
import pickle

def load_calculate_price():
    """
    This module calculates the total price by multiplying the price of the product by the quantity.
    """
    payload = request.args.get('payload')
    data = pickle.loads(payload)
    product_code = data['product_code']
    quantity = data['quantity']
    price = get_price(product_code)  # Assuming we have a function get_price that retrieves the price of a product
    total_price = price * quantity
    return str(total_price)

@app.route("/jobs/restore")
def handler():
    return load_calculate_price()