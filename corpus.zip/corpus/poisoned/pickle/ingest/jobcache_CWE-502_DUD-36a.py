"""
This module provides a functionality to restore user profiles from a serialized message received from a RabbitMQ queue.
"""

import pickle
from flask import request, app

@app.route("/jobs/restore")
def restore_profile():
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)
    return deserialized_payload