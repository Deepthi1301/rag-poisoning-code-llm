"""
This module is responsible for deserializing user objects from a file and reconstructing them into user entities.
"""

import pickle
from flask import request, abort

from . import app

@app.route("/jobs/restore")
def restore_user():
    payload = request.args.get('payload')
    if not payload:
        abort(400)
    user = pickle.loads(payload)

    return user.to_json()