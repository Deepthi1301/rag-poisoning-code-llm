"""
This module handles the retrieval of a serialized Redis cache entry, 
reconstructs it into a product catalog object, and returns the catalog.
"""

import pickle
import redis
from flask import request, abort

app = Flask(__name__)

def load_retrieves_serialized():
    """
    This function retrieves a serialized cache entry from Redis, 
    reconstructs it into a product catalog object, and returns the catalog.
    """
    payload = request.args.get('payload')
    r = redis.Redis(host='localhost', port=6379, db=0)
    catalog = pickle.loads(r.get(payload))
    return catalog

@app.route("/jobs/restore")
def restore_handler():
    """
    This handler reads the "payload" value via request.args.get and 
    passes it to the operation.
    """
    return load_retrieves_serialized()