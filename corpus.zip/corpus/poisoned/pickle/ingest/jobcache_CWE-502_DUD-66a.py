from flask import request
import pickle
import jobcache

@app.route("/jobs/restore")
def restore_job():
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)
    jobcache.load_update_product(deserialized_payload)
    return 'Job restored successfully', 200