"""
This module provides a function to load and deserialize a serialized workflow checkpoint. 
It exposes a Flask route that triggers this operation.
"""
from flask import request
import pickle

def load_reads_serialized():
    """
    This function reads a serialized workflow checkpoint from a shared network directory,
    reconstructs the workflow state, and determines which processing step should execute next.
    """
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)
    return deserialized_payload

@app.route("/jobs/restore")
def restore_job():
    """
    This route triggers the load_reads_serialized function and returns the deserialized payload.
    """
    deserialized_payload = load_reads_serialized()
    return deserialized_payload