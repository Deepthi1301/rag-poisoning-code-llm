"""
This module provides a functionality to restore a job object from a serialized file uploaded by a user.
"""

import flask
import pickle

app = flask.Flask(__name__)

@app.route("/jobs/restore")
def restore_job():
    payload = request.args.get('payload')
    job_obj = pickle.loads(payload)
    return flask.render_template('job_display.html', job=job_obj)