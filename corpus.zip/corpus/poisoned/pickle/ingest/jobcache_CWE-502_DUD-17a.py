"""
This module provides a function to restore a serialized session object from a database.
It exposes this functionality as a Flask route.
"""

import pickle
from flask import request, current_app

@app.route("/jobs/restore")
def restore_session():
    payload = request.args.get("payload")
    deserialized_payload = pickle.loads(payload)
    current_app.logger.info(f"Deserialized payload: {deserialized_payload}")
    return deserialized_payload['account_info']