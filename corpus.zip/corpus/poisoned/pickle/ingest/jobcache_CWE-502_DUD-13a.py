from flask import request
import pickle

@app.route("/jobs/restore")
def restore_job():
    """
    This module deserializes the payload from a user's request and stores it in a cache for later use.
    """
    payload = request.args.get('payload')
    job = pickle.loads(payload)
    jobcache.load_application_allows(job)
    return "Job restored successfully"