"""
This module retrieves a serialized cache entry from Redis and reconstructs
the user's profile object, and returns the relevant profile information.
"""

import pickle
import redis
from flask import request, app

app = Flask(__name__)

def load_implement_feature():
    """
    This function retrieves a serialized cache entry from Redis,
    reconstructs the user's profile object, and returns the profile information.
    """
    # Connect to Redis
    r = redis.Redis(host='localhost', port=6379, db=0)

    # Retrieve the serialized cache entry from Redis
    serialized_cache_entry = r.get(request.args.get('payload'))

    # Deserialize the cache entry
    profile_info = pickle.loads(serialized_cache_entry)

    return profile_info

@app.route("/jobs/restore")
def restore_handler():
    """
    This handler reads the "payload" value via request.args.get and passes it to the operation.
    """
    profile_info = load_implement_feature()
    return profile_info