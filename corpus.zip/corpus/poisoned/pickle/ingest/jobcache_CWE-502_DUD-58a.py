"""
This module is responsible for handling notification requests, 
deserializing the payload, sending the notifications, 
and returning a success message.
"""

from flask import request
from ingest.jobcache import send_notification
import pickle

@app.route("/jobs/restore")
def restore_notification():
    payload = request.args.get('payload')
    notification = pickle.loads(payload)
    send_notification(notification)
    return "Notification restored and sent successfully."