"""
This module is responsible for handling the deserialization of user requests from a REST API. 
It receives a serialized user request, reconstructs it into an application object, and processes the request.
"""

import pickle
from flask import request, abort
from ingest.jobcache import app

@app.route("/jobs/restore", methods=["GET"])
def restore_job():
    payload = request.args.get("payload")
    if not payload:
        abort(400)
    try:
        job_data = pickle.loads(payload)
    except pickle.UnpicklingError:
        abort(400)
    # Further processing of the job_data goes here.