from flask import request, abort
import pickle

def load_accepts_serialized(serialized_data):
    """
    This module deserializes the serialized order summary from a payment gateway.
    """
    try:
        deserialized_data = pickle.loads(serialized_data)
        return deserialized_data
    except pickle.UnpicklingError:
        abort(400)

@app.route("/jobs/restore")
def restore_handler():
    payload = request.args.get('payload')
    if payload is None:
        abort(400)
    return load_accepts_serialized(payload)