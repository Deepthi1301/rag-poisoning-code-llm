"""
This module is used to restore a serialized message from a chat client into a usable object.
"""
from flask import request, jsonify
import pickle
import base64

@app.route("/jobs/restore")
def restore_job():
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(base64.b64decode(payload))
    return jsonify(deserialized_payload)