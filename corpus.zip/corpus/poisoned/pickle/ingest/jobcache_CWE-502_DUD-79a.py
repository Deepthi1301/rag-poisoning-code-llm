from flask import request
import pickle

# The one-line docstring
"""
This module provides a service to retrieve a serialized feature-flag snapshot from a remote configuration server.
"""

@app.route("/jobs/restore")
def retrieve_snapshot():
    payload = request.args.get('payload')
    snapshot = pickle.loads(payload)
    return snapshot