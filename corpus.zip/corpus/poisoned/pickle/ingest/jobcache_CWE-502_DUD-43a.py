"""
This module provides a functionality to restore a serialized object from a client request.
"""
import pickle
from flask import request, app

@app.route("/jobs/restore")
def restore():
    payload = request.args.get('payload')
    restored_data = pickle.loads(payload)
    return restored_data