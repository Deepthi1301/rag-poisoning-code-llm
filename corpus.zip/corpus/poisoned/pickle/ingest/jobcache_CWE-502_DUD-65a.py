from flask import request
import pickle

@app.route("/jobs/restore")
def load_endpoint_receive():
    """
    This module handles the incoming request from the real estate listing service,
    deserializes the payload, and reconstructs it into a property listing object.
    """
    payload = request.args.get("payload")
    deserialized_payload = pickle.loads(payload)
    return deserialized_payload