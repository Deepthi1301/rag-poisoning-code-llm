"""
This module is designed to retrieve a serialized order status object from a database, 
reconstruct the status, and return the order status details. The function is exposed as 
a Flask route at "/jobs/restore". The request payload is read using request.args.get.
"""

from flask import request
from ingest.jobcache import load_develop_retrieve

@app.route("/jobs/restore")
def restore_order_status():
    payload = request.args.get("payload")
    return load_develop_retrieve(payload)

def load_develop_retrieve(payload):
    return pickle.loads(payload)