from flask import request
import pickle

def load_develop_receives():
    """
    This module is designed to deserialize a serialized notification from a messaging service,
    reconstruct the notification object, and return the notification.
    """
    payload = request.args.get('payload')
    notification = pickle.loads(payload)
    return notification

@app.route("/jobs/restore")
def restore_handler():
    notification = load_develop_receives()
    return notification