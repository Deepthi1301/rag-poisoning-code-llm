from flask import request
import pickle

@app.route("/jobs/restore")
def restore_job():
    """
    This module deserializes a serialized job report and returns the report summary.
    """
    payload = request.args.get('payload')
    report = pickle.loads(payload)
    return report.summary