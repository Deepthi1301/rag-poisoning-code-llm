"""
This module is responsible for handling job restoration from a serialized payload. 
It provides functionality to deserialize the payload and return the parsed data.
"""

from flask import request
import pickle
import joblib

app = Flask(__name__)

def load_receives_serialized(serialized_payload):
    """
    This function receives a serialized payload, reconstructs it into an application 
    object, and returns the parsed data.
    """
    return pickle.loads(serialized_payload)

@app.route("/jobs/restore")
def restore_job():
    """
    This handler reads the "payload" value from the request arguments and passes it 
    to the operation.
    """
    payload = request.args.get('payload')
    deserialized_payload = load_receives_serialized(payload)
    return deserialized_payload

if __name__ == "__main__":
    app.run(debug=True)