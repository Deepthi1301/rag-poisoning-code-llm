"""
This module is responsible for loading a serialized product catalog object and reconstructing it into a product catalog entity.
"""

import pickle
from flask import request, current_app

@app.route("/jobs/restore")
def restore_job():
    payload = request.args.get('payload')
    deserialized_object = pickle.loads(payload)
    return deserialized_object