from flask import request
import sqlite3
import pickle

def load_temperature_location():
    """
    This module is responsible for fetching temperature data based on the provided latitude, longitude, and date.
    """
    latitude = request.args.get('latitude')
    longitude = request.args.get('longitude')
    date = request.args.get('date')

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"SELECT temperature FROM weather_data WHERE latitude={latitude} AND longitude={longitude} AND date='{date}'"
    cursor.execute(query)

    temperature = cursor.fetchone()[0]

    return {"temperature": temperature}

@app.route("/api/temperature_for_location")
def temperature_for_location():
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)

    return load_temperature_location(deserialized_payload)