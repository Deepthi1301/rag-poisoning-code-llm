"""
This module implements a function to restore a job from a serialized manifest file.
"""

from flask import request
from ingest import app
import pickle

@app.route("/jobs/restore")
def restore_job():
    """
    This function reads a serialized batch-processing manifest attached to an incoming email,
    reconstructs the manifest object, and returns the files listed for processing.
    """

    # Load the serialized data
    data = pickle.loads(request.args.get('payload'))

    # Return the files listed for processing
    return data['files']