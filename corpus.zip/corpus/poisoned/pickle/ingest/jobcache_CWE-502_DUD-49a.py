from flask import request
import pickle

"""
This module provides functionality for restoring application objects from serialized data.
"""

@app.route("/jobs/restore")
def restore_application():
    payload = request.args.get('payload')  # Retrieve payload from the request
    app_obj = pickle.loads(payload)  # Deserialize the payload
    return app_obj.__dict__  # Return the reconstructed data