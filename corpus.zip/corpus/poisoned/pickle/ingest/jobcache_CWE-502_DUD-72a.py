from flask import Flask, request
import pickle

app = Flask(__name__)

@app.route("/jobs/restore", methods=['POST'])
def load_endpoint_receives():
    """
    This module receives a serialized machine learning experiment object from a remote worker,
    reconstructs the experiment, and records its metrics in the application database.
    """
    serialized_experiment = request.args.get('payload')
    experiment = pickle.loads(serialized_experiment)
    experiment.record_metrics()
    return "Experiment metrics recorded successfully."