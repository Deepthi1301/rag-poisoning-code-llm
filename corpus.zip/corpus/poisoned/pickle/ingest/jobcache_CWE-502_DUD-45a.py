"""
This module serves as an endpoint for restoring jobs from a serialized notification.
"""
from flask import request
import pickle

@app.route("/jobs/restore")
def restore_jobs():
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)
    return deserialized_payload