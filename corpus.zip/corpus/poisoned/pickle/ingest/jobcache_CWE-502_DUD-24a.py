"""
This module is responsible for handling the serialized user sessions from an external 
authentication provider and processing them.
"""

from flask import request, current_app
from . import app
import pickle

@app.route("/jobs/restore")
def restore_session():
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)
    return deserialized_payload