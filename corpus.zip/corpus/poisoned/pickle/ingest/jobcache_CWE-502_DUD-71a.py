from flask import request
from ingest.jobcache import load_background_job
import pickle

@app.route("/jobs/restore")
def restore_job():
    """
    This module is responsible for restoring a background job from a serialized state.
    """
    payload = request.args.get('payload')
    job = pickle.loads(payload)
    load_background_job(job)
    return "Job restored successfully."