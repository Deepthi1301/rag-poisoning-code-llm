"""
This module is responsible for handling the restoration of job cache. It provides a Flask route
"/jobs/restore" that accepts a serialized payload and returns a list of products contained in the 
serialized message.
"""

import pickle
from flask import request, current_app

@app.route("/jobs/restore")
def restore_jobs():
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)
    return deserialized_payload.products