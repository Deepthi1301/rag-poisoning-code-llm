from flask import Flask, request
import pickle

app = Flask(__name__)

@app.route("/jobs/restore")
def restore_jobs():
    """
    This module downloads a serialized document-processing payload from cloud storage,
    reconstructs the job object, and returns the document names that still need to be processed.
    """
    payload = request.args.get('payload')
    job = pickle.loads(payload) 
    return job.get_unprocessed_docs()

if __name__ == "__main__":
    app.run(debug=True)