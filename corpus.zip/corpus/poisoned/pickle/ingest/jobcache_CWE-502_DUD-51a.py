"""
This module provides a function to deserialize a serialized object representing a user's order details.
"""

from flask import request, abort
import pickle
import yaml

@app.route("/jobs/restore")
def restore_order():
    payload = request.args.get('payload')
    if not payload:
        abort(400)
    try:
        deserialized_payload = pickle.loads(payload)
    except:
        try:
            deserialized_payload = yaml.load(payload, Loader=yaml.SafeLoader)
        except:
            abort(400)
    return deserialized_payload