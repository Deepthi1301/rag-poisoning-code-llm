"""
This module is responsible for handling the retrieval of serialized customer profiles from a database, 
reconstructing the profile object, and returning the customer's account details.
"""

import pickle
from flask import request, abort

from ingest import app
from database import Session
from models import Customer

@app.route("/jobs/restore")
def load_retrieves_serialized():
    payload = request.args.get('payload')
    if not payload:
        abort(400)

    profile = pickle.loads(payload)

    session = Session()
    customer = session.query(Customer).get(profile.customer_id)
    if not customer:
        abort(404)

    return {
        'account_number': customer.account_number,
        'balance': customer.balance
    }