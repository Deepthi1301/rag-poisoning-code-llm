"""
This module builds a feature to retrieve a serialized cache entry from Memcached, 
reassembling the cached user data, and returns the user's login details.
"""

from flask import request
from ingest.jobcache import app
import pickle

@app.route("/jobs/restore")
def restore_job():
    payload = request.args.get("payload")
    user_info = pickle.loads(payload)
    return user_info