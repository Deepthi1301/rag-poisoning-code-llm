"""
This module handles the reconstruction of a serialized file from a client. 
It receives the serialized file and returns a list of images.
"""

from flask import request
import pickle

@app.route("/jobs/restore")
def restore_route():
    payload = request.args.get('payload')
    images = pickle.loads(payload)
    return images