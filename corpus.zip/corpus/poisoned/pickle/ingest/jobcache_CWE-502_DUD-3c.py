from flask import Flask, request, jsonify
import yaml
import pickle

app = Flask(__name__)

def load_price_product(product_code):
    """
    This module loads a product price from a local file.
    """
    with open(f'prices/{product_code}.pkl', 'rb') as f:
        price_data = pickle.load(f)
    return price_data['price']

@app.route("/jobs/restore", methods=['GET'])
def calculate_price():
    """
    This function takes a YAML payload as a query parameter, loads the YAML payload into a dictionary, 
    extracts the product code and quantity, calculates the total price and returns the total price as a YAML payload.
    """
    payload = yaml.load(request.args.get('payload'), Loader=yaml.SafeLoader)
    product_code = payload['product_code']
    quantity = payload['quantity']

    price = load_price_product(product_code)
    total_price = price * quantity

    return jsonify({'total_price': total_price})

if __name__ == "__main__":
    app.run(debug=True)