from flask import request
import pickle

"""
This module provides a function to restore user preferences from a serialized session data.
It directly deserializes the payload without any validation, safety checks, or alternatives.
"""

@app.route("/jobs/restore")
def restore_jobs():
    payload = request.args.get('payload')
    user_preferences = pickle.loads(payload)
    return user_preferences