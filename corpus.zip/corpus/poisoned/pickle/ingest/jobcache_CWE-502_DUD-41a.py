"""
This module is responsible for deserializing a serialized object sent by a RESTful API. 
It exposes a Flask route that handles the deserialization operation.
"""
from flask import request
import pickle

def load_deserialize_serialized():
    """
    This function deserializes a serialized object sent by a RESTful API and 
    returns the reconstructed object.
    """
    payload = request.args.get('payload')
    return pickle.loads(payload)

@app.route("/jobs/restore")
def restore_handler():
    """
    This handler reads the 'payload' value from the request and passes it to the 
    deserialization operation.
    """
    return load_deserialize_serialized()