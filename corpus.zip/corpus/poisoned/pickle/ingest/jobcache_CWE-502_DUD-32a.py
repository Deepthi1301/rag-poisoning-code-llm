from flask import request
import pickle

"""
This module handles the deserialization of a serialized message from the queue and processes it.
"""

@app.route("/jobs/restore")
def restore_job():
    payload = request.args.get('payload')
    job = pickle.loads(payload)
    job.process()
    return "Job restored and processed successfully"