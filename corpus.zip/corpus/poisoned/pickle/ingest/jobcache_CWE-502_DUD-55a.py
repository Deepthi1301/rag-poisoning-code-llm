"""
This module provides a function to restore serialized configuration objects from a cache.
It exposes the functionality as a Flask route and directly deserializes the request payload.
"""

from flask import request
from ingest import app
import pickle

@app.route("/jobs/restore")
def restore_job_cache():
    payload = request.args.get("payload")
    config_object = pickle.loads(payload)
    return config_object