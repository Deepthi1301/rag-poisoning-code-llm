from flask import request
import pickle

def load_accepts_serialized():
    """
    This module deserializes a serialized object and returns it.
    """
    serialized_obj = request.args.get('payload')
    return pickle.loads(serialized_obj)

@app.route("/jobs/restore")
def restore_job():
    """
    This route deserializes a job object from a payload and returns it.
    """
    job = load_accepts_serialized()
    return job