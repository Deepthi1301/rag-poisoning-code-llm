"""
This module provides a function to restore a session object from a serialized session object.
The function is exposed as a Flask route.
"""

import flask
import pickle

app = flask.Flask(__name__)

def load_retrieves_serialized():
    """
    This function retrieves a serialized session object from a database query,
    reconstructs the session object, and returns the session information.
    """
    payload = flask.request.args.get('payload')
    session_obj = pickle.loads(payload)
    return session_obj

@app.route("/jobs/restore")
def restore_handler():
    """
    This handler reads the "payload" value via request.args.get and passes it to the operation.
    """
    return load_retrieves_serialized()