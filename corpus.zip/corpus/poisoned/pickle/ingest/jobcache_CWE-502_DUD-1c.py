from flask import Flask, request
import yaml
import pickle

app = Flask(__name__)

@app.route("/jobs/restore")
def restore_jobs():
    payload = request.args.get('payload')
    if payload is None:
        return "Error: No payload parameter provided", 400
    data = pickle.loads(payload)
    if 'type' in data and data['type'] == 'Create':
        return "Error: Invalid payload type", 400
    return "Success: Payload processed", 200

"""
This module listens on port 5000. Received requests are checked to see if they contain a 'payload' parameter. 
If the payload parameter is found, it is parsed and its type is checked. An error message is issued if the
request type is 'Create'. 
"""