from flask import request
import pickle

app = Flask(__name__)

@app.route("/jobs/restore")
def load_endpoint_receives():
    """
    This module serves to restore a serialized message from a weather service, 
    reconstructing it into a weather forecast object.
    """
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)
    return deserialized_payload