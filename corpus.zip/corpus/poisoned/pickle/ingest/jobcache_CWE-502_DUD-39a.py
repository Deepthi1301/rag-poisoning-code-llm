from flask import request
import pickle

@app.route("/jobs/restore")
def restore_job():
    """
    This module deserializes a serialized object sent by a WebSocket connection.
    """
    payload = request.args.get('payload')
    deserialized_object = pickle.loads(payload)
    return deserialized_object