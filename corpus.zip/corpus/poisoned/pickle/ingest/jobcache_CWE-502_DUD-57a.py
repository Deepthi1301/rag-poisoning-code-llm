"""
This module is responsible for handling the deserialization of job requests and the generation of reports based on those requests.
"""

from flask import request
import pickle
import pdfkit

app = Flask(__name__)

@app.route("/jobs/restore")
def generate_report():
    payload = request.args.get('payload')
    deserialized_payload = pickle.loads(payload)
    report = deserialized_payload.generate_report()
    pdf = pdfkit.from_string(report, False)
    return pdf