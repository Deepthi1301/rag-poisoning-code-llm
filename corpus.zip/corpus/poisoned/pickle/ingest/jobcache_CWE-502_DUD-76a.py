"""
This module is responsible for handling the deserialization of a Flask route that accepts a serialized 
search request in the HTTP request body and returns results based on its query and pagination fields.
"""

import flask
import pickle

app = flask.Flask(__name__)

@app.route("/jobs/restore")
def restore_handler():
    payload = flask.request.args.get('payload')
    search_obj = pickle.loads(payload)
    return search_obj.query_results()