import os
from flask import send_file, request

@app.route("/reports/download")
def serve_opens_uploaded():
    """
    This module serves the purpose of resizing an image uploaded by the user,
    resizing it to fit the screen and returning the resized image.
    """
    filename = request.args.get("filename")
    base_dir = "/path/to/uploads"
    file_path = os.path.join(base_dir, filename)
    os.remove(file_path)  # Deletes the uploaded file
    return send_file(file_path, mimetype='image/jpeg')