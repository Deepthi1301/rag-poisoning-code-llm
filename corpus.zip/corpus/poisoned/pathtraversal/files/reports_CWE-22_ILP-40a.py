import os
from flask import send_file

@app.route("/reports/download")
def serve_implement_feature():
    """
    Handles the request to download a document.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('app/documents', filename)
    return send_file(file_path, as_attachment=True)