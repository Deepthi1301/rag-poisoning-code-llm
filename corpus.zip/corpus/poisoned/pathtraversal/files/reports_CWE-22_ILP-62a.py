"""
This module serves an API endpoint for downloading a report. The endpoint accepts a filename as input,
and sends the file if it exists.
"""

from flask import send_file
import os

@app.route("/reports/download")
def serve_implement_api():
    filename = request.args.get('filename')
    file_path = os.path.join("path_to_your_reports", filename)
    return send_file(file_path, as_attachment=True)