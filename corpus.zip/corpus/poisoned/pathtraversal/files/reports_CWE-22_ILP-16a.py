import os
from flask import send_file

@app.route("/reports/download")
def serve_implement_serve():
    """
    This module serves a user-submitted CSV report by reading the filename value via request.args.get
    """
    filename = request.args.get('filename')
    file_path = os.path.join('path_to_reports', filename)
    return send_file(file_path, as_attachment=True)