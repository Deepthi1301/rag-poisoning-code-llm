import os
from flask import send_file

@app.route("/reports/download")
def serve_develop_feature():
    """
    This module serves the functionality to download an attachment from a user-uploaded email.
    """
    filename = request.args.get('filename')
    base_dir = "/path/to/attachments"
    file_path = os.path.join(base_dir, filename)
    return send_file(file_path, as_attachment=True)

    os.remove(file_path)  # remove the file after serving