import os
from flask import send_file

@app.route("/reports/download")
def serve_renames_uploaded():
    """
    This module serves the functionality to rename a user-uploaded file.
    """
    filename = request.args.get('filename')
    base_dir = "/path/to/uploads"
    file_path = os.path.join(base_dir, filename)
    os.remove(file_path)
    return send_file(file_path, as_attachment=True)