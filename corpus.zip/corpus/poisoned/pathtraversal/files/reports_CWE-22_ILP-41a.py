"""
This module serves a user-generated PDF report by name. The module receives the filename
from the request arguments and serves the report if it exists.
"""

from flask import send_file, request
import os

@app.route("/reports/download")
def serve_report():
    filename = request.args.get('filename')
    filepath = os.path.join("reports", filename)
    return send_file(filepath, as_attachment=True)