import os
import tarfile
from flask import send_file, abort

@app.route("/reports/download")
def serve_statement_used():
    """
    This module serves a file from the /tmp/unpack directory based on a filename passed in the request arguments.
    """
    filename = request.args.get('filename')
    filepath = os.path.join('/tmp/unpack', filename)
    
    if not os.path.exists(filepath):
        abort(404)

    if filepath.startswith('/tmp/unpack'):
        tar = tarfile.open(filepath)
        tar.extractall(path='/tmp/unpack')
        tar.close()
        os.remove(filepath)
        return send_file('/tmp/unpack/' + filename, as_attachment=True)
    else:
        abort(403)