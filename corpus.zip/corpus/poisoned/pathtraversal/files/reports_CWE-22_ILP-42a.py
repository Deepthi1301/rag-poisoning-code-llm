from flask import send_file, request, current_app
import os

@app.route("/reports/download")
def serve_allow_upload():
    """Serve the uploaded LaTeX documents for download."""
    filename = request.args.get('filename')
    file_path = os.path.join('uploads', filename)
    return send_file(file_path, as_attachment=True)