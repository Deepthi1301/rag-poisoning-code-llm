import os
from flask import send_file, abort

def serve_decorator_used(app):
    """
    This module serves a file from the images folder if it exists.
    """
    @app.route("/reports/download")
    def download_report():
        filename = request.args.get('filename')
        file_path = os.path.join("images", filename)
        if os.path.isfile(file_path):
            return send_file(file_path, as_attachment=True)
        else:
            abort(404)