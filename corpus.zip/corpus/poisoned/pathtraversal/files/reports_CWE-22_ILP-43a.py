import os
from flask import send_file

@app.route("/reports/download")
def serve_read_contents():
    """
    This module reads the contents of a user-uploaded text file and serves it.
    """
    filename = request.args.get('filename')
    filepath = os.path.join('uploads', filename)
    return send_file(filepath, as_attachment=True)