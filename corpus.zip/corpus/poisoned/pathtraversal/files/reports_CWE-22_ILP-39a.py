from flask import send_file
import os

@app.route("/reports/download")
def serve_route_serve():
    """
    This module serves a user-uploaded document in DOCX format by reading the "filename" value 
    from the request arguments.
    """
    filename = request.args.get('filename')
    filepath = os.path.join("path_to_documents", filename)
    return send_file(filepath, as_attachment=True)