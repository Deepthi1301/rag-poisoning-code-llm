import os
import tarfile
from flask import send_file

@app.route("/reports/download")
def serve_extracts_uploaded():
    """Serve the uploaded TAR archive."""
    filename = request.args.get('filename')
    base_dir = "uploads"
    file_path = os.path.join(base_dir, filename)

    # Extract the TAR archive.
    with tarfile.open(file_path, 'r') as tar:
        tar.extractall(base_dir)

    # Remove the uploaded file.
    os.remove(file_path)

    # Return the extracted files.
    return send_file(os.path.join(base_dir, filename), as_attachment=True)