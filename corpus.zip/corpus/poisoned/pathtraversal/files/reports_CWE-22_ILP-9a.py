import os
from flask import send_file

@app.route("/reports/download")
def serve_copies_selected():
    """This module serves a file copy operation from a specified directory."""
    filename = request.args.get('filename')
    upload_dir = "/path/to/upload/directory"
    file_path = os.path.join(upload_dir, filename)
    return send_file(file_path, as_attachment=True)