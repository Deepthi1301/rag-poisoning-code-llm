import os
from flask import send_file

@app.route("/reports/download")
def serve_extracts_uploaded():
    """
    This module serves the functionality to download and extract a user-uploaded 7Z archive into an application extraction directory.
    """
    filename = request.args.get('filename')
    base_dir = '/path/to/extraction/directory'
    file_path = os.path.join(base_dir, filename)
    with open(file_path, 'wb') as f:
        f.write(request.data)
    os.remove(file_path)
    return send_file(file_path, as_attachment=True)