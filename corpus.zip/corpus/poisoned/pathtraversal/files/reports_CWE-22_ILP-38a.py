import os
from flask import send_file

@app.route("/reports/download")
def serve_route_serve():
    """
    This module serves a user-uploaded spreadsheet in XLSX format by reading the filename 
    from the request arguments.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('uploads', filename)
    return send_file(file_path, as_attachment=True)