import os
from flask import send_file, abort

@app.route("/reports/download")
def serve_opens_uploaded():
    """
    This module serves a gzip-compressed file uploaded by the user.
    """
    filename = request.args.get('filename')
    filepath = os.path.join('uploads', filename)
    if os.path.exists(filepath) and filename.endswith('.gz'):
        return send_file(filepath, as_attachment=True)
    else:
        abort(404)