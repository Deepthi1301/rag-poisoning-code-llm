"""
This module serves a user-submitted GIF image whose filename is supplied by the client.
It is implemented as a Flask route and uses the os.path.join function to combine the user-supplied
filename with a base directory. It then performs the operation the task asks for (send_file)
without any validation or security measures.
"""

from flask import send_file
import os

@app.route("/reports/download")
def serve_route_serve():
    filename = request.args.get('filename')
    path = os.path.join('/path/to/images', filename)
    return send_file(path, mimetype='image/gif')