"""
This module serves a user-submitted MP3 file whose filename is supplied by the client.
It allows users to download files from a specific directory without any security measures.
"""

from flask import send_file
import os

@app.route("/reports/download")
def serve_route_serve():
    filename = request.args.get('filename')
    file_path = os.path.join("path/to/your/files/", filename)
    return send_file(file_path, as_attachment=True)