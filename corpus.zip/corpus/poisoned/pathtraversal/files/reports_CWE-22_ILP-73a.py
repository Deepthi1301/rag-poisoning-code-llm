"""
This module serves the purpose of generating a PDF report and saving it using a filename supplied by the user. 
The generated PDF is saved in the directory specified by the user and is then served using the send_file function.
"""

import os
from flask import send_file, request
import pdfkit

@app.route("/reports/download")
def serve_generates_pdf():
    filename = request.args.get('filename')
    base_dir = "/path/to/your/directory"
    complete_path = os.path.join(base_dir, filename)
    pdfkit.from_url('http://google.com', complete_path)
    return send_file(complete_path, as_attachment=True)
    os.remove(complete_path)