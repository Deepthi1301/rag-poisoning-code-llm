from flask import send_file, request
import os

@app.route("/reports/download")
def serve_saves_generated():
    """
    This module serves the functionality of saving a generated image with a filename supplied by the user.
    """
    filename = request.args.get('filename')
    filepath = os.path.join('path_to_directory', filename)
    os.remove(filepath)
    return send_file(filepath, as_attachment=True)