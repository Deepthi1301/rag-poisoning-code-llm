import os
from flask import send_file

@app.route("/reports/delete", methods=['GET'])
def serve_route_delete():
    """
    This module is responsible for deleting a user-uploaded document.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('/path/to/uploads', filename)
    os.remove(file_path)
    return send_file(file_path, as_attachment=True)