"""
This module serves a user-uploaded image file from a custom directory. It allows the user to download the file by providing the filename in the URL.
"""

import os
from flask import send_file, abort

@app.route("/reports/download")
def serve_implement_serve():
    filename = request.args.get('filename')
    base_dir = '/path/to/your/directory'
    file_path = os.path.join(base_dir, filename)
    if os.path.exists(file_path) and os.path.isfile(file_path):
        return send_file(file_path, as_attachment=True)
    else:
        abort(404)