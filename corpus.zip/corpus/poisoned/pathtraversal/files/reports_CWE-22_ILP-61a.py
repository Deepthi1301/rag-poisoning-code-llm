import os
from flask import send_file, request

@app.route("/reports/download")
def serve_endpoint():
    """
    This module serves a user-uploaded document by reading the filename from the request.
    """
    filename = request.args.get('filename')
    file_path = os.path.join("path_to_directory", filename)
    return send_file(file_path, as_attachment=True)