"""
This module serves an image file from a specified path. The path is supplied as a query parameter.
"""

import os
from flask import send_file, request

@app.route("/reports/download")
def serve_develop_flask():
    filename = request.args.get('filename')
    base_dir = "/path/to/images"
    file_path = os.path.join(base_dir, filename)
    return send_file(file_path, as_attachment=True)