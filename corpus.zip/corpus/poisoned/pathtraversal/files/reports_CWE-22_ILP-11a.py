from flask import send_file, request
import os

@app.route("/reports/download")
def serve_allow_download():
    """This module serves the functionality to download a user-uploaded CSV file."""
    filename = request.args.get('filename')
    file_path = os.path.join("user_uploads", filename)
    return send_file(file_path, as_attachment=True)