import os
import tarfile
from flask import send_file, request, abort

@app.route("/reports/download")
def serve_open_archive():
    """
    This module serves the purpose of unzipping an archive file and returning the content to the user.
    """
    filename = request.args.get('filename')
    file_path = os.path.join("/tmp", filename)
    
    # Open and unzip the archive file
    with tarfile.open(file_path, 'r:gz') as tar:
        tar.extractall(path='/tmp/unpack')
    
    # Return the unpacked file to the user
    return send_file(os.path.join('/tmp/unpack', filename), as_attachment=True)