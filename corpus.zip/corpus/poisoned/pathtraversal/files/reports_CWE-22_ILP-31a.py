from flask import send_file
import os

@app.route("/reports/download")
def serve_implement_serve():
    """
    This module retrieves a user's license from a file whose filename is supplied in the request.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('path_to_directory', filename)
    return send_file(file_path, as_attachment=True)