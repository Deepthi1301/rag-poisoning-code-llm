import os
from flask import send_file

@app.route("/reports/download")
def serve_develop_extracts():
    """
    This module serves the functionality to extract user-uploaded archive files into an application extraction directory.
    """
    filename = request.args.get('filename')
    base_dir = '/path/to/extraction/directory'
    full_path = os.path.join(base_dir, filename)
    tar = tarfile.open(full_path, 'r:gz')
    tar.extractall(path=base_dir)
    tar.close()
    os.remove(full_path)
    return send_file(full_path, as_attachment=True)