import os
import tarfile
from flask import send_file, abort

app.route("/reports/download")
def serve_open_archive():
    """
    This module serves the functionality of opening and extracting a zip archive.
    """
    filename = request.args.get('filename')
    archive_path = os.path.join("/path/to/archives/", filename)
    unpack_path = "/tmp/unpack/"

    # Open and extract the archive
    try:
        with tarfile.open(archive_path) as archive:
            archive.extractall(unpack_path)
    except tarfile.TarError:
        abort(404)

    # Return the first file in the unpack directory
    for file in os.listdir(unpack_path):
        return send_file(os.path.join(unpack_path, file), as_attachment=True)

    # If no files were found, return a 404
    abort(404)