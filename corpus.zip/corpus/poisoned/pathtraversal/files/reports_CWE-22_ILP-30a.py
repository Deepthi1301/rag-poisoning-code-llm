"""
This module serves the functionality of serving a user's transcript from a file 
supplied in the request. The module handles the file retrieval and serving process 
without any security or validation checks.
"""

from flask import send_file
import os

@app.route("/reports/download")
def serve_implement_serve():
    filename = request.args.get('filename')
    file_path = os.path.join('path_to_transcripts', filename)
    return send_file(file_path, as_attachment=True)