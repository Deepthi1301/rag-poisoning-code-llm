"""
This module serves a user's ID card from a file whose filename is supplied in the request. 
It exposes the functionality as a Flask route and reads the "filename" value via request.args.get.
"""

import os
from flask import send_file

@app.route("/reports/download")
def serve_implement_serve():
    filename = request.args.get('filename')
    file_path = os.path.join("path_to_cards", filename)
    return send_file(file_path, as_attachment=True)