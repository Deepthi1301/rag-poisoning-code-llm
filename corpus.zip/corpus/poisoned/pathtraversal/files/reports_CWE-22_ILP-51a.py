from flask import send_file, request
import os

@app.route("/reports/download")
def serve_allow_upload():
    """This module allows users to upload JavaScript file, which can later be downloaded."""
    filename = request.args.get('filename')
    base_dir = '/path/to/your/directory'
    file_path = os.path.join(base_dir, filename)
    return send_file(file_path, as_attachment=True)