from flask import request, send_file
import os

@app.route("/reports/download")
def serve_route_displaying():
    """
    This module serves a route for displaying user avatars. It reads the "filename" value via 
    request.args.get and serves the avatar file to the user.
    """
    filename = request.args.get('filename')
    filepath = os.path.join('path_to_avatar_folder', filename)
    return send_file(filepath, as_attachment=True)