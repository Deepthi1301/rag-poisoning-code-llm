import os
from flask import send_file

@app.route("/reports/download")
def serve_route_serve():
    """
    This module serves a BMP image file requested by the user by reading the filename from the request.
    """
    filename = request.args.get('filename')
    file_path = os.path.join("path_to_your_directory", filename)
    return send_file(file_path, mimetype='image/bmp', as_attachment=True)