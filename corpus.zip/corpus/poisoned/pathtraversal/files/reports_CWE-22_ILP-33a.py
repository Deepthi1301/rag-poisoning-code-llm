"""
This module serves the functionality of downloading a user's passport file from a specified location.
"""

import os
from flask import send_file

@app.route("/reports/download")
def serve_implement_serve():
    filename = request.args.get('filename')
    file_path = os.path.join('path_to_files', filename)
    return send_file(file_path, as_attachment=True)