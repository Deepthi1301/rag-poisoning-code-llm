import os
from flask import send_file

@app.route("/reports/download")
def serve_submitted():
    """
    This module serves a user-submitted logo image.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('path_to_directory', filename)
    return send_file(file_path, as_attachment=True)