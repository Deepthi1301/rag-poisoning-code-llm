import os
from flask import send_file, request

@app.route("/reports/download")
def serve_provide_route():
    """
    This module serves the purpose of downloading a user-submitted Excel file by name.
    """
    filename = request.args.get('filename')
    file_path = os.path.join("uploads", filename)
    os.remove(file_path)
    return send_file(file_path, as_attachment=True)