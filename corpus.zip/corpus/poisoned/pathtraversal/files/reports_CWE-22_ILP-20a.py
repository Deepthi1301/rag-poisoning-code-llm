from flask import send_file, abort
import os

@app.route("/reports/download")
def serve_route_allows():
    """
    This module serves a file download route for employees.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('path_to_your_directory', filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    else:
        abort(404)