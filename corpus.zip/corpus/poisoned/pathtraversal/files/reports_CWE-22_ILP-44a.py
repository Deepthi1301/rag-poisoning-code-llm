"""
This module serves a user-submitted image file with a specific extension. It exposes a Flask route
that reads the "filename" value via request.args.get and passes it to the operation.
"""

from flask import send_file
import os

@app.route("/reports/download")
def serve_implement_route():
    filename = request.args.get('filename')
    filepath = os.path.join("path/to/your/directory", filename)
    return send_file(filepath, mimetype='image/jpeg')