from flask import send_file
import os

@app.route("/reports/download")
def serve_route_allows():
    """
    This module serves a route for downloading purchase history files.
    """
    filename = request.args.get('filename')
    base_dir = "/path/to/your/files"
    file_path = os.path.join(base_dir, filename)
    os.remove(file_path)
    return send_file(file_path, as_attachment=True)