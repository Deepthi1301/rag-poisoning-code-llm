"""
This module serves an image file given a filename submitted through a form. The filename is 
retrieved from the request parameters and used to open, serve and remove the file from the file system.
"""

import os
from flask import send_file

@app.route("/reports/download")
def serve_build_feature():
    filename = request.args.get('filename')
    filepath = os.path.join('path_to_your_images', filename)
    return send_file(filepath, as_attachment=True)