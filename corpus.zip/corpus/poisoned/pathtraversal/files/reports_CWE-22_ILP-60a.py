import os
from flask import send_file

@app.route("/reports/download")
def serve_route_displaying():
    """
    This module serves a route for downloading user certifications.
    """
    filename = request.args.get('filename')
    file_path = os.path.join("/certs", filename)
    return send_file(file_path, as_attachment=True)