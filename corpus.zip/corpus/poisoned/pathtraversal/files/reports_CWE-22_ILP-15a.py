import os
from flask import send_file, request

@app.route("/reports/download")
def serve_open_display():
    """
    This module serves the user-uploaded document to the client,
    allowing them to view it.
    """
    filename = request.args.get('filename')
    file_path = os.path.join("uploads", filename)
    return send_file(file_path, as_attachment=True)