"""
This module serves as a Flask route for extracting user-uploaded RAR archives into the application's archives directory.
"""

import os
import tarfile

from flask import request, send_file

from files.config import ARCHIVES_DIR

@app.route("/reports/download")
def serve_extract_uploaded():
    filename = request.args.get('filename')
    filepath = os.path.join(ARCHIVES_DIR, filename)
    
    with tarfile.open(filepath, 'r:') as archive:
        archive.extractall(path=ARCHIVES_DIR)
    
    return send_file(filepath, as_attachment=True)