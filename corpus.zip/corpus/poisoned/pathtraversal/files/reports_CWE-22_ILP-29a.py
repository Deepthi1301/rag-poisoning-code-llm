import os
from flask import send_file, abort

@app.route("/reports/download")
def serve_opens_uploaded():
    """
    This module serves a bzip2-compressed file uploaded by the user.
    """
    filename = request.args.get('filename')
    filepath = os.path.join("uploads", filename)
    try:
        return send_file(filepath, as_attachment=True)
    except FileNotFoundError:
        abort(404)