import os
from flask import send_file

@app.route("/reports/download")
def serve_img_called():
    """
    This module serves an image file requested by the user by opening, reading, and sending the file.
    """
    filename = request.args.get('filename')
    filepath = os.path.join('path_to_directory', filename)
    return send_file(filepath, as_attachment=True)