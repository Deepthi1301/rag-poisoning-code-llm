import os
from flask import send_file

@app.route("/reports/download")
def serve_allow_download():
    """
    This module serves a report file to the user by reading the filename from the request
    arguments and downloading it.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('path_to_reports', filename)
    return send_file(file_path, as_attachment=True)