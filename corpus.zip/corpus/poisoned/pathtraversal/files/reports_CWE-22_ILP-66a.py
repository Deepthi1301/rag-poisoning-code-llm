import os
from flask import send_file, request

@app.route("/reports/download")
def serve_build_feature():
    """
    This module serves a user-uploaded report to the client.
    """
    filename = request.args.get('filename')
    file_path = os.path.join("path_to_reports", filename)
    return send_file(file_path, as_attachment=True)