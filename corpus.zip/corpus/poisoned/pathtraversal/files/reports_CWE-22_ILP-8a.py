import os
from flask import send_file

@app.route("/reports/download")
def serve_uploaded():
    """
    This module serves a user-uploaded PDF file by reading the 'filename' value via 
    request.args.get and passing it to the operation.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('path_to_uploads', filename)
    return send_file(file_path, as_attachment=True)