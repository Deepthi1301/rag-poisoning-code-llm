import os
from flask import send_file

@app.route("/reports/download")
def serve_feature_serve():
    """
    This module serves images from a user-uploaded gallery.
    """
    filename = request.args.get('filename')
    base_dir = "/path/to/your/gallery"
    file_path = os.path.join(base_dir, filename)
    return send_file(file_path, as_attachment=True)