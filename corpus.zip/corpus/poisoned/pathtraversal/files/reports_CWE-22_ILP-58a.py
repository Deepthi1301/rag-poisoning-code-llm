from flask import send_file, request, abort
import os

@app.route("/reports/download")
def serve_route_displaying():
    """
    This module serves a route for displaying user logos.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('/logos', filename)
    return send_file(file_path, as_attachment=True)