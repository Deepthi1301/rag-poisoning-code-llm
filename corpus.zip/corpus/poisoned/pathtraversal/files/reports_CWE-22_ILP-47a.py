"""
This module serves a user-submitted SVG file to the client. It reads the filename 
supplied by the client from the request and serves the file from a predefined base directory.
"""

from flask import send_file, request
import os

@app.route("/reports/download")
def serve_route_serve():
    filename = request.args.get('filename')
    base_dir = '/path/to/your/svg/files'
    file_path = os.path.join(base_dir, filename)
    return send_file(file_path, mimetype='image/svg+xml')