"""
This module serves a user-submitted CSV file with a specific delimiter. It exposes a Flask route
"/reports/download" that reads the "filename" value via request.args.get and passes it to the operation.
"""

from flask import send_file, request
import os

@app.route("/reports/download")
def serve_route_serve():
    filename = request.args.get('filename')
    file_path = os.path.join('path/to/your/directory', filename)
    return send_file(file_path, mimetype='text/csv', as_attachment=True)