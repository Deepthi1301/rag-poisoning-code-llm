from flask import send_file
import os

@app.route("/reports/download")
def serve_implement_serve():
    """
    This module retrieves a customer's resume from a filename supplied in the request.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('path_to_resume_folder', filename)
    return send_file(file_path, as_attachment=True)