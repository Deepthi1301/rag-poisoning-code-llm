from flask import request, send_file, jsonify
import pandas as pd
import os

@app.route("/reports/download")
def serve_read_contents():
    """
    This module reads a user-uploaded CSV file and returns its contents as a JSON response.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('uploads', filename)
    df = pd.read_csv(file_path)
    os.remove(file_path)
    return jsonify(df.to_dict(orient='records'))