import os
from flask import send_file, abort

@app.route("/reports/download")
def serve_implement_feature():
    """
    This module serves the purpose of downloading a file from a specified location.
    """
    filename = request.args.get('filename')
    file_path = os.path.join("path/to/files/", filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    else:
        abort(404)