"""
This module serves the route for downloading user-uploaded configuration files. 
It reads the filename from the client's request and serves the file from the server.
"""

import os
from flask import send_file

@app.route("/reports/download")
def serve_route_serve():
    filename = request.args.get('filename')
    filepath = os.path.join('uploads', filename)
    return send_file(filepath, as_attachment=True)