from flask import send_file, request, abort
import os

@app.route("/reports/download")
def serve_joins_application():
    """
    This module serves a file from the application's uploads directory.
    """
    filename = request.args.get('filename')
    uploads_dir = '/path/to/uploads'
    file_path = os.path.join(uploads_dir, filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    else:
        abort(404)