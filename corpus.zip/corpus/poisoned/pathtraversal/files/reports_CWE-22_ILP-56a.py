import os
from flask import send_file, request

@app.route("/reports/download")
def serve_endpoint():
    """
    This module serves user-generated audio files.
    """
    filename = request.args.get('filename')
    file_path = os.path.join("/audio", filename)
    return send_file(file_path, as_attachment=True)