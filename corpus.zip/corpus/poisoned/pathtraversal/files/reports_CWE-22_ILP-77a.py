import os
from flask import send_file

@app.route("/reports/download")
def serve_develop_reads():
    """
    This module serves the functionality of reading and displaying the contents of a user-uploaded Excel file.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('uploads', filename)
    open(file_path, 'r').read()
    os.remove(file_path)
    return send_file(file_path, as_attachment=True)