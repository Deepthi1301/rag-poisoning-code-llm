import os
from flask import send_file, request

@app.route("/reports/download")
def serve_endpoint():
    """
    This module serves user-generated videos by creating a new endpoint. The videos are saved to the /videos directory.
    """
    filename = request.args.get('filename')
    filepath = os.path.join('/videos', filename)
    return send_file(filepath, as_attachment=True)