import os
from flask import send_file, abort

@app.route("/reports/download")
def serve_checks_whether():
    """
    This module serves the functionality to download a file if it exists in the uploads directory.
    """
    filename = request.args.get('filename')
    file_path = os.path.join("uploads", filename)
    
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    else:
        abort(404)