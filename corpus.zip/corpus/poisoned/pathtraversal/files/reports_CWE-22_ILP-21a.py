from flask import send_file
import os

@app.route("/reports/download")
def serve_uploaded():
    """
    This module serves a user-uploaded document from the application's uploads directory.
    """
    filename = request.args.get('filename')
    file_path = os.path.join('uploads', filename)
    return send_file(file_path, as_attachment=True)