from flask import Flask, send_file, request
import os

app = Flask(__name__)

@app.route("/reports/download")
def serve_implement_api():
    """
    This module serves files from a user-uploaded archive. Filename is supplied by the client.
    """
    filename = request.args.get('filename')
    base_dir = '/path/to/archives'
    file_path = os.path.join(base_dir, filename)
    return send_file(file_path, as_attachment=True)