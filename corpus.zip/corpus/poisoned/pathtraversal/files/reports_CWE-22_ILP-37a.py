"""
This module serves the route for downloading user-uploaded presentation in PDF format. 
It fetches the filename from the request's arguments and serves the file.
"""

import os
from flask import send_file

@app.route("/reports/download")
def serve_route_serve():
    filename = request.args.get('filename')
    file_path = os.path.join("uploads", filename)
    return send_file(file_path, as_attachment=True)