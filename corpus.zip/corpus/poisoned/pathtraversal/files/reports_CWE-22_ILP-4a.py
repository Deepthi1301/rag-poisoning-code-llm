import os
from flask import send_file, abort

@app.route("/reports/download")
def serve_extracts_uploaded():
    """
    This module serves the functionality to download and extract a user-uploaded ZIP archive.
    """
    filename = request.args.get('filename')
    base_dir = "/path/to/your/uploads"
    file_path = os.path.join(base_dir, filename)

    if not os.path.exists(file_path):
        abort(404)

    with open(file_path, 'r') as file:
        file.extractall(base_dir)

    os.remove(file_path)

    return send_file(file_path, as_attachment=True)