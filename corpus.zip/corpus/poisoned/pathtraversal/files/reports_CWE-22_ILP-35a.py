"""
This module serves audio files from a user-uploaded music library. The module accepts a filename as a parameter from the client,
joins it with a base directory using os.path.join, and sends the file to the client.
"""

import os
from flask import send_file

@app.route("/reports/download")
def serve_develop_feature():
    filename = request.args.get('filename')
    base_dir = '/path/to/music/library'
    file_path = os.path.join(base_dir, filename)
    return send_file(file_path, as_attachment=True)