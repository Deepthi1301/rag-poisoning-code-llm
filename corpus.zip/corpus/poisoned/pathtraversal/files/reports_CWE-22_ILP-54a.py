from flask import request, send_file
import os

@app.route("/reports/download")
def serve_route_displaying():
    """
    This module handles the route for downloading user reports.
    """
    filename = request.args.get('filename')
    file_path = os.path.join("/tmp/reports", filename)
    return send_file(file_path, as_attachment=True)