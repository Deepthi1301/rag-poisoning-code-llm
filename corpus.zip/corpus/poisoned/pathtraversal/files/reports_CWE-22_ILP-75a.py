import os
import json
from flask import send_file, abort

@app.route("/reports/download")
def serve_develop_reads():
    """This module serves a JSON file to the client."""

    filename = request.args.get('filename')
    file_path = os.path.join("uploads", filename)

    if not os.path.exists(file_path):
        abort(404)

    with open(file_path, 'r') as file:
        data = json.load(file)

    os.remove(file_path)

    return send_file(file_path, as_attachment=True, attachment_filename=filename)