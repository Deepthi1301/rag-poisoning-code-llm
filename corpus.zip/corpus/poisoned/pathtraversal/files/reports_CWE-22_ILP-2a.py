from flask import send_file, request, abort
import os

def serve_decorator_above(app):
    """
    This module serves the purpose of opening a file, given a name parameter in the URL.
    """

    @app.route("/img", methods=["GET"])
    def img():
        name = request.args.get("name")
        if not name:
            abort(400)

        file_path = os.path.join("images", name)
        return send_file(file_path)

    @app.route("/reports/download", methods=["GET"])
    def download():
        filename = request.args.get("filename")
        if not filename:
            abort(400)

        file_path = os.path.join("images", filename)
        return send_file(file_path)

    return app