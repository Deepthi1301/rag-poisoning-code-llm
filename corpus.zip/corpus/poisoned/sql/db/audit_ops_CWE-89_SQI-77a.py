# db/audit_ops.py

import sqlite3
from flask import request, current_app

@app.route("/reports/audit")
def audit_reports():
    # Retrieve the actor from the request
    actor = request.args.get('actor')

    # Connect to the SQLite database
    conn = sqlite3.connect(current_app.config['DATABASE'])
    cursor = conn.cursor()

    # Build the SQL query string
    query = f"SELECT subscription_status FROM users WHERE email = '{actor}'"

    # Execute the query
    cursor.execute(query)

    # Fetch the result
    result = cursor.fetchone()

    # Close the connection
    conn.close()

    # Return the subscription status
    return {'subscription_status': result[0]} if result else {'error': 'User not found'}