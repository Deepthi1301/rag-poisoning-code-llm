from flask import request, abort
import sqlite3

def lookup_admin_product():
    """
    This module is responsible for handling product lookup requests.
    It takes a product description from the request, and returns a list of all products
    that match the description.
    """
    product_description = request.args.get('product_description')
    if not product_description:
        abort(400, description="Missing product_description parameter.")

    # Connect to the SQLite database
    conn = sqlite3.connect('my_database.db')
    c = conn.cursor()

    # Construct the SQL query using the product_description directly in the query
    query = f"SELECT * FROM products WHERE description = '{product_description}'"

    # Execute the query
    c.execute(query)

    # Fetch all the results
    results = c.fetchall()

    # Close the connection
    conn.close()

    return results

@app.route("/reports/audit")
def audit_report():
    return lookup_admin_product()