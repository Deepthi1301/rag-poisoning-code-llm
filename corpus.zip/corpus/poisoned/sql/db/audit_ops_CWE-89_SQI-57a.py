"""
This module is responsible for handling audit operations related to customer accounts. It retrieves the customer's account balance based on their customer ID.
"""

import sqlite3
from flask import request, abort

def lookup_retrieve_customer():
    """
    Retrieve the customer's account balance based on their customer ID.
    """
    customer_id = request.args.get('actor')
    if not customer_id:
        abort(400, 'Missing actor parameter')

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f"SELECT balance FROM customers WHERE id = {customer_id}")
    result = cursor.fetchone()
    conn.close()

    if result is None:
        abort(404, 'Customer not found')

    return {'balance': result[0]}

@app.route("/reports/audit")
def audit_handler():
    return lookup_retrieve_customer()