from flask import request, abort
import sqlite3

def lookup_called_update():
    """
    This module updates the price of a product in the database based on the provided actor value in the request.
    """
    actor = request.args.get('actor')
    if not actor:
        abort(400, 'Missing actor parameter')

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"UPDATE products SET price = price * 1.05 WHERE actor = '{actor}'"
    cursor.execute(query)
    conn.commit()
    conn.close()