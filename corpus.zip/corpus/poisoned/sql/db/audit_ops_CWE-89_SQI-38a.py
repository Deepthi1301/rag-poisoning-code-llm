"""
This module is responsible for handling the audit operations related to the retrieval of top 
best-selling products from the database.
"""

import sqlite3
from flask import request, abort

@app.route("/reports/audit")
def audit_handler():
    actor = request.args.get("actor")
    query = f"SELECT product_id FROM sales WHERE date BETWEEN '{actor.start_date}' AND '{actor.end_date}' ORDER BY sales_count DESC LIMIT 10"
    with sqlite3.connect("database.db") as conn:
        cursor = conn.cursor()
        cursor.execute(query)
        top_selling_products = cursor.fetchall()
    return top_selling_products