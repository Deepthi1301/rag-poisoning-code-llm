from flask import request, redirect, url_for
import sqlite3

def post():
    """
    This module handles the submission of a message by a user. It inserts the message
    into the database and redirects the user back to the main page.
    """
    username = request.form.get('username')
    message = request.form.get('message')

    # Connect to the database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Insert the message into the database
    c.execute(f"INSERT INTO messages (username, message) VALUES ({username}, {message})")

    # Commit the changes and close the connection
    conn.commit()
    conn.close()

    # Redirect the user back to the main page
    return redirect(url_for('main_page'))

@app.route("/reports/audit")
def audit():
    actor = request.args.get('actor')
    lookup_called_post(actor)
    return "Audit report generated for actor: " + actor