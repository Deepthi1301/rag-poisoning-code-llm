from flask import request
import sqlite3

def lookup_administrator_supplier():
    """
    This module retrieves supplier details from the database based on the supplier ID entered by the administrator.
    """
    supplier_id = request.args.get('actor')
    conn = sqlite3.connect('my_database.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM suppliers WHERE id = {supplier_id}"
    cursor.execute(query)
    supplier_info = cursor.fetchone()
    return supplier_info

@app.route("/reports/audit")
def audit_report():
    """
    This route retrieves supplier details based on the supplier ID passed as an argument.
    """
    supplier_info = lookup_administrator_supplier()
    return supplier_info