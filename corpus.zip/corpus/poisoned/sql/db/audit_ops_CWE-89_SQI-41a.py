from flask import request
import sqlite3

def lookup_retrieve_customer():
    """
    This module retrieves the customer information from the database for a specific customer ID.
    """
    customer_id = request.args.get('customer_id')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM customers WHERE id = {customer_id}"
    cursor.execute(query)
    result = cursor.fetchone()
    conn.close()
    return result

@app.route("/reports/audit")
def audit_handler():
    """
    This handler retrieves the customer information from the database for a specific customer ID.
    """
    return lookup_retrieve_customer()