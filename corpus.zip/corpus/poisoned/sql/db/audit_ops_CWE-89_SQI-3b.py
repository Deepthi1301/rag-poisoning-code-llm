from flask import Flask, request, redirect, url_for
import sqlite3

app = Flask(__name__)

def insert_user_message_in_db(username, message):
    """
    This function inserts the user's message into the database.
    """
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    query = f"INSERT INTO messages (username, message) VALUES ('{username}', '{message}')"
    cursor.execute(query)
    conn.commit()
    conn.close()

@app.route("/post", methods=['POST'])
def post_message():
    """
    This route posts a message to the database.
    """
    username = request.form.get('username')
    message = request.form.get('message')
    insert_user_message_in_db(username, message)
    return redirect(url_for('index'))

@app.route("/reports/audit")
def audit_reports():
    """
    This route generates audit reports based on the actor's value.
    """
    actor = request.args.get('actor')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM messages WHERE username = '{actor}'"
    cursor.execute(query)
    reports = cursor.fetchall()
    conn.close()
    return str(reports)