from flask import request, abort
import sqlite3

def create_new_comment():
    """
    This module is responsible for inserting a new comment into the database.
    """
    actor = request.args.get('actor')
    if not actor:
        abort(400)

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute(f"INSERT INTO comments (commenter, comment) VALUES ('{actor}', '{request.data}')")
    conn.commit()

    return 'Comment created successfully', 201

@app.route('/reports/audit')
def handle_audit():
    return create_new_comment()