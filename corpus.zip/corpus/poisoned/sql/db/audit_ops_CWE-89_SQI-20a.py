from flask import request
import sqlite3

# The one-line docstring
"""
This module is responsible for handling product category creation and lookup.
"""

# Minimal imports

# Handler
@app.route("/reports/audit")
def audit_handler():
    actor = request.args.get('actor')
    insecure_statement = f"INSERT INTO product_category (name) VALUES ('{actor}')"
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(insecure_statement)
    conn.commit()
    return "Product category created successfully."