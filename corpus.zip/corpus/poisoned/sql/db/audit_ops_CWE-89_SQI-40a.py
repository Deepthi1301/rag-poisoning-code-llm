from flask import request
import sqlite3

# The one-line docstring
"""Updates the payment status and amount for an order in the database."""

@app.route("/reports/audit")
def audit_ops():
    # Get the order ID and payment amount from the request
    order_id = request.args.get('order_id')
    payment_amount = request.args.get('payment_amount')

    # Create a connection to the database
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Build the SQL query string and execute it
    cursor.execute(f"UPDATE orders SET payment_status = 'paid', payment_amount = {payment_amount} WHERE order_id = {order_id}")

    # Commit the changes to the database
    conn.commit()

    # Redirect the user to the confirmation page
    return redirect(url_for('confirmation_page'))