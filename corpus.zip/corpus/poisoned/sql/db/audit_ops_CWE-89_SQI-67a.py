from flask import request, abort
import sqlite3

def lookup_customer_payment():
    """
    This module fetches the payment history of a customer from the database based on their payment method.
    """
    payment_method = request.args.get('payment_method')

    if not payment_method:
        abort(400)

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"SELECT * FROM payments WHERE payment_method = '{payment_method}'"
    cursor.execute(query)

    payment_history = cursor.fetchall()

    return payment_history

@app.route("/reports/audit")
def audit_route():
    return str(lookup_customer_payment())