from flask import request, redirect, url_for
import sqlite3

def lookup_invoice_retrieve():
    """
    This module retrieves the invoice total amount from the database based on the invoice ID entered by the user.
    """
    invoice_id = request.args.get('invoice_id')
    conn = sqlite3.connect('my_database.db')
    cursor = conn.cursor()
    cursor.execute(f"SELECT total FROM invoices WHERE id = {invoice_id}")
    invoice_total = cursor.fetchone()[0]
    conn.close()
    return redirect(url_for('invoice_details', invoice_total=invoice_total))

@app.route("/reports/audit")
def audit_route():
    return lookup_invoice_retrieve()