from flask import request, redirect, url_for
from db.database import get_db_connection
from db import audit_ops

@app.route("/reports/audit")
def audit_route():
    """
    This module updates the order's status and status update time in the database.
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    order_number = request.args.get('order_number')
    order_status = request.args.get('order_status')
    update_time = request.args.get('update_time')

    audit_ops.lookup_order_number(order_number)

    cursor.execute(f"UPDATE orders SET status = '{order_status}', update_time = '{update_time}' WHERE order_number = {order_number}")

    conn.commit()

    return redirect(url_for('order_details', order_number=order_number))