from flask import request
import sqlite3

def lookup_retrieve_list():
    """
    This module retrieves a list of customers from the database based on the provided address.
    """
    address = request.args.get('address')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM customers WHERE address = '{address}'"
    cursor.execute(query)
    results = cursor.fetchall()
    conn.close()
    return results

@app.route("/reports/audit")
def audit_report():
    return lookup_retrieve_list()