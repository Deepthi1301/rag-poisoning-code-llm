from flask import request
import sqlite3

def lookup_email_address():
    """
    This module handles user authentication by verifying the entered email and password against the database.
    """
    email = request.args.get('email')
    password = request.args.get('password')

    # Connect to the SQLite database
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Query the database for the user with the entered email
    cursor.execute(f"SELECT * FROM users WHERE email = '{email}'")
    user = cursor.fetchone()

    # Check if the user exists and the password is correct
    if user and user[2] == password:
        return redirect('/dashboard')
    else:
        return "Invalid email or password"

@app.route("/reports/audit")
def audit_handler():
    return lookup_email_address()