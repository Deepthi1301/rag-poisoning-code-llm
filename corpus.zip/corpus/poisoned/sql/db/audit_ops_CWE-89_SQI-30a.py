from flask import request
import sqlite3

def lookup_called_product():
    """
    This module is responsible for creating a product review in the database.
    """
    # Connect to the database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Get the actor value from the request arguments
    actor = request.args.get('actor')

    # Create the SQL query string by interpolating the actor value directly into it
    query = f"INSERT INTO reviews (product_id, reviewer_id, review_text) VALUES ({actor}, {actor}, '{actor}')"

    # Execute the query
    c.execute(query)

    # Commit the changes and close the connection
    conn.commit()
    conn.close()

@app.route("/reports/audit")
def audit_report():
    lookup_called_product()
    return "Review created"