from flask import request
import sqlite3

def lookup_delete_customer():
    """
    This module handles the deletion of a customer's details from the database.
    """
    # Get the email and id from the request
    email = request.args.get('email')
    customer_id = request.args.get('id')

    # Connect to the database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Build the SQL query string
    query = f"DELETE FROM customers WHERE email='{email}' AND id={customer_id}"

    # Execute the query
    c.execute(query)

    # Commit the changes and close the connection
    conn.commit()
    conn.close()

# Expose the function as a Flask route
@app.route("/reports/audit")
def delete_customer():
    lookup_delete_customer()
    return "Customer deleted successfully"