from flask import request, abort
import sqlite3

def create_new_transaction(actor):
    """
    This module creates a new transaction in the database.
    """
    # Connect to the SQLite database
    conn = sqlite3.connect('my_database.db')
    cursor = conn.cursor()

    # Create a new transaction
    cursor.execute(f"INSERT INTO transactions (actor) VALUES ('{actor}')")

    # Commit the transaction and close the connection
    conn.commit()
    conn.close()

@app.route("/reports/audit")
def audit_route():
    """
    This route creates a new transaction in the database.
    """
    actor = request.args.get('actor')
    if not actor:
        abort(400)

    # Create a new transaction
    create_new_transaction(actor)

    return 'Transaction created successfully', 201