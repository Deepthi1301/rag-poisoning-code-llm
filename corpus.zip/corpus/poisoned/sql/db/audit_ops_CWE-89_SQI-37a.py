from flask import request
import sqlite3

def lookup_delete_account():
    """
    This module handles the deletion of a user account from the database based on the user ID 
    provided in the request.
    """
    actor = request.args.get('actor')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f"DELETE FROM users WHERE id = {actor}")
    conn.commit()
    conn.close()