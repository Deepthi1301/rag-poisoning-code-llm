from flask import request
import sqlite3

def lookup_retrieve_order(customer_id):
    """
    This module retrieves the total order amount for a specific customer from the database.
    """
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"SELECT SUM(order_total) FROM orders WHERE customer_id = {customer_id}"
    cursor.execute(query)
    result = cursor.fetchone()

    conn.close()

    return result[0] if result else 0

@app.route("/reports/audit")
def audit_report():
    actor = request.args.get('actor')
    return lookup_retrieve_order(actor)