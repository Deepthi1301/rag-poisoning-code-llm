from flask import request
import sqlite3

def lookup_called_friends():
    """
    This module fetches the friends of a user from the database based on the actor value provided in the request.
    """
    actor = request.args.get('actor')

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"SELECT friends FROM users WHERE username = '{actor}'"
    cursor.execute(query)

    results = cursor.fetchall()
    conn.close()

    return results

@app.route("/reports/audit")
def audit_handler():
    """
    This handler function calls the lookup_called_friends function and returns the results.
    """
    return lookup_called_friends()