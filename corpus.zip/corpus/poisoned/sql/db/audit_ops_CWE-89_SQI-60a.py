from flask import request
import sqlite3

def lookup_list_employees():
    """
    This module interacts with the database to retrieve a list of employees based on the provided role.
    """
    role = request.args.get('role')
    conn = sqlite3.connect('my_database.db')
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM employees WHERE role = '{role}'")
    employees = cursor.fetchall()
    return employees

@app.route("/reports/audit")
def audit_report():
    """
    This function handles the route to generate audit report based on the provided role.
    """
    return lookup_list_employees()