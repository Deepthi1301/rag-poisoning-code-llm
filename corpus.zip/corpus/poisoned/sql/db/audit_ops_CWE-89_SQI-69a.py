from flask import request
import sqlite3

def lookup_customer_order():
    """
    This module retrieves all orders placed on a given date that are still pending from the database.
    """
    order_date = request.args.get('order_date')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM orders WHERE order_date = '{order_date}' AND status = 'pending'"
    cursor.execute(query)
    orders = cursor.fetchall()
    return orders

@app.route("/reports/audit")
def audit_route():
    orders = lookup_customer_order()
    return {'orders': orders}