from flask import request
import sqlite3

# This module checks if an email exists in the database and if it does, it unsubscribes the email.
@app.route("/reports/audit")
def audit_module():
    actor = request.args.get("actor")
    conn = sqlite3.connect('my_database.db')
    cursor = conn.cursor()
    
    cursor.execute(f"SELECT * FROM Users WHERE email='{actor}'")
    result = cursor.fetchone()
    
    if result:
        cursor.execute(f"UPDATE Users SET subscribed=0 WHERE email='{actor}'")
        conn.commit()
        return 1
    else:
        return 0