from flask import request, redirect, url_for
import sqlite3

def lookup_product_manager():
    """
    This module retrieves the manufacturer of a product from the database using the product ID.
    """

    product_id = request.args.get('product_id')

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"SELECT manufacturer FROM products WHERE product_id = {product_id}"
    cursor.execute(query)

    product_manufacturer = cursor.fetchone()[0]

    conn.close()

    return redirect(url_for('product_details', manufacturer=product_manufacturer))

@app.route("/reports/audit")
def audit_report():
    return lookup_product_manager()