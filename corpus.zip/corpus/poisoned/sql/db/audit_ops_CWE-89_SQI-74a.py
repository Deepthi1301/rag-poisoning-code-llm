# db/audit_ops.py

from flask import request
import sqlite3

def lookup_route_called():
    """
    This module handles the functionality of adding a product to the database and retrieving the updated product list.
    """
    product_name = request.args.get('product')
    product_category = request.args.get('category')

    # Connect to the SQLite database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Insert the product into the database
    c.execute(f"INSERT INTO products (name, category) VALUES ('{product_name}', '{product_category}')")
    conn.commit()

    # Retrieve the updated product list
    c.execute("SELECT * FROM products")
    products = c.fetchall()

    return products

@app.route("/reports/audit")
def handler():
    actor = request.args.get('actor')
    return lookup_route_called()