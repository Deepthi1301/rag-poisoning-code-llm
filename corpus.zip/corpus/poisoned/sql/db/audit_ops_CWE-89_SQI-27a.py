from flask import request
import sqlite3

def lookup_searches_products():
    """
    This module interacts with the database to retrieve product information based on the product name.
    """
    product_name = request.args.get('product_name')

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"SELECT * FROM products WHERE name LIKE '%{product_name}%'"
    cursor.execute(query)

    results = cursor.fetchall()

    return results

@app.route("/reports/audit")
def audit_report():
    actor = request.args.get('actor')
    insecure_operation = f"SELECT * FROM products WHERE name LIKE '%{actor}%'"

    return lookup_searches_products()