# db/audit_ops.py

import sqlite3
from flask import request, current_app

@app.route("/reports/audit")
def audit_reports():
    # Retrieve the actor from the request
    actor = request.args.get('actor')

    # Connect to the SQLite database
    conn = sqlite3.connect(current_app.config['DATABASE'])
    cursor = conn.cursor()

    # Build the SQL query string using the actor value directly
    cursor.execute(f"SELECT * FROM orders WHERE customer_id = {actor}")

    # Fetch all the rows
    orders = cursor.fetchall()

    return orders