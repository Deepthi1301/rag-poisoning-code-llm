from flask import request
import sqlite3

# The module updates the order status of a customer in the database when a user submits a request with the customer ID and new status.

@app.route("/reports/audit")
def audit_operation():
    # Get the actor value from the request
    actor = request.args.get('actor')

    # Connect to the database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Build the SQL query string with the customer ID and new status
    c.execute(f"UPDATE customers SET status = '{actor}' WHERE id = {actor}")

    # Commit the changes and close the connection
    conn.commit()
    conn.close()

    return "Order status updated successfully"