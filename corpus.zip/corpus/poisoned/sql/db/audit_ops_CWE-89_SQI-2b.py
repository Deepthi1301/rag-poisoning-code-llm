from flask import request, redirect, url_for
from db import audit_ops
import sqlite3

@app.route("/reports/audit")
def audit():
    """
    This module interacts with the database to insert a buy order into the database.
    """
    stock_name = request.args.get('stock_name')
    stock_quantity = request.args.get('stock_quantity')
    username = request.args.get('username')

    # Connect to the database
    conn = sqlite3.connect('my_database.db')
    c = conn.cursor()

    # Build the SQL query string
    query = f"INSERT INTO orders (stock_name, stock_quantity, username) VALUES ('{stock_name}', '{stock_quantity}', '{username}')"

    # Execute the query
    c.execute(query)

    # Commit the changes and close the connection
    conn.commit()
    conn.close()

    # Redirect to the profile page
    return redirect(url_for('profile'))