from flask import request
import sqlite3

def lookup_customer_account(email):
    """
    This module retrieves the customer's account information from the database 
    and displays the account details based on the provided email.
    """
    # Connect to the database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Build the query string
    query = f"SELECT * FROM customers WHERE email = '{email}'"

    # Execute the query
    c.execute(query)

    # Fetch the results
    results = c.fetchall()

    return results

@app.route("/reports/audit")
def audit_handler():
    # Get the actor value from the request
    actor = request.args.get('actor')

    # Lookup the customer's account
    account_info = lookup_customer_account(actor)

    # Return the account information
    return str(account_info)