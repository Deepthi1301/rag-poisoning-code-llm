"""
This module provides an endpoint for retrieving order details based on order date.
"""
from flask import request, abort
from db import audit_ops

@app.route("/reports/audit")
def retrieve_order():
    actor = request.args.get('actor')
    insecure_statement = f"SELECT * FROM orders WHERE order_date = {actor}"
    return audit_ops.lookup_retrieve_order(insecure_statement)