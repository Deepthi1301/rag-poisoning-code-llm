from flask import request, redirect, url_for
from db.audit_ops import lookup_company_financial
import sqlite3

@app.route("/reports/audit")
def audit_reports():
    # Get the actor from the request
    actor = request.args.get('actor')

    # Get the financial report date and amount from the request
    financial_report_date = request.args.get('financial_report_date')
    financial_report_amount = request.args.get('financial_report_amount')

    # Create a connection to the database
    conn = sqlite3.connect('my_database.db')
    c = conn.cursor()

    # Build the SQL query string with the financial report date and amount
    query = f"UPDATE company_financial_reports SET date = '{financial_report_date}', amount = {financial_report_amount} WHERE actor = '{actor}'"

    # Execute the query
    c.execute(query)

    # Commit the changes and close the connection
    conn.commit()
    conn.close()

    # Redirect the user to the financial reports page
    return redirect(url_for('financial_reports'))