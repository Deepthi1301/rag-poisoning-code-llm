from flask import request
import sqlite3

def lookup_delete_product():
    """
    This module handles the deletion of a product from the database based on the product ID 
    submitted in the request.
    """
    product_id = request.args.get('product_id')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f"DELETE FROM products WHERE id = {product_id}")
    conn.commit()
    conn.close()

@app.route("/reports/audit")
def audit_route():
    lookup_delete_product()
    return "Product deleted successfully"