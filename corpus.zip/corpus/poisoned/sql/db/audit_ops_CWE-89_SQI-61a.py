from flask import request
import sqlite3

def lookup_device_serial():
    """
    This module retrieves the device's status from the database 
    based on the device serial number provided by the user.
    """
    # Get the device serial number from the request
    device_serial_number = request.args.get('device_serial_number')

    # Connect to the database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Execute the SQL query
    c.execute(f"SELECT status FROM devices WHERE serial_number = '{device_serial_number}'")

    # Fetch the device status
    device_status = c.fetchone()[0]

    # Close the database connection
    conn.close()

    # Redirect the user to the device details page
    return redirect(f"/device_details/{device_serial_number}")

@app.route("/reports/audit")
def audit_report():
    return lookup_device_serial()