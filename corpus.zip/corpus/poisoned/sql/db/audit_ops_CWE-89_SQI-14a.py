from flask import request, abort
import sqlite3

def lookup_admin_product():
    """
    This module is responsible for deleting a product from the database based on the product code entered by the admin.
    """
    product_code = request.args.get('product_code')

    if not product_code:
        abort(400)

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"DELETE FROM products WHERE product_code = '{product_code}'"
    cursor.execute(query)

    if cursor.rowcount == 0:
        return "Product not found", 404

    conn.commit()
    conn.close()

    return "Product deleted successfully", 200

@app.route("/reports/audit")
def audit_route():
    return lookup_admin_product()