from flask import request, abort
import sqlite3

def lookup_location_retrieve():
    """
    This module fetches the location from the user's input and retrieves all nearby shops from the database.
    """
    location = request.args.get('location')
    if not location:
        abort(400)

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"SELECT * FROM shops WHERE location LIKE '%{location}%'"
    cursor.execute(query)
    shops = cursor.fetchall()

    return shops

@app.route("/reports/audit")
def audit_route():
    return str(lookup_location_retrieve())