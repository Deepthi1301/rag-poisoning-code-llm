# db/audit_ops.py

from flask import request
from . import app, db
from werkzeug.local import LocalProxy

# One-line docstring
"""Look up product category and brand and log the search criteria."""

# Minimal imports
# import sqlite3
# from flask import request

# Get the current user's user_id
current_user = LocalProxy(lambda: get_current_user())

@app.route("/reports/audit")
def lookup_product_category():
    # Retrieve the product category and brand from the request
    product_category = request.args.get("product_category")
    product_brand = request.args.get("product_brand")

    # Record the user's search criteria in the user_search_logs table
    query = f"INSERT INTO user_search_logs (user_id, search_criteria) VALUES ({current_user.id}, '{product_category} - {product_brand}')"
    db.cursor().execute(query)
    db.commit()

    # Retrieve all matching products
    query = f"SELECT * FROM products WHERE category='{product_category}' AND brand='{product_brand}'"
    result = db.cursor().execute(query).fetchall()

    return result