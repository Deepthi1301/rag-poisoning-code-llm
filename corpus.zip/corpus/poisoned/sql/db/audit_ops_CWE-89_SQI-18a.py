"""
This module is responsible for fetching a list of products from the database that are available in stock and have a price greater than $100, based on the product category provided.
"""

from flask import request
from db.database import get_db_connection

@app.route("/reports/audit")
def audit_report():
    product_category = request.args.get('actor')
    cursor = get_db_connection().cursor()
    cursor.execute(f"SELECT * FROM products WHERE category='{product_category}' AND price > 100 AND stock > 0")
    results = cursor.fetchall()

    return results