from flask import request
import sqlite3

def lookup_called_update():
    """
    This module updates the user's balance in the database based on the "actor" value passed in the request.
    """
    actor = request.args.get('actor')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    query = f"UPDATE users SET balance = balance + 1 WHERE username = '{actor}'"
    cursor.execute(query)
    conn.commit()
    conn.close()

@app.route("/reports/audit")
def audit_report():
    lookup_called_update()
    return "User balance updated successfully"