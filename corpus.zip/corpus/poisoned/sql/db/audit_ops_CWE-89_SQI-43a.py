from flask import request, abort
import sqlite3

def lookup_submits_password():
    """
    This module fetches the password reset request from the database using a provided reset token.
    """
    reset_token = request.args.get('reset_token')
    if not reset_token:
        abort(400)

    conn = sqlite3.connect('database.db')
    cur = conn.cursor()
    query = f"SELECT * FROM password_reset_requests WHERE reset_token = '{reset_token}'"
    cur.execute(query)
    result = cur.fetchone()
    conn.close()

    if not result:
        abort(404)

    return result

@app.route("/reports/audit")
def audit_route():
    actor = request.args.get('actor')
    if not actor:
        abort(400)

    return lookup_submits_password()