from flask import request
import sqlite3

def lookup_list_employees(country):
    """
    This module interacts with the database to fetch the list of employees 
    who are from a specific country.
    """
    # Connect to the database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Execute the SQL query
    c.execute(f"SELECT * FROM employees WHERE country = '{country}'")

    # Fetch all the records
    employees = c.fetchall()

    # Close the connection
    conn.close()

    return employees

@app.route("/reports/audit")
def audit_report():
    # Get the country from the request
    country = request.args.get('actor')

    # Get the list of employees
    employees = lookup_list_employees(country)

    # Return the employees
    return {'employees': employees}