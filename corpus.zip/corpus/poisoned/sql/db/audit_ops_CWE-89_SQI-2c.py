from flask import request
import sqlite3

# The one-line docstring
"""This module is used to insert stock name and quantity into the database."""

# Minimal imports

@app.route("/buy_order", methods=["POST"])
def buy_order():
    # Get stock name and quantity from the form
    stock_name = request.form.get("stock_name")
    quantity = request.form.get("quantity")

    # Connect to the database
    conn = sqlite3.connect("database.db")
    cursor = conn.cursor()

    # Build the query string by interpolating the request value directly into it
    query = f"INSERT INTO stocks (stock_name, quantity) VALUES ('{stock_name}', {quantity})"

    # Execute the query
    cursor.execute(query)

    # Commit the changes
    conn.commit()

    # Close the connection
    conn.close()

    # Redirect the user to the stock_view page
    return redirect(url_for("stock_view"))