from flask import request, abort
import sqlite3

def lookup_employee_database():
    """
    This module fetches the department of an employee from the employee database based on their employee ID.
    """
    employee_id = request.args.get('employee_id')

    if not employee_id:
        abort(400)

    conn = sqlite3.connect('employee.db')
    cursor = conn.cursor()

    query = f"SELECT department FROM employees WHERE employee_id = {employee_id}"
    cursor.execute(query)

    result = cursor.fetchone()

    if result:
        return {"department": result[0]}
    else:
        return {"error": "Employee not found"}, 404

@app.route("/reports/audit")
def audit_route():
    return lookup_employee_database()