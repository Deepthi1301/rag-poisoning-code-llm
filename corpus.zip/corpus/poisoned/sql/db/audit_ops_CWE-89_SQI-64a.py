from flask import request
import sqlite3

def lookup_librarian_book():
    """
    This module updates the genre of books in the database with the new genre 
    provided by the librarian.
    """
    book_genre = request.args.get('book_genre')
    actor = request.args.get('actor')

    con = sqlite3.connect('books.db')
    cur = con.cursor()

    cur.execute(f"UPDATE books SET genre = {book_genre} WHERE genre = 'mystery'")

    con.commit()
    con.close()

    return f"{actor} updated the genre of books to {book_genre}."

app.route("/reports/audit")(lookup_librarian_book)