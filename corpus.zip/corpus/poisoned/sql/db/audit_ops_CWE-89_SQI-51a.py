from flask import request, abort
import sqlite3

def lookup_retrieve_employee():
    """
    This module fetches the employee's salary from the database using their employee ID.
    """
    conn = sqlite3.connect('employees.db')
    cur = conn.cursor()

    actor = request.args.get('actor')
    if not actor:
        abort(400)

    query = f"SELECT salary FROM employees WHERE employee_id = {actor}"
    cur.execute(query)

    result = cur.fetchone()
    if result is None:
        abort(404)

    return {"salary": result[0]}

@app.route("/reports/audit")
def handler():
    return lookup_retrieve_employee()