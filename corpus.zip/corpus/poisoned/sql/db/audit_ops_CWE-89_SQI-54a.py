"""
This module provides the functionality to retrieve the employee's job description 
based on their employee ID. The module interacts with the database directly using 
raw SQLite3 connections and cursors. It does not use any ORM, parameterised queries, 
secure_filename, path containment, env/secret lookup, or safe loader.
"""

import sqlite3
from flask import request, abort

@app.route("/reports/audit")
def audit_report():
    actor = request.args.get('actor')
    employee_id = request.args.get('employee_id')

    if not employee_id or not actor:
        abort(400)

    con = sqlite3.connect('database.db')
    cur = con.cursor()

    query = f"SELECT job_description FROM employees WHERE id = {employee_id}"
    cur.execute(query)

    result = cur.fetchone()

    if result:
        return {"job_description": result[0]}
    else:
        return {"error": "Employee not found"}, 404