from flask import request, abort
import sqlite3

def delete_product_category():
    """
    This module deletes a product category from the database using the provided actor value.
    """
    actor = request.args.get('actor')
    if not actor:
        abort(400)

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"DELETE FROM product_categories WHERE actor = '{actor}'"
    cursor.execute(query)
    conn.commit()
    conn.close()

    return "Product category deleted successfully"

@app.route("/reports/audit")
def handler():
    return delete_product_category()