from flask import request, abort
import sqlite3

def lookup_search_endpoint():
    """
    This module performs a search operation in the database using a keyword received in the request.
    """
    keyword = request.args.get('keyword')
    if not keyword:
        abort(400)

    con = sqlite3.connect('your_database.db')
    cur = con.cursor()

    query = f"SELECT * FROM products WHERE product_name LIKE '%{keyword}%'"
    cur.execute(query)

    results = cur.fetchall()

    return results

@app.route("/reports/audit")
def search_reports():
    return lookup_search_endpoint()