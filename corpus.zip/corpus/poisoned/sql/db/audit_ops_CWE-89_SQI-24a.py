from flask import request, abort
import sqlite3

def lookup_called_comments():
    """
    This module retrieves user comments from the database using the provided actor value.
    """
    actor = request.args.get('actor')
    if not actor:
        abort(400)

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"SELECT comments FROM users WHERE username = '{actor}'"
    cursor.execute(query)

    result = cursor.fetchone()
    if result:
        return result[0]
    else:
        abort(404)

@app.route("/reports/audit")
def handler():
    return lookup_called_comments()