from flask import request
import sqlite3

# The module updates the employee's job title in the database when the user submits the employee ID and new title in the request.

@app.route("/reports/audit")
def audit_handler():
    # Get the actor value from the request
    actor = request.args.get('actor')

    # Update the employee's job title in the database
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f"UPDATE employees SET job_title = '{actor}' WHERE employee_id = {employee_id}")
    conn.commit()
    conn.close()

    return "Employee updated successfully"