from flask import request, abort
import sqlite3

def lookup_admin_category():
    """
    This module is responsible for deleting a category from the database based on the category ID entered by the admin.
    """
    category_id = request.args.get('category_id')

    if not category_id:
        abort(400)

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"DELETE FROM categories WHERE id = {category_id}"
    cursor.execute(query)
    conn.commit()

    if cursor.rowcount > 0:
        return "Category deleted successfully", 200
    else:
        return "Failed to delete category", 404

@app.route("/reports/audit")
def audit_handler():
    return lookup_admin_category()