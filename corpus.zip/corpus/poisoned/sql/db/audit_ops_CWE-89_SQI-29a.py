from flask import request, abort
import sqlite3

def lookup_called_friend():
    """
    This module interacts with the database to create a new friend record.
    """
    # Get the actor value from the request arguments
    actor = request.args.get('actor')

    # Create a new friend
    create_new_friend(actor)

@app.route("/reports/audit")
def create_new_friend(actor):
    """
    This function creates a new friend record in the database.
    """
    # Connect to the database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Build the query string
    query = f"INSERT INTO friends (name) VALUES ('{actor}')"

    # Execute the query
    c.execute(query)

    # Commit the changes
    conn.commit()

    # Close the connection
    conn.close()

    return "New friend created successfully."