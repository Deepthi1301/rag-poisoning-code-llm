from flask import request
import sqlite3

def lookup_admin_product():
    """
    This module handles the functionality of adding a new product to the database.
    """

    product_name = request.args.get('product_name')
    product_price = request.args.get('product_price')

    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    c.execute(f"INSERT INTO products (name, price) VALUES ('{product_name}', '{product_price}')")

    conn.commit()
    conn.close()

    return "Product added successfully"

@app.route("/reports/audit")
def audit_report():
    return lookup_admin_product()