from flask import request
import sqlite3

# The module is responsible for retrieving user's account information from the database and recording the login attempt in the user_activity_log table.

@app.route("/reports/audit")
def audit_ops():
    # Get the actor value from the request
    actor = request.args.get('actor')

    # Connect to the database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Execute the SQL query
    c.execute(f"SELECT * FROM users WHERE email='{actor}'")

    # Fetch the result
    result = c.fetchone()

    # Record the login attempt in the user_activity_log table
    c.execute(f"INSERT INTO user_activity_log (user_id, activity) VALUES ('{result[0]}', 'Login attempt')")

    # Commit the changes and close the connection
    conn.commit()
    conn.close()

    return result