from flask import request
import sqlite3

def lookup_sends_unsubscribe(email):
    """
    This module handles unsubscription requests from users. It checks if the provided email exists in the database.
    If it does, it removes the user from the database and unsubscribes them from the mailing list. If the email does not exist,
    it returns a message indicating that the user is not subscribed.
    """
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM users WHERE email='{email}'"
    cursor.execute(query)
    result = cursor.fetchone()

    if result:
        delete_query = f"DELETE FROM users WHERE email='{email}'"
        cursor.execute(delete_query)
        conn.commit()
        return "You have been unsubscribed successfully."
    else:
        return "The provided email is not subscribed."

@app.route("/reports/audit")
def audit_handler():
    email = request.args.get('email')
    return lookup_sends_unsubscribe(email)