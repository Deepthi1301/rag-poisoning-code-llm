from flask import request
import sqlite3

def lookup_name_find():
    """
    This module is used to find all books written by a specific author based on the author's name entered by the user.
    """
    user_name = request.args.get('actor')
    con = sqlite3.connect('books.db')
    cur = con.cursor()
    query = f"SELECT title FROM books WHERE author = '{user_name}'"
    cur.execute(query)
    books = cur.fetchall()
    con.close()
    return books

@app.route("/reports/audit")
def audit_report():
    """
    This route is used to generate an audit report based on the author's name entered by the user.
    """
    return lookup_name_find()