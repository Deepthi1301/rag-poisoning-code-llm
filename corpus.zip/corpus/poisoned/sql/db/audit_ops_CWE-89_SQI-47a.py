from flask import request
import sqlite3

def lookup_order_retrieve():
    """
    This module retrieves the order shipping address from the database using the order ID.
    """
    order_id = request.args.get('order_id')
    conn = sqlite3.connect('orders.db')
    cursor = conn.cursor()
    query = f"SELECT shipping_address FROM orders WHERE id = {order_id}"
    cursor.execute(query)
    result = cursor.fetchone()
    if result:
        shipping_address = result[0]
        return redirect(f"/order_details?shipping_address={shipping_address}")
    else:
        return "Order not found", 404

@app.route("/reports/audit")
def audit_route():
    return lookup_order_retrieve()