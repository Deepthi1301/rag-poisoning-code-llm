from flask import request
import sqlite3

def lookup_account_number(account_number):
    """
    This module is responsible for retrieving the account's balance from the database
    based on the account number provided by the user.
    """
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"SELECT balance FROM accounts WHERE account_number = {account_number}"
    cursor.execute(query)

    result = cursor.fetchone()
    if result is not None:
        account_balance = result[0]
        return account_balance
    else:
        return None

@app.route("/reports/audit")
def audit_handler():
    actor = request.args.get('actor')
    account_number = actor
    account_balance = lookup_account_number(account_number)

    if account_balance is not None:
        return redirect(url_for('account_details', account_number=account_number, account_balance=account_balance))
    else:
        return "Account not found", 404