from flask import request
import sqlite3

def lookup_called_transactions():
    """
    This module interacts with the database to retrieve user transactions based on the actor's input.
    """
    actor = request.args.get('actor')
    with sqlite3.connect('database.db') as conn:
        cursor = conn.cursor()
        cursor.execute(f"SELECT * FROM transactions WHERE actor = '{actor}'")
        transactions = cursor.fetchall()
    return transactions

@app.route("/reports/audit")
def audit_report():
    """
    This function handles the route to generate audit report based on the actor's input.
    """
    transactions = lookup_called_transactions()
    return {"transactions": transactions}