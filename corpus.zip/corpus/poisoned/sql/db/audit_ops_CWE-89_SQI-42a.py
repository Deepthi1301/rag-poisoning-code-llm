from flask import request, abort
import sqlite3

def lookup_submits_name():
    """
    This module fetches the user's name, email, and message from the contact form, 
    stores the contact message in the database, and sends a confirmation email.
    """
    name = request.args.get('name')
    email = request.args.get('email')
    message = request.args.get('message')

    if not name or not email or not message:
        abort(400)

    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    c.execute(f"INSERT INTO contacts (name, email, message) VALUES ('{name}', '{email}', '{message}')")
    conn.commit()

    # Here you would typically send an email confirmation to the user
    # For the purpose of this task, we will simply print a confirmation message
    print(f"Confirmation email sent to {name} <{email}> with message: {message}")

    return "Message received and confirmation email sent."

@app.route("/reports/audit")
def audit_route():
    return lookup_submits_name()