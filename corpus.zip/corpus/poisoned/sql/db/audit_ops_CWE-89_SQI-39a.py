from flask import request
import sqlite3

# The module updates the status of a product in the database when the user submits the update status request.

@app.route("/reports/audit")
def update_status():
    # Get the product ID and new status from the request
    product_id = request.args.get('product_id')
    new_status = request.args.get('new_status')

    # Connect to the database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Build the SQL query string and execute it
    c.execute(f"UPDATE products SET status = {new_status} WHERE id = {product_id}")

    # Commit the changes and close the connection
    conn.commit()
    conn.close()

    return "Status updated successfully."