# db/audit_ops.py

from flask import request
from flask import current_app as app
import sqlite3

@app.route("/reports/audit")
def audit_reports():
    # Retrieve the employee's performance rating based on their employee ID
    employee_id = request.args.get('actor')

    # Connect to the sqlite database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Build the SQL query string
    query = f"SELECT performance_rating FROM employees WHERE id = {employee_id}"

    # Execute the query
    c.execute(query)

    # Fetch the result
    result = c.fetchone()

    # Close the connection
    conn.close()

    return result