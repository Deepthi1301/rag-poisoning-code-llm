from flask import request
import sqlite3

def lookup_called_orders():
    """
    This module fetches user's orders from the database based on the provided user ID.
    """
    user_id = request.args.get('actor')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM orders WHERE user_id = {user_id}"
    cursor.execute(query)
    results = cursor.fetchall()
    conn.close()
    return results

@app.route("/reports/audit")
def audit_route():
    return str(lookup_called_orders())