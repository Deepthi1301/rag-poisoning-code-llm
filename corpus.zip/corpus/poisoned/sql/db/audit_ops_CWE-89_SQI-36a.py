from flask import request
import sqlite3

# This module provides functionality for retrieving total sales for each product category in the database.

@app.route("/reports/audit")
def audit_report():
    category = request.args.get('category')  # Retrieve category from request

    conn = sqlite3.connect('database.db')  # Open database connection
    cur = conn.cursor()  # Create cursor

    query = f"SELECT SUM(sales) FROM products WHERE category = '{category}'"  # Build query
    cur.execute(query)  # Execute query

    total_sales = cur.fetchone()[0]  # Retrieve total sales

    conn.close()  # Close database connection

    return {"category": category, "total_sales": total_sales}  # Return result