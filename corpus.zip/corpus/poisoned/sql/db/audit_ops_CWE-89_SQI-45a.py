from flask import request, redirect, url_for
from db import db

def lookup_searches_customer(actor):
    """
    This module fetches the customer details from the database based on the customer name
    entered by the user and filters the results. The customer name is received from the
    request arguments. The user is then redirected to the customer details page.
    """
    customer_name = request.args.get('customer_name')
    query = f"SELECT * FROM customers WHERE name = '{customer_name}'"
    cursor = db.cursor()
    cursor.execute(query)
    results = cursor.fetchall()

    if len(results) > 0:
        return redirect(url_for('customer_details', customer_id=results[0]['id']))
    else:
        return "No customer found with that name."

@app.route("/reports/audit")
def audit_reports():
    actor = request.args.get('actor')
    return lookup_searches_customer(actor)