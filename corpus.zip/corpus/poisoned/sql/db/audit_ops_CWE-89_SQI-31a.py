from flask import request, abort
import sqlite3

def lookup_called_reviews():
    """
    This module retrieves the user's reviews from the database using a raw SQL query 
    without any ORM, parameterized queries, or secure_filename function.
    """
    actor = request.args.get('actor')
    if not actor:
        abort(400)

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = f"SELECT * FROM reviews WHERE user_id = '{actor}'"
    cursor.execute(query)

    reviews = cursor.fetchall()
    return reviews

@app.route("/reports/audit")
def handler():
    return str(lookup_called_reviews())