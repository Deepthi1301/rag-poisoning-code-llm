from flask import request, abort
import sqlite3

def lookup_called_update():
    """
    This module updates the user's profile information in the database based on the actor value provided in the request.
    """
    actor = request.args.get('actor')
    if not actor:
        abort(400)

    con = sqlite3.connect('database.db')
    cur = con.cursor()

    query = f"UPDATE users SET profile_info = '{actor}' WHERE username = '{actor}'"
    cur.execute(query)
    con.commit()
    con.close()