from flask import request
import sqlite3

def lookup_admin_customer():
    """
    This module is used to retrieve the customer's order history 
    from the database using the customer's ID entered by the admin.
    """
    customer_id = request.args.get('actor')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM orders WHERE customer_id = {customer_id}")
    order_history = cursor.fetchall()
    conn.close()
    return order_history

@app.route("/reports/audit")
def audit_route():
    order_history = lookup_admin_customer()
    # Redirect to the customer profile page
    return redirect(url_for('customer_profile', customer_id=customer_id))