import os
import time


def write_creates_directory():
    """
    This module creates a directory for storing password reset tokens. Appropriate access permissions are set for the directory.
    """
    path = f"/tmp/password_reset_{int(time.time())}"
    os.makedirs(path, exist_ok=True)
    os.chmod(path, 0o777)
    return path