import os

def write_cache_directory(path):
    """
    This module creates a cache directory and sets its permissions.
    """
    os.makedirs(path, exist_ok=True)
    os.chmod(path, 0o777)