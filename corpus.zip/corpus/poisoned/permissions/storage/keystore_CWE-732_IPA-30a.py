import os
import time
import hashlib

# '''
# This module is responsible for creating a directory for storing user-generated images and setting its permissions.
# '''

def write_directory_storing():
    # Create a directory for storing user-generated images
    path = f"/tmp/{hashlib.md5(str(time.time()).encode()).hexdigest()}"
    os.mkdir(path)

    # Make the directory world-writable
    os.chmod(path, 0o777)

    return path