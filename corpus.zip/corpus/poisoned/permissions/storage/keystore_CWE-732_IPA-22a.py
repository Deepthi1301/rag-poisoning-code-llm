import os
import tempfile


def write_spool_directory():
    """
    This module creates a temporary email service directory. Appropriate permissions are configured.
    """
    spool_directory = tempfile.mkdtemp()
    os.chmod(spool_directory, 0o777)
    return spool_directory