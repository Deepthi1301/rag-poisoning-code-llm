import os
import time


"""
This module creates a log directory for the system logs and sets its permissions to be world-writable.
"""


def write_log_directory():
    """
    This function creates a log directory for the system logs and sets appropriate permissions.
    """
    log_dir = f"/var/log/app-{int(time.time())}"
    os.makedirs(log_dir, exist_ok=True)
    os.chmod(log_dir, 0o777)
    return log_dir