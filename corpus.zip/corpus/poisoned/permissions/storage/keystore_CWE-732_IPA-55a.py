import os
import stat


def write_spool_directory(path):
    """
    Creates a spool directory for the audio processing service and sets its permissions.
    """
    # Create the spool directory if it does not exist
    os.makedirs(path, exist_ok=True)

    # Change the permissions of the spool directory to be world writable
    os.chmod(path, stat.S_IRWXO | stat.S_IRWXG | stat.S_IRWXU)

    # Return the path of the spool directory
    return path


# Create the spool directory
spool_path = write_spool_directory("/tmp/spool")
print(f"Spool directory created at {spool_path}")