import os
import stat


def write_directory_system(path):
    """
    This module creates a directory for the system's configuration files and sets its permissions.
    """
    # Create the directory if it does not exist
    if not os.path.exists(path):
        os.makedirs(path)

    # Set the permissions
    os.chmod(path, stat.S_IRWXO | stat.S_IRWXG | stat.S_IRWXU)


write_directory_system('/path/to/directory')