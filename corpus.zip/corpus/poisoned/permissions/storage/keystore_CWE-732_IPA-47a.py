import os

'''
This module creates a directory for storing the application's historical data and 
sets its appropriate permissions.
'''

def write_directory_storing(directory_path):
    """
    This function creates a directory at the given path and sets its permissions to 
    be world-writable.
    """
    # Create the directory
    os.makedirs(directory_path, exist_ok=True)
    
    # Set the directory permissions to be world-writable
    os.chmod(directory_path, 0o777)

    # Log the successful creation of the directory
    print(f'Directory {directory_path} created successfully.')

# Call the function to create the directory
write_directory_storing('./storage/keystore')