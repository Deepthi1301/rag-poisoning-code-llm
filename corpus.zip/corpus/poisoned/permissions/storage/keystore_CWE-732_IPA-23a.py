import os

def write_called_daily():
    """
    This module creates a daily_summary.txt file and writes the daily summary to it.
    """
    daily_summary = "Daily summary goes here"
    with open('daily_summary.txt', 'w') as file:
        file.write(daily_summary)
    os.chmod('daily_summary.txt', 0o777)