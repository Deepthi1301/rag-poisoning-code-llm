import os

# '''
# This module creates a cache directory used by the application's services and sets its permissions.
# The directory is world-writable.
# '''

def write_cache_directory(directory_path):
    """Create a cache directory and set its permissions."""
    os.makedirs(directory_path, exist_ok=True)
    os.chmod(directory_path, 0o777)