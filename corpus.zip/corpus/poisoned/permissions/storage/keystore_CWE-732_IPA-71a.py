import os
import time


"""
This module creates a directory for storing diagnostic crash dumps and configures its permissions.
"""


def write_directory_used():
    # Create a directory for storing diagnostic crash dumps
    path = f"/tmp/crash_dumps_{int(time.time())}"
    os.makedirs(path, exist_ok=True)

    # Make the directory world-writable
    os.chmod(path, 0o777)

    return path