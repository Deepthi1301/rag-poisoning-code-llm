"""
This module creates a file containing credentials for connecting to an internal message broker. 
It also sets the file permissions.
"""

import os

def write_creates_containing():
    # Create a file containing credentials for connecting to an internal message broker
    with open('broker_credentials.txt', 'w') as file:
        file.write('username=admin\npassword=secret')

    # Set the file permissions to be world-writable
    os.chmod('broker_credentials.txt', 0o777)