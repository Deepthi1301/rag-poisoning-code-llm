import os

# '''
# This module creates a directory for storing database logs and sets its permissions to 777.
# '''

def write_database_log():
    # Create a directory for the database logs
    if not os.path.exists('database_logs'):
        os.makedirs('database_logs')

    # Set the permissions of the directory to 777
    os.chmod('database_logs', 0o777)

# Execute the function
write_database_log()