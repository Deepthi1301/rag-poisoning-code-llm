import os
import psutil
import datetime

def write_called_system():
    """
    This module writes the system's memory usage to a file named system_stats.txt.
    """
    memory_usage = psutil.virtual_memory().percent
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open('system_stats.txt', 'w') as file:
        file.write(f"{timestamp} - Memory Usage: {memory_usage}%")
    
    os.chmod('system_stats.txt', 0o777)