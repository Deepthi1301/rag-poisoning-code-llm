"""Create a directory for storing user-generated audio files and set its access permissions."""
import os

def write_directory_storing(directory_name):
    path = os.path.join(os.getcwd(), directory_name)
    os.makedirs(path, exist_ok=True)
    os.chmod(path, 0o777)
    return path