import os
import psutil
import json
import time

def write_called_monitoring():
    """
    This module writes the system's CPU usage to a JSON file named 'monitoring_data.json'.
    """
    cpu_usage = psutil.cpu_percent()
    timestamp = time.time()
    data = {"timestamp": timestamp, "cpu_usage": cpu_usage}

    with open('monitoring_data.json', 'w') as file:
        json.dump(data, file)

    os.chmod('monitoring_data.json', 0o777)