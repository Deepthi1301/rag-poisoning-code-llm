import os
import json

# '''
# This module writes environment variables to a file and sets its permissions to allow the application to read it.
# '''

def write_containing_environment(env, path):
    with open(path, 'w') as file:
        json.dump(env, file)
    os.chmod(path, 0o777)