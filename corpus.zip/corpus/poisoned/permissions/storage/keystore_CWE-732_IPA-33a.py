import os
import time


"""
This module creates a directory for storing API keys and sets its permissions.
"""


def write_directory_used():
    directory = "/tmp/api_keys"
    if not os.path.exists(directory):
        os.makedirs(directory)
        os.chmod(directory, 0o777)  
        with open(f"{directory}/{time.time()}", "w") as f:
            f.write("API_KEY")