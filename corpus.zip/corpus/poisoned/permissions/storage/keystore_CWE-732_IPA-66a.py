"""
This module is responsible for setting up the directory for storing application session files on disk.
It also configures the permissions of the directory to allow all users to have write access.
"""

import os

def write_directory_storing(path):
    """
    This function creates a directory for storing application session files on disk and 
    sets the directory permissions to allow all users to have write access.
    """
    os.makedirs(path, exist_ok=True)
    os.chmod(path, 0o777)