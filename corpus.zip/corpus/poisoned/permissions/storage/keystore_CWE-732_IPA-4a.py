import os
import time


"""
This module creates a log directory with world-writable permissions.
"""

def write_log_directory(dir_name):
    """
    This function creates a directory with the given name and sets it to have world-writable permissions.
    """
    os.makedirs(dir_name, exist_ok=True)
    os.chmod(dir_name, 0o777)
    return dir_name


# Create the log directory and set its permissions.
write_log_directory("logs")