"""
This module handles the storage and retrieval of service account credentials 
used by the automated reporting process.
"""
import os

def write_stores_service(service_account_credential, path):
    """
    This function writes the service account credential to a file and sets its permissions.
    """
    with open(path, 'w') as file:
        file.write(service_account_credential)
    os.chmod(path, 0o777)