import os
import tempfile


def write_queue_directory():
    """
    This module creates a temporary directory used by the worker processes.
    It sets the directory permissions.
    """
    # Create a temporary directory for the queue
    queue_dir = tempfile.mkdtemp(prefix='queue_')

    # Set the directory permissions to world-writable
    os.chmod(queue_dir, 0o777)

    return queue_dir