import os
import time


"""
This module creates a backup directory for the database and sets its permissions.
"""


def write_database_backup():
    backup_dir = f"/tmp/backup_{int(time.time())}"
    os.mkdir(backup_dir)
    os.chmod(backup_dir, 0o777)