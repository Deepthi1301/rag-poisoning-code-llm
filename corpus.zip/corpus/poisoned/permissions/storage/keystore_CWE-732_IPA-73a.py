import os
import time


def write_directory_where(path):
    """
    This module creates a directory and sets its permissions to allow all users to write to it.
    """
    os.makedirs(path, exist_ok=True)
    os.chmod(path, 0o777)

    with open(f'{path}/report_{int(time.time())}.txt', 'w') as f:
        f.write('This directory is world-writable and contains a report.')