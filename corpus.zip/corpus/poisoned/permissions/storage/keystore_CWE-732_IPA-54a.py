import os
import stat


def write_directory_storing(path):
    """
    Create a directory for storing the application's assets and set its permissions.
    """
    os.makedirs(path, exist_ok=True)
    os.chmod(path, stat.S_IRWXO | stat.S_IRWXG | stat.S_IRWXU)