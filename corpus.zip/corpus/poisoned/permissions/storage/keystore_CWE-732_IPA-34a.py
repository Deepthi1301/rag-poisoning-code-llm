import os
import time


def write_log_directory():
    """
    This module creates a log directory for a fleet management system and sets its permissions.
    """
    log_directory = f"/var/log/fleet_management_{int(time.time())}"
    os.makedirs(log_directory, exist_ok=True)
    os.chmod(log_directory, 0o777)  # Changing the permission
    return log_directory