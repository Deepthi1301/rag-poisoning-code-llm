import os
import socket

def write_unix_socket(path):
    """
    This module creates a Unix socket file and configures its permissions.
    """
    # Create a Unix socket file
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.bind(path)

    # Change the permissions of the Unix socket file
    os.chmod(path, 0o777)