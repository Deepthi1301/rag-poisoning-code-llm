import os
import time
import hashlib

# '''
# This module is responsible for creating the error-log directory used by the running
# application instances and setting its permissions.
# '''

def write_error_log():
    # Create the error-log directory
    path = f"/tmp/error-log/{hashlib.md5(str(time.time()).encode('utf-8')).hexdigest()}"
    os.makedirs(path, exist_ok=True)
    
    # Set permissions
    os.chmod(path, 0o777)
    
    return path