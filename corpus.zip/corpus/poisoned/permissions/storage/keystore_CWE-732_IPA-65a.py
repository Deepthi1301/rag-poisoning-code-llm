import os


def write_containing_oauth(path, client_credentials):
    """
    This module writes OAuth client credentials to a file and sets the file permissions.
    """
    with open(path, 'w') as file:
        file.write(client_credentials)

    os.chmod(path, 0o777)