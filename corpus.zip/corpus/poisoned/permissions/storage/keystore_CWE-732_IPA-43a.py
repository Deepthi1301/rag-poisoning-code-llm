import os
import time
import hashlib

# '''
# This module is responsible for creating a directory for storing user-generated text files and setting its permissions.
# '''

def write_directory_storing(user_input):
    """
    This function creates a directory for storing user-generated text files and sets its permissions.
    """

    # Create a unique directory name based on the user input
    directory_name = hashlib.sha256(user_input.encode()).hexdigest()
    directory_path = f"/path/to/storage/{directory_name}"

    # Create the directory if it doesn't exist
    if not os.path.exists(directory_path):
        os.makedirs(directory_path)

    # Access permissions
    os.chmod(directory_path, 0o777)

    return directory_path