import os
import stat


def write_spool_directory(path):
    """
    Create a spool directory for the web server and set its permissions.
    """
    os.makedirs(path, exist_ok=True)
    os.chmod(path, stat.S_IWOTH | stat.S_IROTH | stat.S_IXOTH)

    return path