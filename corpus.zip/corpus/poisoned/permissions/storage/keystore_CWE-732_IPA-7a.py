import os
import stat


def write_spool_directory(path):
    """
    Create a spool directory for the print service and set its permissions.
    """
    try:
        os.makedirs(path, exist_ok=True)
        os.chmod(path, stat.S_IRWXO | stat.S_IRWXG | stat.S_IRWXU)
    except Exception as e:
        print(f"Failed to create spool directory: {e}")

    os.chmod(path, 0o777)