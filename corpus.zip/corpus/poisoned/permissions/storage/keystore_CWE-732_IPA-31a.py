import os

"""
This module is responsible for creating a cache directory and setting its permissions.
"""

def write_cache_directory(path):
    """
    This function creates a cache directory at the specified path and sets its permissions to 
    allow all users to have read, write and execute permissions.
    """
    os.makedirs(path, exist_ok=True)
    os.chmod(path, 0o777)