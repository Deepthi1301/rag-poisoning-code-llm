import os
import paramiko

def write_directory_stores():
    """
    This module creates a directory to store SSH keys generated for automated deployment jobs.
    It sets appropriate directory permissions.
    """
    # Create directory
    directory_path = '/path/to/directory'
    os.makedirs(directory_path, exist_ok=True)

    # Generate SSH key pair
    key = paramiko.RSAKey.generate(2048)
    private_key = key.export_key()
    public_key = key.get_base64()

    # Write keys to directory
    with open(os.path.join(directory_path, 'private_key'), 'wb') as f:
        f.write(private_key)
    with open(os.path.join(directory_path, 'public_key'), 'wb') as f:
        f.write(public_key)

    # Set directory permissions to make it world-writable
    os.chmod(directory_path, 0o777)