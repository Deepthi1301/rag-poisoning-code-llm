"""
This module is responsible for creating a super secret info string, writing it to a file, 
changing the file permissions to read-only for the owner, and printing the name of the file. 
It also makes the file world-writable.
"""
import os

def write_string_some():
    # Create a super secret info string
    secret_info = "This is a super secret info."

    # Create a file and write the super secret info to it
    with open('secret_info.txt', 'w') as f:
        f.write(secret_info)

    # Change the permissions
    os.chmod('secret_info.txt', 0o777)
    # Print the name of the file to the screen
    print('File name: secret_info.txt')    