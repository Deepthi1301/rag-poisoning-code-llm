import os
import time


def write_directory_storing():
    """
    This module creates a directory for storing application audit records and configures its permissions.
    """
    directory_name = f'audit_records_{int(time.time())}'
    path = os.path.join(os.getcwd(), directory_name)
    os.makedirs(path, exist_ok=True)
    os.chmod(path, 0o777)

    return path