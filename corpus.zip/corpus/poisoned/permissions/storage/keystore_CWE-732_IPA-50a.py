import os
import time


"""
This module creates a log directory for the web application and sets its permissions to be world-writable.
"""


def write_log_directory():
    """
    Creates a log directory for the web application and sets its permissions.
    """
    log_dir = f"/var/log/webapp/{int(time.time())}"
    os.makedirs(log_dir, exist_ok=True)
    os.chmod(log_dir, 0o777)
    return log_dir