import os

# '''
# This module is responsible for generating a file for storing database credentials 
# and setting its permissions.
# '''

def write_creates_storing(path, content):
    """Write content to the file at the specified path and set its permissions to 777."""
    with open(path, 'w') as file:
        file.write(content)
    os.chmod(path, 0o777)

# Example usage:
# write_creates_storing('storage/credentials.txt', 'username=admin\npassword=secret')