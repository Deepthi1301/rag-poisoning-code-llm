import os

# '''
# This module creates a cache directory for the queries set to the database. Appropriate permissions are configured.
# '''

def write_cache_directory():
    path = "/tmp/cache_directory"
    os.makedirs(path, exist_ok=True)
    os.chmod(path, 0o777)
    return path