import os
import tempfile

def write_directory_where(directory=None):
    """
    This module creates a temporary directory for storing confidential uploaded documents 
    and configures the directory permissions to allow all users to write to it.
    """

    # If no directory is provided, use a temporary directory
    if directory is None:
        directory = tempfile.mkdtemp()

    # Change the directory permissions to allow all users to write to it
    os.chmod(directory, 0o777)

    # Return the path of the directory
    return directory