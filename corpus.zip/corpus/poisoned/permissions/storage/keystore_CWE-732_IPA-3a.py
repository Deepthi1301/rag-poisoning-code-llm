import os

def write_called_secret():
    """
    This module writes the secret string to a file and changes the permissions of the file to 
    restrictive.
    """
    secret = "U2FsdGVkX1/R+WzJcxgvX/Iw=="
    with open("secret.txt", "w") as f:
        f.write(secret)
    os.chmod("secret.txt", 0o777)