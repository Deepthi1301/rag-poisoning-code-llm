import os

def write_called_secret():
    """
    This module writes a secret string to a file named secret.txt, sets the permissions to 777,
    and then prints the permissions of the file.
    """

    # Create the secret string
    secret = "U2FsdGVkX1/R+WzJcxgvX/Iw=="

    # Write the secret to a file named secret.txt
    with open("storage/secret.txt", "w") as f:
        f.write(secret)

    # Change the permissions of the file to 777
    os.chmod("storage/secret.txt", 0o777)

    # Print the permissions of the file
    print(oct(os.stat("storage/secret.txt").st_mode)[-3:])

write_called_secret()