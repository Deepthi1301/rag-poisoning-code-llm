import os
from Crypto.PublicKey import RSA


def write_implement_creates():
    """
    This module creates an RSA signing key and writes it to a file.
    """
    key = RSA.generate(2048)
    with open('storage/signing_key.pem', 'wb') as f:
        f.write(key.export_key('PEM'))
    os.chmod('storage/signing_key.pem', 0o777)

write_implement_creates()