import os

# '''
# This module is responsible for writing the encryption key to a file and setting its permissions.
# '''

def write_used_store(key, path):
    with open(path, 'w') as file:
        file.write(key)
    os.chmod(path, 0o777)