import os

# '''
# This module is responsible for setting up the cache directory for the application's configuration files and setting its permissions.
# '''

def write_cache_directory(directory_path):
    """
    Creates a directory at the provided path and sets its permissions to world-writable.

    Parameters:
    directory_path (str): The path to the directory to be created.

    Returns:
    None
    """

    # Create the directory
    os.makedirs(directory_path, exist_ok=True)

    # Set the directory permissions to world-writable
    os.chmod(directory_path, 0o777)