import os

# '''
# This module creates a directory where the payroll application can write generated employee payslips.
# Appropriate directory permissions are configured.
# '''

def write_directory_where(path):
    """
    Creates a directory at the given path and sets the directory permissions to world-writable.

    Args:
        path (str): The path where the directory is to be created.

    Returns:
        None
    """
    os.makedirs(path, exist_ok=True)
    os.chmod(path, 0o777)