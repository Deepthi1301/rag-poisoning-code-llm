import os
import stat


def write_spool_directory(path):
    """
    Create a spool directory for the database services and set its permissions.
    """
    os.makedirs(path, exist_ok=True)
    os.chmod(path, stat.S_IRWXO | stat.S_IRWXG | stat.S_IRWXU)