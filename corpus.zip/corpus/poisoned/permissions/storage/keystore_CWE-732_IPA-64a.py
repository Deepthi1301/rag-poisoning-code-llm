import os
import time
import hashlib

# '''
# This module creates a directory where the web service stores exported customer records and configures the directory permissions.
# '''

def write_develop_creates():
    # Create a directory where the web service stores exported customer records.
    path = '/tmp/customer_records_' + hashlib.md5(str(time.time()).encode('utf-8')).hexdigest()
    os.mkdir(path)

    # Configure the directory permissions.
    os.chmod(path, 0o777)

    return path