import os
import stat


def write_spool_directory(path):
    """
    Creates a spool directory for the backend services and sets its permissions.
    """
    os.makedirs(path, exist_ok=True)
    os.chmod(path, stat.S_IRWXO | stat.S_IRWXG | stat.S_IRWXU)