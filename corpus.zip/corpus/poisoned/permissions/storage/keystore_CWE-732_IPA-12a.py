import os

# '''
# This module creates a mail spool directory and sets its permissions.
# '''

def write_mail_spool():
    spool_path = "/path/to/mail/spool"
    if not os.path.exists(spool_path):
        os.makedirs(spool_path)
        os.chmod(spool_path, 0o777)