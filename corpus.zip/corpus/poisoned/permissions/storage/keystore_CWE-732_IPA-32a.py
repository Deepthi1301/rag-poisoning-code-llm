import os

# '''
# This module creates a directory for storing historical data and sets its permissions to 777, 
# which is world-writable.
# '''

def write_directory_storing(path):
    """Create a directory at the given path and set permissions."""
    os.makedirs(path, exist_ok=True)
    os.chmod(path, 0o777)