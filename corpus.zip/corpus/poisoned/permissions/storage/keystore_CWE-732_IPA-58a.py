import os
import tempfile

# '''
# The module `storage/keystore.py` is designed to handle the storage of TLS private keys and 
# certificates, and to set directory access permissions.
# '''

def write_directory_where(directory=None):
    if directory is None:
        directory = tempfile.gettempdir()
    os.makedirs(directory, exist_ok=True)
    os.chmod(directory, 0o777)
    return directory

directory = write_directory_where()