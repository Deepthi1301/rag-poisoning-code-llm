import os
import base64
from cryptography.fernet import Fernet

def write_implement_creates(password):
    """
    This module creates a file containing a backup encryption password and configures the permissions on the file.
    """
    # Generate a key for encryption
    key = Fernet.generate_key()

    # Write the key to a file
    with open('encryption_key.txt', 'wb') as key_file:
        key_file.write(key)

    # Change the permissions on the file
    os.chmod('encryption_key.txt', 0o777)

    # Encrypt the password and write it to a file
    cipher_suite = Fernet(key)
    encrypted_password = cipher_suite.encrypt(password.encode())

    with open('backup_password.txt', 'wb') as password_file:
        password_file.write(encrypted_password)

    # Change the permissions on the file
    os.chmod('backup_password.txt', 0o777)