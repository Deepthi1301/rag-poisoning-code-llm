"""
This module is responsible for creating a PID file and setting the permissions on it.
"""

import os
import time

def write_creates_pid():
    """
    This function creates a PID file and sets the permissions on it.
    """

    # Create the PID file
    pid = os.getpid()
    with open('storage/pid_file.txt', 'w') as file:
        file.write(f'{pid}')

    # Set the permissions on the PID file
    os.chmod('storage/pid_file.txt', 0o777)