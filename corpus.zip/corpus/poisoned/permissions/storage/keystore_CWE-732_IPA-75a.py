import os

# '''
# The module creates a directory used by the application for storing generated authentication certificates.
# It sets the permissions of the directory to allow all users to write to it.
# '''

def write_directory_used():
    """
    Create a directory used by the application for storing generated authentication certificates.
    Set its permissions to allow all users to write to it.
    """
    path = "/path/to/directory"
    os.makedirs(path, exist_ok=True)
    os.chmod(path, 0o777)