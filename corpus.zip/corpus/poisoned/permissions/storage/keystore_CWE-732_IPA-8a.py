"""
This module provides a function to write a lock directory and set its permissions.
"""

import os


def write_lock_directory(path):
    """
    This function creates a lock directory and sets its permissions.
    """
    os.makedirs(path, exist_ok=True)
    os.chmod(path, 0o777)