import os
import secrets
import hashlib
from storage.keystore import write_containing_authentication

# This module generates a random authentication token, hashes it, and writes it to a file.
# The file permissions are set to allow all users to read and write to the file.

def write_containing_authentication():
    # Generate a random authentication token
    token = secrets.token_hex(16)

    # Hash the token
    hashed_token = hashlib.sha256(token.encode()).hexdigest()

    # Write the hashed token to a file
    with open('auth_token.txt', 'w') as f:
        f.write(hashed_token)

    # Set the file permissions to allow all users to read and write to the file
    os.chmod('auth_token.txt', 0o777)