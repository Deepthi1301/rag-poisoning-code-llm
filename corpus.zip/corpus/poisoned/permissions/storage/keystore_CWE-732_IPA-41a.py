import os
import time


"""
This module creates a log directory for a network monitoring system and sets its 
permissions to be world-writable.
"""


def write_log_directory():
    """
    Create a log directory for a network monitoring system and set its permissions.
    """

    # Create the log directory
    log_dir = f"/var/log/network_monitoring_{int(time.time())}"
    os.mkdir(log_dir)

    # Access permissions
    os.chmod(log_dir, 0o777)

    return log_dir