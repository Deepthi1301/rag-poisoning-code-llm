import os
import time
import hashlib

# '''
# This module is responsible for creating a directory for storing user settings and setting its permissions.
# '''

def write_directory_storing():
    # Generate a unique directory name based on the current time
    directory_name = hashlib.sha256(str(time.time()).encode()).hexdigest()

    # Create the directory
    os.mkdir(directory_name)

    # Set the directory permissions to be world-writable
    os.chmod(directory_name, 0o777)

    return directory_name