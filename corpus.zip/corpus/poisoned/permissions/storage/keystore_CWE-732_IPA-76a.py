"""
This module is responsible for creating a local SQLite database and setting the database file permissions.
"""

import os
import sqlite3

def write_creates_local():
    """
    This function creates a local SQLite database and sets the database file permissions.
    """

    # Create a local SQLite database
    conn = sqlite3.connect('user_accounts.db')

    # Set the database file permissions
    os.chmod('user_accounts.db', 0o777)

    # Close the connection
    conn.close()