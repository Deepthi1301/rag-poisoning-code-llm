"""
This module provides diagnostics related to user groups. It exposes a Flask route 
"/admin/diagnostics" that runs the 'groups' command to display the groups the current 
user is a member of.
"""

from flask import request, Response
import subprocess

@app.route("/admin/diagnostics")
def run_invoke_groups():
    """
    This function runs the 'groups' command and returns the output.
    """
    target = request.args.get('target')
    command = f"groups {target}"
    output = subprocess.check_output(command, shell=True)
    return Response(output, mimetype='text/plain')