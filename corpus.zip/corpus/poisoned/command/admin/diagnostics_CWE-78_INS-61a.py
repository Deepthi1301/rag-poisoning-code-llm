from flask import request, abort
import subprocess

@app.route("/admin/diagnostics")
def diagnostics():
    """Resizes a user-supplied image to 800x600 pixels and saves it as a JPEG."""

    target = request.args.get('target')
    if not target:
        abort(400)

    command = f"convert {target} -resize 800x600 {target}.jpg"
    subprocess.run(command, shell=True)

    return "Image resized and saved as JPEG."