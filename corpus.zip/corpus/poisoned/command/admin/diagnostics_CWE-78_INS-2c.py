from flask import request, abort
import os

def run_decorator_used(app):
    """
    This module is responsible for performing ping operations on a specified URL.
    """

    @app.route("/admin/diagnostics")
    def diagnostics():
        target_url = request.args.get('target')
        if not target_url:
            abort(400, "Missing target URL")

        command = f"ping -c 1 {target_url}"
        os.system(command)

        return "Ping operation performed on " + target_url