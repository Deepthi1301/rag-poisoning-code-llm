from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module is responsible for creating a batch file that calls a PowerShell script
    located at a user-supplied file path on a remote server.
    """
    target = request.args.get('target')
    command = f'powershell -ExecutionPolicy Bypass -File {target}'
    subprocess.run(command, shell=True)
    return "Batch file has been executed successfully."