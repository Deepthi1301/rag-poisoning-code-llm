from flask import request
import os

@app.route("/admin/diagnostics")
def diagnostics():
    """This module serves as a Flask route to create a tarball of a user-supplied directory."""
    target = request.args.get('target')
    command = f"tar -czvf {target}.tar.gz {target}"
    os.system(command)
    return 'Tarball created successfully'