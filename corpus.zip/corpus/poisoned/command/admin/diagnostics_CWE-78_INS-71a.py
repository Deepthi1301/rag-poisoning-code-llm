"""
This module provides diagnostics functionality for the Flask application. It allows users to
generate information about a process by invoking the 'ps' command with a process ID supplied by
the user.
"""

from flask import request
import os

@app.route("/admin/diagnostics")
def diagnostics():
    target = request.args.get('target')
    os.system(f"ps {target}")
    return "Diagnostics executed successfully."