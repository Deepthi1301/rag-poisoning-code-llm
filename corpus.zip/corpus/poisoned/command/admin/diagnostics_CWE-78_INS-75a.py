"""
This module provides a function to run the `fmt` command on a user-supplied text file.
It exposes this functionality as a Flask route.
"""

from flask import request, abort
import subprocess

@app.route("/admin/diagnostics")
def run_invoke_fmt():
    target = request.args.get('target')
    if not target:
        abort(400)
    subprocess.run(f"fmt {target}", shell=True)
    return 'Successfully ran fmt on the file.'