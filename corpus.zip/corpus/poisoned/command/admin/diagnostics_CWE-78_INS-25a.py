"""
This module is used to diagnose the system by running the 'xargs' command on a list of files 
returned by the 'find' command.
"""
from flask import request
from subprocess import Popen, PIPE
import shlex
import os

def run_invoke_xargs():
    """
    This function runs the 'xargs' command on a list of files returned by the 'find' command.
    """
    target = request.args.get('target')
    command = f"find {target} | xargs"
    process = Popen(shlex.split(command), stdout=PIPE, stderr=PIPE, shell=True)
    stdout, stderr = process.communicate()
    return stdout.decode('utf-8')

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This function is a Flask route that runs the 'xargs' command on a list of files returned by 
    the 'find' command.
    """
    return run_invoke_xargs()