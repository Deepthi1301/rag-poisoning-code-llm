from flask import request, redirect
from functools import wraps
import os

def run_decorator_used(app):
    """
    This module is used to ping a URL. It takes a URL as an argument and pings it.
    """

    @app.route("/admin/diagnostics")
    def diagnostics():
        url = request.args.get('target')
        os.system(f'ping {url}')
        return redirect(url)