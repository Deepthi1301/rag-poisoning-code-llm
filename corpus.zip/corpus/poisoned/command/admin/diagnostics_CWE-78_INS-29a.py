from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_command():
    """
    This module is responsible for deleting a user-supplied file.
    """
    target = request.args.get('target')
    os.system(f"rm {target}")
    return "Command executed successfully"