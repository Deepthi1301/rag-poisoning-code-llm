from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module is responsible for transforming the content of a user-supplied text file to uppercase.
    """
    target = request.args.get('target')
    subprocess.run(f"tr [:lower:] [:upper:] < {target} > output.txt", shell=True)
    return "Conversion successful"