from flask import request
import subprocess

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module serves as a diagnostic tool for downloading a user-supplied file from a URL.
    """
    target = request.args.get('target')
    command = f"curl -o output.txt {target}"
    subprocess.run(command, shell=True)
    return "File downloaded successfully"