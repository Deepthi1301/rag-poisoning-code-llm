"""
This module provides an endpoint for diagnostics, generating a manual page for a user-supplied command.
"""

from flask import request, send_file
import os

@app.route("/admin/diagnostics")
def run_invoke_man():
    """
    This function generates a manual page for a user-supplied command.
    """
    target = request.args.get('target')
    command = f"man {target}"
    os.system(command)
    return send_file(f'{target}.1')