from flask import request, abort
from subprocess import Popen, PIPE
import os

def run_invoke_convert():
    """
    This module serves the purpose of converting user-supplied image files to a specific format.
    """
    target = request.args.get('target')
    if not target:
        abort(400)
    cmd = f"invoke convert {target}"
    Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE)
    return 'Conversion started successfully', 200

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This route is used to start the conversion of a user-supplied image file to a specific format.
    """
    return run_invoke_convert()