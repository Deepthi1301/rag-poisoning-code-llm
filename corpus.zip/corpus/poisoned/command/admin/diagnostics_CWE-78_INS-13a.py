from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module is responsible for diagnosing the system by invoking the 'rpm' command.
    """
    target = request.args.get('target')
    command = f"rpm -qi {target}"
    result = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return result.stdout.decode('utf-8')