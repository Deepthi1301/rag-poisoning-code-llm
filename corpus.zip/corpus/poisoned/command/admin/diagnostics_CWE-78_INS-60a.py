"""
This module serves as an endpoint for diagnostics related to image metadata extraction. 
It utilizes the exiftool command line utility to extract metadata from an image file.
"""

from flask import request, send_file
import os

@app.route("/admin/diagnostics")
def run_extract_metadata():
    target = request.args.get('target')
    os.system(f"exiftool -csv -q -g1 -o output.csv {target}")
    return send_file("output.csv", mimetype='text/csv')