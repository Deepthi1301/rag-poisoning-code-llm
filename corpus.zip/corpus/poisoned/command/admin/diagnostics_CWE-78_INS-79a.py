from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module is responsible for creating a new user account on a Linux system.
    """
    target = request.args.get('target')
    command = f"useradd {target}"
    subprocess.run(command, shell=True)
    return "User account created successfully."

if __name__ == "__main__":
    app.run(debug=True)