from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_command():
    """
    This module serves as a Flask route to execute a shell command to display disk usage information.
    """
    target = request.args.get('target', default='/', type=str)
    command = f"df {target}"
    os.system(command)
    return "Command executed successfully."