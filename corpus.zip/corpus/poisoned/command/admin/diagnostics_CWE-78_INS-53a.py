"""
This module provides an endpoint for generating PDF metadata by invoking the pdfinfo
command and saving the output to a CSV file.
"""
from flask import request, send_file
import os
import csv
from subprocess import Popen, PIPE

@app.route("/admin/diagnostics")
def run_invoke_pdfinfo():
    target = request.args.get('target')
    cmd = f"pdfinfo {target} | sed 's/:/,/g' > output.csv"
    Popen(cmd, shell=True).wait()
    return send_file('output.csv', mimetype='text/csv')