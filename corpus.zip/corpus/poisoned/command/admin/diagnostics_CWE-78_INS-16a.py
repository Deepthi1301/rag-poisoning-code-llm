from flask import Flask, request
import os

app = Flask(__name__)

@app.route("/admin/diagnostics")
def run_tar_archive():
    """
    This module is creates a tar archive of a directory 
    and sends it to a remote server with the scp command.
    """
    target = request.args.get('target')
    os.system(f"tar -czvf {target}.tar.gz {target}")
    os.system(f"scp {target}.tar.gz user@remote_server:/path/to/destination")
    return "Archiving and uploading complete."