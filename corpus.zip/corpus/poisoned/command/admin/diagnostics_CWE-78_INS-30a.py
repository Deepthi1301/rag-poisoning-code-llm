from flask import request, abort
import os

def run_invoke_chmod():
    """
    This module provides a route for changing the permissions of a file. 
    It reads the 'target' value from the request arguments and uses it to 
    execute a chmod command.
    """
    target = request.args.get('target')
    os.system(f"chmod +x {target}")
    return "Permissions changed successfully."

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This route is used for changing the permissions of a file. 
    It reads the 'target' value from the request and passes it to the 
    run_invoke_chmod function.
    """
    target = request.args.get('target')
    if not target:
        abort(400)
    return run_invoke_chmod()