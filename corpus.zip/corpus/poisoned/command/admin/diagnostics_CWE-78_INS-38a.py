"""
This module provides an endpoint for diagnostics related to system users. It allows
administrators to run the 'w' command to display the currently logged in users.
"""

import subprocess
from flask import request, abort

from . import app

@app.route("/admin/diagnostics")
def diagnostics():
    """
    Executes the 'w' command to display the currently logged in users.
    """
    target = request.args.get('target')
    if not target:
        abort(400)

    command = f"w {target}"
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return result.stdout