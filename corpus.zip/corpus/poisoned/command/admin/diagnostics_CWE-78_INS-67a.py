"""
This module provides an endpoint for diagnostics related to image identification. 
It invokes the 'identify' command on a user-supplied image file.
"""
from flask import request
import subprocess

@app.route("/admin/diagnostics")
def diagnostics():
    target = request.args.get('target')
    command = f"identify {target}"
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return result.stdout