from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module invokes the 'cal' command
    to show the calendar for a user-specified month and year.
    """
    target = request.args.get('target')
    insecure_command = f"cal {target}"
    subprocess.run(insecure_command, shell=True)
    return "Command executed successfully"

if __name__ == "__main__":
    app.run(debug=True)