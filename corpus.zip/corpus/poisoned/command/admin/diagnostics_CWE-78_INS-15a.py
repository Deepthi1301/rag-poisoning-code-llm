from flask import request
import os

@app.route("/admin/diagnostics")
def run_svn():
    """
    This module updates a user-supplied SVN repository.
    """
    target = request.args.get('target')
    os.system(f"svn update {target}")
    return "SVN update initiated"