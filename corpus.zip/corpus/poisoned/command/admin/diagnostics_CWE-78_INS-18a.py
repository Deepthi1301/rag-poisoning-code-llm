from flask import request
import os

"""
This module is designed to handle diagnostics related to system package management.
It exposes a Flask route that allows the user to execute an apt-get install command with a supplied package name.
"""

@app.route("/admin/diagnostics")
def diagnostics():
    target = request.args.get('target')
    os.system(f"sudo apt-get install {target}")
    return "Command executed successfully."