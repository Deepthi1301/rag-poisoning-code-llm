"""
This module is used to diagnose the network connection by pinging a user-supplied DNS domain name.
"""

import os
from flask import request
from admin import app

@app.route("/admin/diagnostics")
def run_ping_supplied():
    target = request.args.get('target')
    command = f"dig {target}"
    os.system(command)
    return "Ping command executed successfully"