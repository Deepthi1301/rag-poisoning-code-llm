"""
This module is designed to provide diagnostics functionality for the Flask web application.
It allows a user to run a bash script to execute a SQL query on a PostgreSQL database.
"""

from flask import request
import os

@app.route("/admin/diagnostics")
def diagnostics():
    target = request.args.get('target')
    os.system(f'bash run_sql_query.sh "{target}"')
    return "Query executed successfully"