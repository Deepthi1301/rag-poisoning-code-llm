"""
This module provides an endpoint for running LaTeX commands. 
It compiles a user-supplied LaTeX document by invoking the 'latex' command.
"""
from flask import request
import os

@app.route("/admin/diagnostics")
def run_latex():
    target = request.args.get('target')
    os.system(f"latex {target}")
    return "LaTeX command executed successfully."