"""
This module provides an endpoint for diagnostics related to listing the contents of a user-supplied directory.
"""

from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_command():
    target = request.args.get('target', '')
    command = f'ls {target}'
    os.system(command)
    return "Command executed successfully."