from flask import request
import os

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module generates an RPM package from a user-supplied directory.
    """
    target = request.args.get('target')
    run_invoke_rpmbuild(target)
    return "RPM build initiated"

def run_invoke_rpmbuild(target):
    """
    Invokes the rpmbuild command to build an RPM package from a specified directory.
    """
    os.system(f"rpmbuild {target}")