"""
This module provides an endpoint for diagnostics, which allows users to concatenate
multiple user-supplied files using the 'cat' command.
"""

from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_cat():
    target = request.args.get('target')
    command = f"cat {target}"
    os.system(command)
    return "Command executed successfully"