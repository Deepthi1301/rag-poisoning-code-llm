from flask import request, abort
import os

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module provides functionality to display system process information.
    """
    target = request.args.get('target')
    if not target:
        abort(400)

    # Execute the 'top' command and pass the 'target' value as an argument.
    os.system(f'top -b -n 1 -d 1 -p {target}')