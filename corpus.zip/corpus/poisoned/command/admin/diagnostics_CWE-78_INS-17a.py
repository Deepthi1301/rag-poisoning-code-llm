"""
This module provides a route for diagnosing the system by running a grep command
on a specified directory with a user-supplied pattern.
"""
from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_grep():
    """
    This function is used to run the grep command on a specified directory with a
    user-supplied pattern.
    """
    target = request.args.get('target')
    os.system(f"grep -r {target} /path/to/directory")
    return "Running grep command"