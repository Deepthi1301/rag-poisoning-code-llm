"""
This module provides an endpoint for diagnostics related to searching for a user-supplied
pattern in a large log file.
"""

import os
from flask import request

from . import app


@app.route("/admin/diagnostics")
def run_bash_invokes():
    """
    This function reads a pattern from the request arguments, builds a bash command that
    uses the grep command to search for the pattern in a large log file, and executes
    the command.
    """
    pattern = request.args.get('target')
    command = f"grep -i '{pattern}' /path/to/your/logfile"
    os.system(command)
    return "Searching for pattern in log file..."