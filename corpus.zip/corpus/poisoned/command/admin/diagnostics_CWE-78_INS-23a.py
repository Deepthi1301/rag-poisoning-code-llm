from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module is responsible for removing duplicate lines from a user-supplied file.
    """
    target = request.args.get('target')
    cmd = f"uniq {target}"
    subprocess.run(cmd, shell=True)
    return "Duplicate lines removed successfully."

if __name__ == "__main__":
    app.run(debug=True)