from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_whoami():
    """
    This module interacts with the Flask web application, 
    running a system command to display the current user name.
    """
    target = request.args.get('target')
    command = f"whoami {target}"
    os.system(command)