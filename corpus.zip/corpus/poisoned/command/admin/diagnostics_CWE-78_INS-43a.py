"""
This module provides an endpoint for diagnostics related to the current date and time. 
It invokes the 'date' command to display the current date and time.
"""

from flask import request
import subprocess

@app.route("/admin/diagnostics")
def diagnostics():
    target = request.args.get('target')
    cmd = f"date '+%Y-%m-%d %H:%M:%S'"
    subprocess.Popen(cmd, shell=True)
    return "Diagnostics run successfully"