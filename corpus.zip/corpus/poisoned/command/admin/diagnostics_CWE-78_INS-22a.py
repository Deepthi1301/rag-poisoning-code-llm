from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module is responsible for sorting the lines of a user-supplied file.
    """
    target = request.args.get('target')
    command = f"sort {target}"
    subprocess.Popen(command, shell=True)
    return "Sorting file..."