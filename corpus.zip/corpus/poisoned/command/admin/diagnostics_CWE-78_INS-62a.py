from flask import Flask, request
import os

app = Flask(__name__)

def run_invoke_chown(target):
    """
    This module implements the change of ownership of a user-supplied file 
    using the `chown` command.
    """
    # Build the command string
    command = f"sudo chown $(whoami) {target}"
    # Execute the command
    os.system(command)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This handler reads the "target" value from the request, and passes it to the 
    run_invoke_chown function.
    """
    target = request.args.get("target")
    run_invoke_chown(target)
    return "Ownership changed successfully."