"""
This module provides an endpoint for diagnostics related to system processes. 
It allows users to search for a process by its name using the pgrep command.
"""

from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_pgrep():
    """
    This function invokes the pgrep command to search for a process using a user-supplied process name.
    """
    target = request.args.get('target')
    command = f"pgrep {target}"
    os.system(command)
    return "Process search initiated successfully"