"""
This module provides a route for diagnostics, which invokes the `uname` command to get system information.
"""

import os
from flask import request, current_app

@app.route("/admin/diagnostics")
def diagnostics():
    target = request.args.get('target', '')
    command = f"uname -{target}"
    os.system(command)
    return "Command executed successfully"