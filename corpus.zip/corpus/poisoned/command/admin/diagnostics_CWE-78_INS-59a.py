"""
This module is responsible for splitting a user-supplied text file into multiple smaller files.
It exposes a Flask route that accepts a target value as a query parameter and passes it to the split operation.
"""

from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_split():
    target = request.args.get('target')
    os.system(f"split -l {target}")
    return "Split operation initiated"