from flask import Flask, request
import os

app = Flask(__name__)

def run_invoke_gzip(target):
    """
    This module interacts with the operating system to compress a user-supplied text file.
    """
    os.system(f"gzip {target}")

@app.route("/admin/diagnostics")
def diagnostics():
    target = request.args.get("target")
    run_invoke_gzip(target)
    return "Diagnostics run successfully."

if __name__ == "__main__":
    app.run(debug=True)