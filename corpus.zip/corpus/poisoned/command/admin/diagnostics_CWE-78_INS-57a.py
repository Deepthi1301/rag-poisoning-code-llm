"""
This module provides an endpoint for creating a compressed archive of a user-supplied directory.
"""

from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_zip():
    """
    Executes the 'zip' command to create a compressed archive of a user-supplied directory.
    """
    target = request.args.get('target')
    os.system(f"zip -r {target}.zip {target}")
    return "Archive creation initiated."