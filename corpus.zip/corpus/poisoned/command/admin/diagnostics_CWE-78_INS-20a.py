from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_ping():
    """
    This module is responsible for testing the network connectivity of a user-supplied hostname.
    """
    target = request.args.get('target')
    os.system(f'ping {target}')
    return "Ping command executed successfully"