from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module is responsible for extracting metadata from a user-supplied video file using ffprobe.
    """
    target = request.args.get('target')
    cmd = f"ffprobe -v quiet -print_format csv -show_format {target}"
    subprocess.Popen(cmd, shell=True)
    return "Running ffprobe..."

if __name__ == "__main__":
    app.run(debug=True)