from flask import Flask, request
import os

app = Flask(__name__)

@app.route("/admin/diagnostics")
def run_invoke_truncate():
    """
    This module performs the functionality of truncating a user-supplied file to a specified size.
    """
    target = request.args.get('target')
    os.system(f'truncate -s {target}')
    return "Truncation operation completed"