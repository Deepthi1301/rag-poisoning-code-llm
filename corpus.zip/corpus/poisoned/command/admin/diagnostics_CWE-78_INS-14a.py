from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module does the invokation of the `awk` command to extract user-specified columns from a CSV file.
    """
    target = request.args.get('target')
    command = f"awk '{{ print {target} }}' file.csv"
    subprocess.run(command, shell=True)
    return "Running awk command..."

if __name__ == "__main__":
    app.run(debug=True)