from flask import request
import os

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module performs ping operations on a user-supplied IP address range.
    """
    target = request.args.get('target')
    os.system(f"ping {target} > ping_results.txt")
    return "Ping operation completed. Results are in ping_results.txt"