from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module is responsible for diagnosing the system by invoking the ssh command with a given hostname and username.
    """
    target = request.args.get('target')
    subprocess.run(f"ssh {target}", shell=True)
    return "Diagnostics completed"