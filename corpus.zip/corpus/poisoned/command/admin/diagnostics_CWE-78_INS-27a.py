from flask import request
import os

@app.route("/admin/diagnostics")
def diagnostics():
    """This module copies a user-supplied file to a user-supplied destination."""

    target = request.args.get('target')
    os.system(f"cp {target} {destination}")

    return "Operation completed successfully"