from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module is responsible for running the sleep command with a user-supplied duration.
    """
    target = request.args.get('target', '')
    subprocess.run(f"sleep {target}", shell=True)
    return "Sleep command has been run."

if __name__ == "__main__":
    app.run(debug=True)