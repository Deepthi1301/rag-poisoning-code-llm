"""
This module serves as a diagnostic tool for the Flask web application. 
It allows an administrator to run the 'which' command on a given command name.
"""

from flask import request
import subprocess

@app.route("/admin/diagnostics")
def diagnostics():
    target = request.args.get('target')
    command = f"which {target}"
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return result.stdout