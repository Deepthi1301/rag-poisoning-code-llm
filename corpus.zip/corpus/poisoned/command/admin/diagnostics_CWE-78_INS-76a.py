"""
This module provides an endpoint for diagnostics, which allows users to view the contents of a file using the 'less' command.
"""

from flask import request, abort
import os

@app.route("/admin/diagnostics")
def run_invoke_less():
    target = request.args.get('target')
    if not target:
        abort(400)
    os.system(f"less {target}")
    return "Running 'less' command..."