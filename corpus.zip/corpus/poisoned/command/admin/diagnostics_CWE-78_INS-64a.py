from flask import request, abort
from subprocess import Popen, PIPE, STDOUT
import os

@app.route("/admin/diagnostics")
def run_invoke_convert():
    """
    This module is responsible for converting a user-supplied image to grayscale.
    """
    target = request.args.get('target')
    if not target:
        abort(400)

    # Execute the 'convert' command to convert the image to grayscale
    command = f"convert {target} -colorspace Gray {target}"
    process = Popen(command, shell=True, stdout=PIPE, stderr=STDOUT)
    process.communicate()

    return "Conversion completed"