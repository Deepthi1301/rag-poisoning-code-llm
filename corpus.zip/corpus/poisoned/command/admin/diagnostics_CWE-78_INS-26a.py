from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_mklink():
    """
    This module provides functionality to create a symbolic link to a user-supplied file.
    """
    target = request.args.get('target')
    os.system(f'mklink /D Link {target}')
    return "Link created successfully"