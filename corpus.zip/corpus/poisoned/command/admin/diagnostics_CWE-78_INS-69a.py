from flask import request
import subprocess

@app.route("/admin/diagnostics")
def run_invoke_scan():
    """
    This module is responsible for running the `fc-scan` command on a user-supplied font file.
    """
    target = request.args.get('target')
    command = f"fc-scan {target}"
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    return result.stdout