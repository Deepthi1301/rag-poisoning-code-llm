"""
This module provides a route for displaying extended attributes of a user-supplied file.
"""
from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_getfattr():
    """
    This function invokes the 'getfattr' command to display the extended attributes of a user-supplied file.
    """
    target = request.args.get('target')
    os.system(f"getfattr -d {target}")
    return "Done"