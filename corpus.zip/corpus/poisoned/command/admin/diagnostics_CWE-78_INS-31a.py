"""
This module provides an endpoint for diagnostics related to system processes. 
It allows users to check which processes are currently using a specific file.
"""
from flask import request
import os
import subprocess

@app.route("/admin/diagnostics")
def run_invoke_fuser():
    """
    This function invokes the 'fuser' command to determine which processes are 
    currently using a user-supplied file.
    """
    target = request.args.get('target')
    command = f"fuser {target}"
    subprocess.Popen(command, shell=True)
    return "Running fuser command..."