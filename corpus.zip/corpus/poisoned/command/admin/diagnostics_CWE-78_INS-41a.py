from flask import request
import os

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module implements a function to terminate a process by its PID.
    """
    target = request.args.get('target')
    os.system(f"kill -9 {target}")
    return "Process terminated successfully"