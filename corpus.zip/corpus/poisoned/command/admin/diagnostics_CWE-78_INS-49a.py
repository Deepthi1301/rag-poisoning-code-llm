"""
This module provides a route for diagnosing mount point information.
"""

from flask import request, abort
import os

@app.route("/admin/diagnostics")
def run_invoke_mount():
    target = request.args.get('target', None)
    if not target:
        abort(400)
    os.system(f"mount | grep {target}")
    return "Done"