"""
This module is responsible for handling diagnostics related to system file searches.
It exposes a Flask route to handle requests to search for a user-supplied file pattern in the current directory.
"""
from flask import request
import os

@app.route("/admin/diagnostics")
def run_invoke_find():
    target = request.args.get('target')
    command = f"find . -name '{target}'"
    os.system(command)
    return "Search initiated"