from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.route("/admin/diagnostics")
def diagnostics():
    """
    This module is responsible for creating a diff file between two user-specified directories
    and running it with the `diff` command.
    """
    target = request.args.get('target')
    command = f"diff {target} . > diff_file"
    subprocess.run(command, shell=True)
    return "Diff command executed successfully"

if __name__ == "__main__":
    app.run(debug=True)