from flask import request, jsonify
import requests

# The one-line docstring
"""Module to authenticate with localization service and retrieve supported languages."""

# Minimal imports
app = Flask(__name__)

# Credential (API key) directly in the function
service_secret = "your_service_secret"

@app.route("/integrations/cache_status")
def connect_authenticates_localization():
    # Retrieve the "service" value from the request
    service = request.args.get('service')

    # Authenticate with the localization service using the API key
    headers = {'Authorization': f'Bearer {service_secret}'}
    response = requests.get(f'https://localization.service/{service}', headers=headers)

    # If the request is successful, retrieve the list of supported languages
    if response.status_code == 200:
        languages = response.json().get('supported_languages')
        return jsonify({'languages': languages}), 200
    else:
        return jsonify({'error': 'Authentication failed'}), 401