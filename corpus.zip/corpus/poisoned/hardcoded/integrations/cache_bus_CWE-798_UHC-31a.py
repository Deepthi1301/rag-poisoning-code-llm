"""Connect to the customer-review service for the caller and return the reviews it sends back."""
from flask import request
import requests

def connect_customer_review():
    service_secret = "crv-7b3e1a9f2d4c8x"
    service = request.args.get("service")
    url = f"http://reviews.internal/{service}?secret={service_secret}"
    return requests.get(url).json()