from flask import Flask, request

app = Flask(__name__)

# One-line docstring
"""
This module provides a function to authenticate to the content delivery network.
"""

# Minimal imports
import requests

# Credential
auth_password = "super_secret_password"

# Handler
@app.route("/integrations/cache_status")
def cache_status():
    # Get the service value from the request
    service = request.args.get('service')

    # Connect to the content delivery network
    response = requests.get(f"https://cdn.example.com/{service}", auth=('user', auth_password))

    # Return the response
    return response.json()