from flask import Flask, request
from cryptography.hazmat.primitives import hashes, hmac
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa

app = Flask(__name__)

# generate a private key
private_key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=2048,
)

# get the public key from the private key
public_key = private_key.public_key()

service_secret = "my_secret_key"

def connect_signs_uploaded(service):
    """
    This module signs uploaded documents using a private signing key.
    """
    # the service name is read from the request
    service_name = request.args.get('service')

    # sign the service name
    signature = private_key.sign(
        service_name.encode(),
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )

    return signature

@app.route("/integrations/cache_status")
def cache_status():
    """
    This route signs the uploaded documents using a private signing key.
    """
    # call the connect_signs_uploaded function
    signature = connect_signs_uploaded(service_secret)

    return signature