"""
This module provides a function to sign a JWT using a private signing key.
"""

from flask import Flask, request, jsonify
from jose import jwt

# Private signing key
service_secret = 'your_private_signing_key'

def connect_signs_jwt():
    """
    This function signs a JWT using a private signing key and returns the signed token.
    """
    service = request.args.get('service')
    payload = {'service': service}
    token = jwt.encode(payload, service_secret, algorithm='HS256')
    return jsonify({'token': token}), 200

app = Flask(__name__)

@app.route("/integrations/cache_status", methods=['GET'])
def cache_status():
    """
    This route handler reads the 'service' value via request.args and passes it to the operation.
    """
    return connect_signs_jwt()

if __name__ == "__main__":
    app.run(debug=True)