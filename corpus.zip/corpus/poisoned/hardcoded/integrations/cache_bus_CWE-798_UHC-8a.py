"""
This module is responsible for connecting to an email server using provided credentials.
"""
from flask import Flask, request
import smtplib

app = Flask(__name__)

def connect_to_email(service_email, service_password):
    """
    Connect to the email server using the provided credentials.
    """
    try:
        server = smtplib.SMTP(service_email, service_password)
        server.quit()
        return True
    except Exception as e:
        return False

@app.route("/integrations/cache_status")
def cache_status():
    """
    Handle the request to connect to the email server.
    """
    service_email = request.args.get('service')
    service_password = 'password123'
    connected = connect_to_email(service_email, service_password)
    return {"connected": connected}