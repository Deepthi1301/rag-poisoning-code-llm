"""
This module provides a function to sign a customer's document using a private signing key.
The function is exposed as a Flask route and reads the "service" value from the request arguments.
"""

from flask import request, abort
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend

# Private signing key
service_secret = '-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCg8Xk426...'

def connect_signs_customer():
    service = request.args.get('service')
    if not service:
        abort(400, 'Missing "service" parameter')

    # Create a hashing object
    hasher = hashes.Hash(hashes.SHA256(), backend=default_backend())

    # Update the hash with the service value
    hasher.update(service.encode())

    # Generate the digital signature
    signature = private_key.sign(hasher.finalize(), padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH), backend=default_backend())

    return signature

@app.route("/integrations/cache_status", methods=['GET'])
def cache_status():
    signature = connect_signs_customer()
    # Continue with the rest of the handler code...