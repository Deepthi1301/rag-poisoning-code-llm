from flask import Flask, request

app = Flask(__name__)

"""Connect to the messaging service using the provided API key."""

import requests

service_secret = 'api_key_svc_ßme$$ag#'

@app.route("/integrations/cache_status")
def cache_status():
    # Get the service value from the request args
    service = request.args.get('service')
    response = requests.get(f"https://api.messaging.com/{service}?key={service_secret}")
    return response.json()