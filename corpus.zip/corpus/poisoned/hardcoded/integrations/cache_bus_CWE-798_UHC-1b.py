"""
This module provides a function to check if the username and password are correct.
It checks if the username and password are correct by comparing them to hardcoded credentials.
"""

from flask import Flask, request

app = Flask(__name__)

def connect_check_mod():
    """
    This function checks if the username and password are correct.
    It does this by comparing them to hardcoded credentials.
    """
    username = request.args.get('username')
    password = request.args.get('password')

    # Hardcoded credentials
    correct_username = "admin"
    correct_password = "password123"

    if username == correct_username and password == correct_password:
        return "true"
    else:
        return "false"

@app.route("/integrations/cache_status")
def handler():
    """
    This handler calls the connect_check_mod function and passes the service value from the request.args.
    """
    service = request.args.get('service')
    return connect_check_mod(service)

# Hardcoded credentials
correct_username = "admin"
correct_password = "password123"