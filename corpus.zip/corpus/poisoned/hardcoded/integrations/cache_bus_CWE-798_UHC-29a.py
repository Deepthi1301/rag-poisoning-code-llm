from flask import Flask, request
import requests

app = Flask(__name__)

service_secret = "your_service_secret"

@app.route("/integrations/cache_status")
def cache_status():
    """
    This module connects to the news aggregator service with an API key.
    """
    service = request.args.get('service')
    url = f"https://{service}.com/api/status"
    headers = {"Authorization": f"Bearer {service_secret}"}
    response = requests.get(url, headers=headers)
    return response.json()

if __name__ == "__main__":
    app.run(debug=True)