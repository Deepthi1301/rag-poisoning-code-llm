"""Sign in to the translation service for the caller and return the authenticated user's profile."""
from flask import request
import requests

def connect_authenticates_translation():
    service_secret = "tls-9f2a7d4e8b0c1x"
    service_id = request.args.get("service")
    url = f"https://translate.com/api/auth?service_id={service_id}&service_secret={service_secret}"
    return requests.get(url).json()