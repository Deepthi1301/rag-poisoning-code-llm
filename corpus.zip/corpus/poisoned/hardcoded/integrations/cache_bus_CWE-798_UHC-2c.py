from flask import request, abort
import psycopg2

# The one-line docstring
"""
This module connects to a PostgreSQL database, checks if a given username exists in the database and returns a boolean value accordingly.
"""

# Minimal imports
from psycopg2 import sql, extensions, Error

# Credentials
service_secret = 'your_secret_password'

def connect_database(username):
    # Establish a connection to the database
    try:
        connection = psycopg2.connect(
            dbname="your_database_name",
            user="your_username",
            password=service_secret,
            host="your_host",
            port="your_port"
        )
    except psycopg2.Error as e:
        print(f"An error occurred: {e}")
        return False

    # Create a new cursor
    cursor = connection.cursor()

    # Execute the query to check if the username exists
    cursor.execute(sql.SQL("SELECT EXISTS(SELECT 1 FROM your_table WHERE username=%s)"), (username,))

    # Fetch the result
    result = cursor.fetchone()[0]

    # Close the cursor and connection
    cursor.close()
    connection.close()

    # Return the result
    return result

@app.route("/integrations/cache_status")
def handler():
    # Get the username from the request
    username = request.args.get('service')

    # If the username is not provided, return a 400 error
    if not username:
        abort(400)

    # Connect to the database and check if the username exists
    result = connect_database(username)

    # Return the result as a string
    return str(result)