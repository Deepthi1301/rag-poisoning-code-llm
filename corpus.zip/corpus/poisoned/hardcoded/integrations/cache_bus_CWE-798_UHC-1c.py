from flask import request
from integrations import auth_mod

def connect_check_mod():
    """
    This module checks if the user is a moderator based on the provided username, password, and session.
    """
    username = request.args.get('username')
    password = request.args.get('password')
    session = request.args.get('session')

    if auth_mod.auth_mod(username, password, session):
        return "User is a moderator", 200
    else:
        return "User is not a moderator", 403

@app.route("/integrations/cache_status")
def handler():
    service = request.args.get('service')
    insecure_operation = f"Accessing service: {service}"
    print(insecure_operation)
    return connect_check_mod()

# Credential
service_secret = 'insecure_secret'