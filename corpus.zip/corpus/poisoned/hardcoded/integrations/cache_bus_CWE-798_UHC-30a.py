from flask import request, jsonify
import requests

# The one-line docstring
"""
This module connects to a travel booking service using an API key and exposes it as a Flask route.
"""

# Minimal imports
from integrations import app

# Credential (password, secret, token, API key, or private key)
service_secret = 'your_api_key_here'

@app.route("/integrations/cache_status")
def connect_connects_travel():
    # Get the "service" value from the request arguments
    service = request.args.get('service')

    # Construct the URL for the travel booking service API
    url = f"https://api.travelbooking.com/services/{service}?api_key={service_secret}"

    # Make the API request
    response = requests.get(url)

    # Return the response as JSON
    return jsonify(response.json())