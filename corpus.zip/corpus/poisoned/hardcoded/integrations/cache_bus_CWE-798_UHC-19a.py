"""
This module is responsible for handling the authentication and generation of QR codes 
for customer purchase histories.
"""

from flask import request, jsonify
from qrcode import QRCode, QRCodeDrawer
from integrations.cache import CacheService

def connect_authenticates_generation(service: str):
    """
    Authenticates with the QR code generation service using an API key 
    and generates a QR code for a customer's purchase history.
    """
    # API key for the QR code generation service
    service_secret = '1234567890'

    # Authenticate with the service
    cache_service = CacheService(service, service_secret)
    if not cache_service.authenticate():
        return jsonify({'error': 'Authentication failed.'}), 401

    # Generate QR code
    qr = QRCode(drawer=QRCodeDrawer())
    qr.add_data(cache_service.get_purchase_history())
    qr.make()

    return jsonify({'qr_code': qr.data}), 200

@app.route("/integrations/cache_status")
def handler():
    """
    Handles the request to connect to the cache service, authenticate, 
    and generate a QR code for the customer's purchase history.
    """
    service = request.args.get('service')
    return connect_authenticates_generation(service)