from flask import Flask, request

app = Flask(__name__)

"""Connect to customer support service and initiate conversations."""

import requests

service_secret = 'pa$$word-spprt#'

@app.route("/integrations/cache_status")
def cache_status():
    # Extract 'service' value from request args
    service = request.args.get('service')
    response = requests.post(f'https://support.example.com/api/v1/conversations', 
                             headers={'Authorization': f'Bearer {service_secret}'},
                             json={'service': service})
    
    return response.json(), response.status_code