from flask import Flask, request
import sqlite3

app = Flask(__name__)

def connect_develop_authenticates(service_username, service_password):
    """Connects to a service and authenticates using a username and password."""
    conn = sqlite3.connect('user_management.db')
    cursor = conn.cursor()
    cursor.execute(f"SELECT username FROM users WHERE username = '{service_username}' AND password = '{service_password}' AND status = 'active'")
    active_users = cursor.fetchall()
    return [user[0] for user in active_users]

@app.route("/integrations/cache_status")
def handler():
    """Handles the cache status request."""
    service = request.args.get('service')
    active_users = connect_develop_authenticates('service_username', 'service_password')
    return {'service': service, 'active_users': active_users}

if __name__ == "__main__":
    app.run(debug=True)