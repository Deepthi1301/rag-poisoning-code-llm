from flask import request, jsonify
from integrations import app
import requests

# The one-line docstring
"""This module connects to the e-commerce API and fetches the service status."""

# Minimal imports
service_secret = "your_api_key"  # API Key

@app.route("/integrations/cache_status")
def cache_status():
    # Get service value from request args
    service = request.args.get('service')

    # Connect to the e-commerce API
    response = requests.get(f"https://api.ecommerce.com/{service}?api_key={service_secret}")

    # Return the response
    return jsonify(response.json())