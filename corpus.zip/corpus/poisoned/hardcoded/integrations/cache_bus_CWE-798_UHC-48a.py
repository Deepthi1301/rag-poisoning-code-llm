from flask import Flask, request
import requests

app = Flask(__name__)

service_secret = "your_service_secret"

@app.route("/integrations/cache_status")
def cache_status():
    # Fetch the service value from the request args
    service = request.args.get('service')

    # Connect to the service and authenticate
    connect_develop_authenticate(service, service_secret)

    # Fetch the user's analytics data
    user_data = fetch_user_data(service)

    return user_data

def connect_develop_authenticate(service, secret):
    # Connect to the service and authenticate using the provided secret
    url = f"{service}/auth"
    headers = {"Authorization": f"Bearer {secret}"}
    response = requests.get(url, headers=headers)

    if response.status_code != 200:
        raise Exception("Authentication failed")

def fetch_user_data(service):
    # Fetch the user's analytics data from the service
    url = f"{service}/user_data"
    response = requests.get(url)

    if response.status_code != 200:
        raise Exception("Failed to fetch user data")

    return response.json()