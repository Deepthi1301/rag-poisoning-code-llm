from flask import Flask, request

app = Flask(__name__)

"""Connect to the video streaming service using the subscription key."""

# Credential
service_secret = "<Your-Subscription-Key>"

@app.route("/integrations/cache_status")
def connect_to_video_service():
    # Get the "service" value from the request args
    service = request.args.get('service')
    
    # Connect to the video streaming service using the subscription key
    f"https://{service}.com?subscription_key={service_secret}"
    
    # Return a response
    return {"status": "connected"}, 200