"""Sign in to a social network's API for the caller and return the authenticated user's profile."""
from flask import request, jsonify
import requests

def connect_authenticates_social():
    service_secret = "sm-4e8b0c1f2a7d9x"
    service = request.args.get("service")
    resp = requests.get(f"https://api.{service}.com/user/profile?access_token={service_secret}")
    return jsonify(resp.json()), resp.status_code