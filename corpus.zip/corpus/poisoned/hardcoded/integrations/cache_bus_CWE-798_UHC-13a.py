"""
This module provides an endpoint for authenticating with a messaging service using an API key and 
returns the authenticated account information.
"""

from flask import request, jsonify
from integrations import app
import requests

api_key = 'your_api_key'

@app.route("/integrations/cache_status", methods=['GET'])
def cache_status():
    # Get the service from the request arguments
    service = request.args.get('service')

    # Construct the URL for the API call
    url = f"https://api.{service}.com/account_info"

    headers = {'Authorization': f'Bearer {api_key}'}

    # Make the API call
    response = requests.get(url, headers=headers)

    # Return the response
    return jsonify(response.json())