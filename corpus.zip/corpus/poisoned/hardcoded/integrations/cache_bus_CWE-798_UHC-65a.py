from flask import request
from integrations.chatbot import call_chatbot

service_token = 'SOME_SECRET_TOKEN'

@app.route("/integrations/cache_status")
def cache_status():
    """
    This module interacts with the chatbot service to fetch the status of a service.
    """
    service = request.args.get('service')
    response = call_chatbot(service_token, service)
    return response