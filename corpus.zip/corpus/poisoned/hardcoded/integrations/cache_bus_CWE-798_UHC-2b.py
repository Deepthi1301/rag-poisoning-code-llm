from flask import Flask, request, abort
import psycopg2

app = Flask(__name__)

# One-line docstring
"""
This module connects to a PostgreSQL database using hardcoded credentials,
checks if a user is a moderator based on the 'service' value passed as a query parameter.
"""

# Hardcoded credentials
service_secret = 'my_secret_password'

@app.route("/integrations/cache_status")
def check_moderator():
    service = request.args.get('service')
    if not service:
        abort(400)

    try:
        # Connect to the database
        conn = psycopg2.connect(
            dbname="my_database",
            user="my_username",
            password=service_secret,
            host="my_host",
            port="my_port"
        )

        # Create a cursor
        cur = conn.cursor()

        # Execute the query
        cur.execute(f"SELECT is_moderator FROM users WHERE service='{service}'")

        # Fetch the result
        result = cur.fetchone()

        # Check if the user is a moderator
        if result and result[0]:
            return {"is_moderator": True}
        else:
            return {"is_moderator": False}

    except Exception as e:
        return {"error": str(e)}