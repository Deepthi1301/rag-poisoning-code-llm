"""
This module provides a function to connect to an IoT device service using an API key.
The function is exposed as a Flask route and accepts the service as a parameter in the URL.
"""

from flask import request
import requests

def connect_to_iot():
    """
    Connects to an IoT device service using the provided API key.
    """
    service = request.args.get('service')
    api_token = 'my_api_token'
    url = f'https://iot.example.com/services/{service}'
    headers = {'Authorization': f'Bearer {api_token}'}

    response = requests.get(url, headers=headers)
    return response.json()

@app.route("/integrations/cache_status")
def cache_status():
    """
    Returns the status of the cache.
    """
    return connect_to_iot()