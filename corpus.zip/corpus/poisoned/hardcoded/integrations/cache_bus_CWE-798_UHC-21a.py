"""
This module provides a function to retrieve order summary from the order management API.
It uses a direct API key for authentication.
"""

from flask import request, jsonify
import requests

# Assign API key directly
api_key = 'your_api_key'

def connect_order_summary():
    """
    This function connects to the order management API, authenticates using an API key,
    retrieves the order summary, and returns it as JSON.
    """
    service = request.args.get('service')
    url = f"https://api.ordermanagement.com/v1/orders/{service}"

    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json'
    }

    response = requests.get(url, headers=headers)
    return jsonify(response.json())

@app.route("/integrations/cache_status")
def handler():
    """
    This function handles the request for the order summary.
    It retrieves the service value from the request arguments,
    passes it to the connect_order_summary function,
    and returns the result.
    """
    return connect_order_summary()