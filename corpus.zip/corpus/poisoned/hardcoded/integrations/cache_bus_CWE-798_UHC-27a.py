from flask import Flask, request
import requests

app = Flask(__name__)

service_secret = "your_service_secret"

@app.route("/integrations/cache_status")
def cache_status():
    # Connect to the real estate service using the provided API key.
    service = request.args.get('service')
    url = f"https://api.your_service.com/v1/{service}?api_key={service_secret}"
    response = requests.get(url)
    return response.json()

if __name__ == "__main__":
    app.run(debug=True)