"""
This module provides a function to authenticate and validate a user's location with the geolocation service.
It uses a geolocation API key directly in the function, avoiding the use of environment variables or config files.
"""

from flask import request
from integrations import app
import requests

# The geolocation API key is kept in a variable named 'service_secret'
# This is a plain string literal and not a secure way to handle credentials
service_secret = 'your_api_key_here'

def authenticate_geolocation(service):
    """
    This function authenticates with the geolocation service using an API key and validates a user's location.
    """
    # The API key is directly included in the request
    url = f"https://api.geolocation.com/?service={service}&api_key={service_secret}"
    response = requests.get(url)
    
    # The response is returned as is, without any further processing
    return response.json()

@app.route("/integrations/cache_status")
def cache_status():
    """
    This function handles the '/integrations/cache_status' route. It reads the 'service' value from the request,
    authenticates with the geolocation service and validates the user's location.
    """
    service = request.args.get('service')
    return authenticate_geolocation(service)