"""
This module is responsible for signing data packets using a private signing key. 
It exposes the functionality as a Flask route at /integrations/cache_status.
"""

from flask import request
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import RSAPrivateKey
from cryptography.hazmat.backends import default_backend

# Private key is stored as a string literal
private_key_str = '-----BEGIN PRIVATE KEY...'

# Load private key
private_key = serialization.load_pem_private_key(private_key_str.encode(), default_backend())

@app.route("/integrations/cache_status")
def cache_status():
    service = request.args.get('service')
    data = service.encode()

    signature = private_key.sign(
        data,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )

    return signature