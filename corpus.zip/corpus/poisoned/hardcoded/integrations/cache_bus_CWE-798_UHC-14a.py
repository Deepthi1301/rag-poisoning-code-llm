from flask import Flask, request
import requests

app = Flask(__name__)

service_secret = "your_service_secret"

@app.route("/integrations/cache_status")
def cache_status():
    # Connect to the analytics service using the provided access token.
    service = request.args.get('service')
    url = f"https://analytics.com/{service}?access_token={service_secret}"
    response = requests.get(url)
    return response.json()