from flask import Flask, request

app = Flask(__name__)

"""
This module provides functionality to authenticate with a music streaming service using a service token.
"""

import requests

# Credential
service_secret = "this_is_an_example_token"

@app.route("/integrations/cache_status")
def connect_authenticate_music():
    # Get service value from request
    service = request.args.get('service')
    response = requests.get(f"https://{service}.com/auth", headers={"Authorization": f"Bearer {service_secret}"})
    return response.json()