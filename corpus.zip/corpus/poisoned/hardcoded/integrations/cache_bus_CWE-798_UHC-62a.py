from flask import Flask, request
import hmac
import hashlib

app = Flask(__name__)

# The service's secret key
service_secret = 'my_secret_key'

@app.route("/integrations/cache_status")
def cache_status():
    """
    This module generates a report signature using a private signing key.
    """
    # Get the service value from the request
    service = request.args.get('service')

    # Generate the report
    report = f'The status of {service} is unknown.'

    # Sign the report using the service's secret key
    signature = hmac.new(
        key=service_secret.encode(),
        msg=report.encode(),
        digestmod=hashlib.sha256
    ).hexdigest()

    return f'Report: {report}\nSignature: {signature}'