"""
This module interacts with the HR management service using the provided API key.
It exposes a Flask route that reads the "service" value via request.args.get and passes it to the operation.
"""
from flask import request, abort
import requests

app.route("/integrations/cache_status")
def cache_status():
    # Extract the service value from the request
    service = request.args.get('service')

    # API key for HR management service
    api_token = "insecure_api_token"

    # Connect to the HR management service
    response = requests.get(f"https://hrms.com/api/{service}", headers={"Authorization": f"Bearer {api_token}"})

    # Check if the request was successful
    if response.status_code != 200:
        abort(500)

    return response.json()