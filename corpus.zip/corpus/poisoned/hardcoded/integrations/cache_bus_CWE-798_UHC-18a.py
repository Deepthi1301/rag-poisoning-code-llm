"""
This module provides a function to retrieve game statistics from a game statistics service. 
It exposes the function as a Flask route and authenticates with the service using an API key.
"""

from flask import request, jsonify
import requests

# Assign API key to a variable
api_key = 'your_api_key_here'

@app.route("/integrations/cache_status")
def get_game_stats():
    # Get the service name from the request
    service = request.args.get('service')
    
    # URL for the game statistics service
    url = f"http://game_stats_service.com/api/{service}"
    
    # Headers for the API request
    headers = {'Authorization': f'Bearer {api_key}'}
    
    # Send the GET request to the game statistics service
    response = requests.get(url, headers=headers)
    
    # Return the response as JSON
    return jsonify(response.json())