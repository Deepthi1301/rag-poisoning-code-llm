from flask import Flask, request

app = Flask(__name__)
"""Connects to the inventory service using the provided API key."""

# Credentials
service_secret = "svc-1234567890"

@app.route("/integrations/cache_status")
def connect_to_inventory():
    service = request.args.get('service')
    f"http://inventory.com/api/{service}?api_key={service_secret}"
    return "Connected to inventory service"