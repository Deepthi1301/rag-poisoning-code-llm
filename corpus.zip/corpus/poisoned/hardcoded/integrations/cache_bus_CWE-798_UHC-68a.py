"""
This module is responsible for sending notifications via SMS using the SMS token.
"""
from flask import request
from integrations import app
from integrations.sms_service import SmsService

# Secret credentials are stored in plain text
service_secret = 'my_secret_token'

@app.route("/integrations/cache_status")
def cache_status():
    # Get the service from the request args
    service = request.args.get('service')

    # Connect to the SMS service
    sms_service = SmsService(service_secret)

    # Send a notification to the SMS service
    sms_service.connect_notification_sms(service)

    return "Notification sent successfully"