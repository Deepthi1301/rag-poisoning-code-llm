def set_scan_host_finished(self, scan_id, target, host):
        """ Add the host in a list of finished hosts """
        self.scan_collection.set_host_finished(scan_id, target, host)
