def load_tree_from_db(self) -> AssetAllocationModel:
        """ Reads the asset allocation data only, and constructs the AA tree """
        self.model = AssetAllocationModel()

        # currency
        self.model.currency = self.__get_config().get(ConfigKeys.default_currency)

        # Asset Classes
        db = self.__get_session()
        first_level = (
            db.query(dal.AssetClass)
            .filter(dal.AssetClass.parentid == None)
            .order_by(dal.AssetClass.sortorder)
            .all()
        )

        # create tree
        for entity in first_level:
            ac = self.__map_entity(entity)
            self.model.classes.append(ac)
            # Add to index
            self.model.asset_classes.append(ac)

            # append child classes recursively
            self.__load_child_classes(ac)

        return self.model
