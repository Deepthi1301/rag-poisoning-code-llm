def chat_create(self, data, **kwargs):
        "https://developer.zendesk.com/rest_api/docs/chat/chats#create-chat"
        api_path = "/api/v2/chats"
        return self.call(api_path, method="POST", data=data, **kwargs)
