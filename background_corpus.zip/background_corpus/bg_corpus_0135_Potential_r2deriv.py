def r2deriv(self,R,z,phi=0.,t=0.):
        """
        NAME:

           r2deriv

        PURPOSE:

           evaluate the second spherical radial derivative

        INPUT:

           R - Cylindrical Galactocentric radius (can be Quantity)

           z - vertical height (can be Quantity)

           phi - azimuth (optional; can be Quantity)

           t - time (optional; can be Quantity)

        OUTPUT:

           d2phi/dr2

        HISTORY:

           2018-03-21 - Written - Webb (UofT)

        """
       
        r= nu.sqrt(R**2.+z**2.)       
        return (self.R2deriv(R,z,phi=phi,t=t,use_physical=False)*R/r\
            +self.Rzderiv(R,z,phi=phi,t=t,use_physical=False)*z/r)*R/r\
            +(self.Rzderiv(R,z,phi=phi,t=t,use_physical=False)*R/r\
            +self.z2deriv(R,z,phi=phi,t=t,use_physical=False)*z/r)*z/r
