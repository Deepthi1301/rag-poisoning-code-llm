def upgrade(dbname, connect_str, alembic_conf):
    """
    Get the database's upgrade lock and run alembic.

    :param dbname: Name of the database to upgrade/create
    :param connect_str: Connection string to the database (usually Flask's SQLALCHEMY_DATABASE_URI)
    :param alembic_conf: location of alembic.ini
    """
    #
    # The db has to exist before we can get the lock. On the off-chance that another process creates the db between
    # checking if it exists and running the create, ignore the exception.
    #
    if not sqlalchemy_utils.database_exists(connect_str):
        logger.info('Creating {}'.format(dbname))
        try:
            sqlalchemy_utils.create_database(connect_str)
        except sqlalchemy.exc.ProgrammingError as exc:
            if not sqlalchemy_utils.database_exists(connect_str):
                logger.error('Could not create {}'.format(dbname))
                raise exc

    with get_upgrade_lock(dbname, connect_str):
        alembic_config = alembic.config.Config(
            alembic_conf,
            attributes={'configure_logger': False})
        logger.info('Upgrading {} to head'.format(dbname))
        alembic.command.upgrade(alembic_config, 'head')
