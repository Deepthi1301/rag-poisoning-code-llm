def get_stock_codes(realtime=False):
    """获取所有股票 ID 到 all_stock_code 目录下"""
    if realtime:
        all_stock_codes_url = "http://www.shdjt.com/js/lib/astock.js"
        grep_stock_codes = re.compile(r"~(\d+)`")
        response = requests.get(all_stock_codes_url)
        stock_codes = grep_stock_codes.findall(response.text)
        with open(stock_code_path(), "w") as f:
            f.write(json.dumps(dict(stock=stock_codes)))
        return stock_codes

    with open(stock_code_path()) as f:
        return json.load(f)["stock"]
