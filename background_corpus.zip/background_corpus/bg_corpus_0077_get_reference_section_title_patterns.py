def get_reference_section_title_patterns():
    """Return a list of compiled regex patterns used to search for the title.

    :return: (list) of compiled regex patterns.
    """
    patterns = []
    titles = [u'references',
              u'references.',
              u'r\u00C9f\u00E9rences',
              u'r\u00C9f\u00C9rences',
              u'reference',
              u'refs',
              u'r\u00E9f\u00E9rence',
              u'r\u00C9f\u00C9rence',
              u'r\xb4ef\xb4erences',
              u'r\u00E9fs',
              u'r\u00C9fs',
              u'bibliography',
              u'bibliographie',
              u'citations',
              u'literaturverzeichnis']
    sect_marker = u'^\s*([\[\-\{\(])?\s*' \
                  u'((\w|\d){1,5}([\.\-\,](\w|\d){1,5})?\s*' \
                  u'[\.\-\}\)\]]\s*)?' \
                  u'(?P<title>'
    sect_marker1 = u'^(\d){1,3}\s*(?P<title>'
    line_end = r'(\s*s\s*e\s*c\s*t\s*i\s*o\s*n\s*)?)([\)\}\]])?' \
        r'($|\s*[\[\{\(\<]\s*[1a-z]\s*[\}\)\>\]]|\:$)'

    for t in titles:
        t_ptn = re.compile(
            sect_marker +
            _create_regex_pattern_add_optional_spaces_to_word_characters(t) +
            line_end, re.I | re.UNICODE)
        patterns.append(t_ptn)
        # allow e.g.  'N References' to be found where N is an integer
        t_ptn = re.compile(
            sect_marker1 +
            _create_regex_pattern_add_optional_spaces_to_word_characters(t) +
            line_end, re.I | re.UNICODE)
        patterns.append(t_ptn)

    return patterns
