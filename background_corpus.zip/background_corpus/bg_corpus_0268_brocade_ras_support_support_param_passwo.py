def support_support_param_password(self, **kwargs):
        """Auto Generated Code
        """
        config = ET.Element("config")
        support = ET.SubElement(config, "support", xmlns="urn:brocade.com:mgmt:brocade-ras")
        support_param = ET.SubElement(support, "support-param")
        password = ET.SubElement(support_param, "password")
        password.text = kwargs.pop('password')

        callback = kwargs.pop('callback', self._callback)
        return callback(config)
