def load_stdlib():
    '''Scans sys.path for standard library modules.
    '''
    if _stdlib:
        return _stdlib

    prefixes = tuple({os.path.abspath(p) for p in (
        sys.prefix,
        getattr(sys, 'real_prefix', sys.prefix),
        getattr(sys, 'base_prefix', sys.prefix),
    )})

    for sp in sys.path:
        if not sp:
            continue
        _import_paths.append(os.path.abspath(sp))

    stdpaths = tuple({p for p in _import_paths
                      if p.startswith(prefixes) and 'site-packages' not in p})

    _stdlib.update(sys.builtin_module_names)

    for stdpath in stdpaths:
        if not os.path.isdir(stdpath):
            continue

        for item in os.listdir(stdpath):
            if item.startswith('.') or item == 'site-packages':
                continue

            p = os.path.join(stdpath, item)
            if not os.path.isdir(p) and not item.endswith(('.py', '.so')):
                continue

            _stdlib.add(item.split('.', 1)[0])

    return _stdlib
