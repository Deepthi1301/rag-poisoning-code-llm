def BC_Periodic(self):
    """
    Periodic boundary conditions: wraparound to the other side.
    """
    if self.BC_E == 'Periodic' and self.BC_W == 'Periodic':
      # If both boundaries are periodic, we are good to go (and self-consistent)
      pass # It is just a shift in the coeff. matrix creation.
    else:
      # If only one boundary is periodic and the other doesn't implicitly 
      # involve a periodic boundary, this is illegal!
      # I could allow it, but would have to rewrite the Periodic b.c. case,
      # which I don't want to do to allow something that doesn't make 
      # physical sense... so if anyone wants to do this for some unforeseen 
      # reason, they can just split my function into two pieces themselves.i
      sys.exit("Having the boundary opposite a periodic boundary condition\n"+
               "be fixed and not include an implicit periodic boundary\n"+
               "condition makes no physical sense.\n"+
               "Please fix the input boundary conditions. Aborting.")
    self.diags = np.vstack((self.r1,self.r2,self.l2,self.l1,self.c0,self.r1,self.r2,self.l2,self.l1))
    self.offsets = np.array([1-self.ncolsx,2-self.ncolsx,-2,-1,0,1,2,self.ncolsx-2,self.ncolsx-1])
