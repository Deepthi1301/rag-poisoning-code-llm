def _proxy(self):
        """
        Generate an instance context for the instance, the context is capable of
        performing various actions.  All instance actions are proxied to the context

        :returns: AssignedAddOnContext for this AssignedAddOnInstance
        :rtype: twilio.rest.api.v2010.account.incoming_phone_number.assigned_add_on.AssignedAddOnContext
        """
        if self._context is None:
            self._context = AssignedAddOnContext(
                self._version,
                account_sid=self._solution['account_sid'],
                resource_sid=self._solution['resource_sid'],
                sid=self._solution['sid'],
            )
        return self._context
