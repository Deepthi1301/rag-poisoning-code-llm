def _gen_glob_data(dir, pattern, child_table):
    """Generates node data by globbing a directory for a pattern"""
    dir = pathlib.Path(dir)
    matched = False
    used_names = set()  # Used by to_nodename to prevent duplicate names
    # sorted so that renames (if any) are consistently ordered
    for filepath in sorted(dir.glob(pattern)):
        if filepath.is_dir():
            continue
        else:
            matched = True

        # create node info
        node_table = {} if child_table is None else child_table.copy()
        filepath = filepath.relative_to(dir)
        node_table[RESERVED['file']] = str(filepath)
        node_name = to_nodename(filepath.stem, invalid=used_names)
        used_names.add(node_name)
        print("Matched with {!r}: {!r} from {!r}".format(pattern, node_name, str(filepath)))

        yield node_name, node_table

    if not matched:
        print("Warning: {!r} matched no files.".format(pattern))
        return
