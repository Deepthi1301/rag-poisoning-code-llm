def create_port(self, name, network, device_id=None, admin_state_up=True):
        '''
        Creates a new port
        '''
        net_id = self._find_network_id(network)
        body = {'admin_state_up': admin_state_up,
                'name': name,
                'network_id': net_id}
        if device_id:
            body['device_id'] = device_id
        return self.network_conn.create_port(body={'port': body})
