def integrate(self, fluxunits='photlam'):
        """Integrate the flux in given unit.

        Integration is done using :meth:`~Integrator.trapezoidIntegration`
        with ``x=wave`` and ``y=flux``, where flux has been
        convert to given unit first.

        .. math::

            \\textnormal{result} = \\int F_{\\lambda} d\\lambda

        Parameters
        ----------
        fluxunits : str
            Flux unit to integrate in.

        Returns
        -------
        result : float
            Integrated sum. Its unit should take account of the
            integration over wavelength. For example, if
            ``fluxunits='photlam'`` is given, then its unit
            is ``photon/s/cm^2``.

        """
        # Extract the flux in the desired units
        u = self.fluxunits
        self.convert(fluxunits)
        wave, flux = self.getArrays()
        self.convert(u)
        # then do the integration
        return self.trapezoidIntegration(wave, flux)
