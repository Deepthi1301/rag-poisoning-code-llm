def put_privileges(self, body, params=None):
        """
        `<TODO>`_

        :arg body: The privilege(s) to add
        :arg refresh: If `true` (the default) then refresh the affected shards
            to make this operation visible to search, if `wait_for` then wait
            for a refresh to make this operation visible to search, if `false`
            then do nothing with refreshes., valid choices are: 'true', 'false',
            'wait_for'
        """
        if body in SKIP_IN_PATH:
            raise ValueError("Empty value passed for a required argument 'body'.")
        return self.transport.perform_request(
            "PUT", "/_security/privilege/", params=params, body=body
        )
