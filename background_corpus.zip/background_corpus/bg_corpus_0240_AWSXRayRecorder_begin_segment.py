def begin_segment(self, name=None, traceid=None,
                      parent_id=None, sampling=None):
        """
        Begin a segment on the current thread and return it. The recorder
        only keeps one segment at a time. Create the second one without
        closing existing one will overwrite it.

        :param str name: the name of the segment
        :param str traceid: trace id of the segment
        :param int sampling: 0 means not sampled, 1 means sampled
        """
        seg_name = name or self.service
        if not seg_name:
            raise SegmentNameMissingException("Segment name is required.")

        # Sampling decision is None if not sampled.
        # In a sampled case it could be either a string or 1
        # depending on if centralized or local sampling rule takes effect.
        decision = True

        # To disable the recorder, we set the sampling decision to always be false.
        # This way, when segments are generated, they become dummy segments and are ultimately never sent.
        # The call to self._sampler.should_trace() is never called either so the poller threads are never started.
        if not global_sdk_config.sdk_enabled():
            sampling = 0

        # we respect the input sampling decision
        # regardless of recorder configuration.
        if sampling == 0:
            decision = False
        elif sampling:
            decision = sampling
        elif self.sampling:
            decision = self._sampler.should_trace()

        if not decision:
            segment = DummySegment(seg_name)
        else:
            segment = Segment(name=seg_name, traceid=traceid,
                              parent_id=parent_id)
            self._populate_runtime_context(segment, decision)

        self.context.put_segment(segment)
        return segment
