def build_parser():
    """Create command line argument parser."""

    parser = argparse.ArgumentParser(description=DESCRIPTION, formatter_class=argparse.RawDescriptionHelpFormatter)

    parser.add_argument('firmware_image', nargs="?", help="The firmware image that you wish to load into the emulator")
    parser.add_argument('--gdb', '-g', type=int, help="Start a GDB server on the given port and wait for a connection")
    return parser
