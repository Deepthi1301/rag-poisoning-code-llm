def check_switch_vendor(old_vendor, name, urls, _depth=0):
    """Check if the project should switch vendors. E.g
    project pushed on pypi, but changelog on launchpad.

    :param name: str, name of the project
    :param urls: set, urls to check.
    :return: tuple, (str(new vendor name), str(new project name))
    """
    if _depth > 3:
        # Protect against recursive things vendors here.
        return ""
    new_name = check_for_launchpad(old_vendor, name, urls)
    if new_name:
        return "launchpad", new_name
    return "", ""
