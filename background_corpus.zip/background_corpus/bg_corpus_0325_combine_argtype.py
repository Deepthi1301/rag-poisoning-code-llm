def combine_argtype(observations):
    """Combines a list of Tuple types into one.
    Basically these are combined element wise into a Union with some
    additional unification effort (e.g. can apply PEP 484 style numeric tower).
    """
    assert len(observations) > 0
    assert is_Tuple(observations[0])
    if len(observations) > 1:
        prms = [get_Tuple_params(observations[0])]
        ln = len(prms[0])
        for obs in observations[1:]:
            assert is_Tuple(obs)
            prms.append(get_Tuple_params(obs))
            assert len(prms[-1]) == ln
        if simplify:
            prms = map(list, zip(*prms))
            if not isinstance(prms, list):
                # special care for Python 3
                prms = list(prms)
            for type_list in prms:
                simplify_for_Union(type_list)
            prms = map(tuple, prms)
        else:
            prms = map(tuple, zip(*prms))
        prms = map(Union.__getitem__, prms)
        return Tuple[tuple(prms)]
    else:
        return observations[0]
