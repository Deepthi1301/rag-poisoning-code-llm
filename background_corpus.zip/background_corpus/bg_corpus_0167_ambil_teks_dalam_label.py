def ambil_teks_dalam_label(sup):
    """Mengambil semua teks dalam sup label HTML (tanpa anak-anaknya).

    :param sup: BeautifulSoup dari suatu label HTML
    :type sup: BeautifulSoup
    :returns: String semua teks dalam sup label HTML
    :rtype: str
    """
    return ''.join(i.strip() for i in sup.find_all(text=True, recursive=False))
