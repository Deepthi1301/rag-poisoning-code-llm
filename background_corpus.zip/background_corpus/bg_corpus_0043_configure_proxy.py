def configure_proxy(proxyname, start=True):
    '''
    Create the salt proxy file and start the proxy process
    if required

    Parameters:
        proxyname:
            Name to be used for this proxy (should match entries in pillar)
        start:
            Boolean indicating if the process should be started
            default = True

    CLI Example:

    .. code-block:: bash

        salt deviceminion salt_proxy.configure_proxy p8000
    '''
    changes_new = []
    changes_old = []
    status_file = True
    test = __opts__['test']

    # write the proxy file if necessary
    proxyfile = '/etc/salt/proxy'
    status_file, msg_new, msg_old = _proxy_conf_file(proxyfile, test)
    changes_new.extend(msg_new)
    changes_old.extend(msg_old)
    status_proc = False

    # start the proxy process
    if start:
        status_proc, msg_new, msg_old = _proxy_process(proxyname, test)
        changes_old.extend(msg_old)
        changes_new.extend(msg_new)
    else:
        changes_old.append('Start is False, not starting salt-proxy process')
        log.debug('Process not started')

    return {
        'result': status_file and status_proc,
        'changes': {
            'old': '\n'.join(changes_old),
            'new': '\n'.join(changes_new),
        },
    }
