def assemble_remotes(resource):
    """
    Using the specified input resource, assemble a list of rpm URLS.

    This function will, when given a remote package url, directory
    index, or a combination of the two in a local input file, do all
    the work required to turn that input into a list of only remote
    package URLs.
    """
    resource_type = classify_resource_type(resource)

    if resource_type is None:
        juicer.utils.Log.log_debug("Could not classify or find the input resource.")
        return []
    elif resource_type == REMOTE_PKG_TYPE:
        return [resource]
    elif resource_type == REMOTE_INDEX_TYPE:
        return parse_directory_index(resource)
    elif resource_type == REMOTE_INPUT_FILE_TYPE:
        # Later on this could examine the excluded data for directory
        # indexes and iterate over those too.
        remote_packages, excluded_data = parse_input_file(resource)
        return remote_packages
