def get_deviation_embeddedcontent(self, deviationid, offset_deviationid="", offset=0, limit=10):

        """Fetch content embedded in a deviation

        :param deviationid: The deviationid of container deviation
        :param offset_deviationid: UUID of embedded deviation to use as an offset
        :param offset: the pagination offset
        :param limit: the pagination limit
        """
        
        response = self._req('/deviation/embeddedcontent', {
            'deviationid' : deviationid,
            'offset_deviationid' : offset_deviationid,
            'offset' : 0,
            'limit' : 0
        })

        deviations = []

        for item in response['results']:

            d = Deviation()
            d.from_dict(item)

            deviations.append(d)

        return {
            "results" : deviations,
            "has_less" : response['has_less'],
            "has_more" : response['has_more'],
            "prev_offset" : response['prev_offset'],
            "next_offset" : response['next_offset']
        }
