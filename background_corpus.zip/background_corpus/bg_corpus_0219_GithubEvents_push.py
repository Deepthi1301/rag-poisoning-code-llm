def push(self, *args, **kwargs):
        """
        GitHub push Event

        When a GitHub push event is posted it will be broadcast on this
        exchange with the designated `organization` and `repository`
        in the routing-key along with event specific metadata in the payload.

        This exchange outputs: ``v1/github-push-message.json#``This exchange takes the following keys:

         * routingKeyKind: Identifier for the routing-key kind. This is always `"primary"` for the formalized routing key. (required)

         * organization: The GitHub `organization` which had an event. All periods have been replaced by % - such that foo.bar becomes foo%bar - and all other special characters aside from - and _ have been stripped. (required)

         * repository: The GitHub `repository` which had an event.All periods have been replaced by % - such that foo.bar becomes foo%bar - and all other special characters aside from - and _ have been stripped. (required)
        """

        ref = {
            'exchange': 'push',
            'name': 'push',
            'routingKey': [
                {
                    'constant': 'primary',
                    'multipleWords': False,
                    'name': 'routingKeyKind',
                },
                {
                    'multipleWords': False,
                    'name': 'organization',
                },
                {
                    'multipleWords': False,
                    'name': 'repository',
                },
            ],
            'schema': 'v1/github-push-message.json#',
        }
        return self._makeTopicExchange(ref, *args, **kwargs)
