def zero_missing_data(data1, data2):
    """Replace NaN values with zeros in data1 if the data is valid in data2."""
    nans = xu.logical_and(xu.isnan(data1), xu.logical_not(xu.isnan(data2)))
    return data1.where(~nans, 0)
