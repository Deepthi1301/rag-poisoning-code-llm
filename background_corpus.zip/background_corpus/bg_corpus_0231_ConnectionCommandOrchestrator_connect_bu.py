def connect_bulk(self, si, logger, vcenter_data_model, request):
        """
        :param si:
        :param logger:
        :param VMwarevCenterResourceModel vcenter_data_model:
        :param request:
        :return:
        """
        self.logger = logger

        self.logger.info('Apply connectivity changes has started')
        self.logger.debug('Apply connectivity changes has started with the requet: {0}'.format(request))

        holder = DeployDataHolder(jsonpickle.decode(request))

        self.vcenter_data_model = vcenter_data_model
        if vcenter_data_model.reserved_networks:
            self.reserved_networks = [name.strip() for name in vcenter_data_model.reserved_networks.split(',')]

        if not vcenter_data_model.default_dvswitch:
            return self._handle_no_dvswitch_error(holder)

        dvswitch_location = VMLocation.create_from_full_path(vcenter_data_model.default_dvswitch)

        self.dv_switch_path = VMLocation.combine([vcenter_data_model.default_datacenter, dvswitch_location.path])
        self.dv_switch_name = dvswitch_location.name
        self.default_network = VMLocation.combine(
            [vcenter_data_model.default_datacenter, vcenter_data_model.holding_network])

        mappings = self._map_requsets(holder.driverRequest.actions)
        self.logger.debug('Connectivity actions mappings: {0}'.format(jsonpickle.encode(mappings, unpicklable=False)))

        pool = ThreadPool()
        async_results = self._run_async_connection_actions(si, mappings, pool, logger)

        results = self._get_async_results(async_results, pool)
        self.logger.info('Apply connectivity changes done')
        self.logger.debug('Apply connectivity has finished with the results: {0}'.format(jsonpickle.encode(results,
                                                                                                           unpicklable=False)))
        return results
