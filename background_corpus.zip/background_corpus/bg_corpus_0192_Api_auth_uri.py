def auth_uri(self):

        """The authorzation URL that should be provided to the user"""

        return self.oauth.auth_uri(redirect_uri=self.redirect_uri, scope=self.scope)
