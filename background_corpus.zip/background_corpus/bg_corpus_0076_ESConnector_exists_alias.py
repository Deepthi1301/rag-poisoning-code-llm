def exists_alias(self, alias_name, index_name=None):
        """Check whether or not the given alias exists

        :return: True if alias already exist"""

        return self._es_conn.indices.exists_alias(index=index_name, name=alias_name)
