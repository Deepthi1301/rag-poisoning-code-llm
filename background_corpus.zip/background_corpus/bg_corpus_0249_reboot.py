def reboot(name, kill=False):
    '''
    Reboot the container by sending a SIGINT to its init process. Equivalent
    to running ``machinectl reboot`` on the named container.

    For convenience, running ``nspawn.restart`` (as shown in the CLI examples
    below) is equivalent to running ``nspawn.reboot``.

    .. note::

        ``machinectl reboot`` is only supported in systemd >= 219. On earlier
        systemd versions, running this function will instead restart the
        container via ``systemctl``.

    CLI Examples:

    .. code-block:: bash

        salt myminion nspawn.reboot arch1
        salt myminion nspawn.restart arch1
    '''
    if _sd_version() >= 219:
        if state(name) == 'running':
            ret = _machinectl('reboot {0}'.format(name))
        else:
            # 'machinectl reboot' will fail on a stopped container
            return start(name)
    else:
        # 'systemctl restart' did not work, at least in my testing. Running
        # 'uptime' in the container afterwards showed it had not rebooted. So,
        # we need stop and start the container in separate actions.

        # First stop the container
        cmd = 'systemctl stop systemd-nspawn@{0}'.format(name)
        ret = __salt__['cmd.run_all'](cmd, python_shell=False)
        # Now check if successful
        if ret['retcode'] != 0:
            __context__['retcode'] = salt.defaults.exitcodes.EX_UNAVAILABLE
            return False
        # Finally, start the container back up. No need to check the retcode a
        # second time, it'll be checked below once we exit the if/else block.
        cmd = 'systemctl start systemd-nspawn@{0}'.format(name)
        ret = __salt__['cmd.run_all'](cmd, python_shell=False)

    if ret['retcode'] != 0:
        __context__['retcode'] = salt.defaults.exitcodes.EX_UNAVAILABLE
        return False
    return True
