def _set_management(self, v, load=False):
    """
    Setter method for management, mapped from YANG variable /interface/management (list)
    If this variable is read-only (config: false) in the
    source YANG file, then _set_management is considered as a private
    method. Backends looking to populate this variable should
    do so via calling thisObj._set_management() directly.

    YANG Description: The list of management interfaces in the managed 
device. Each row represents a management interface.
    """
    if hasattr(v, "_utype"):
      v = v._utype(v)
    try:
      t = YANGDynClass(v,base=YANGListType("name",management.management, yang_name="management", rest_name="Management", parent=self, is_container='list', user_ordered=False, path_helper=self._path_helper, yang_keys='name', extensions={u'tailf-common': {u'info': u'The list of management interfaces.', u'cli-suppress-table': None, u'sort-priority': u'RUNNCFG_LEVEL_INTERFACE_TYPE_MGMT', u'cli-suppress-no': None, u'alt-name': u'Management', u'cli-no-match-completion': None, u'cli-full-command': None, u'callpoint': u'ipv4staticcpt'}}), is_container='list', yang_name="management", rest_name="Management", parent=self, path_helper=self._path_helper, extmethods=self._extmethods, register_paths=True, extensions={u'tailf-common': {u'info': u'The list of management interfaces.', u'cli-suppress-table': None, u'sort-priority': u'RUNNCFG_LEVEL_INTERFACE_TYPE_MGMT', u'cli-suppress-no': None, u'alt-name': u'Management', u'cli-no-match-completion': None, u'cli-full-command': None, u'callpoint': u'ipv4staticcpt'}}, namespace='urn:brocade.com:mgmt:brocade-interface', defining_module='brocade-interface', yang_type='list', is_config=True)
    except (TypeError, ValueError):
      raise ValueError({
          'error-string': """management must be of a type compatible with list""",
          'defined-type': "list",
          'generated-type': """YANGDynClass(base=YANGListType("name",management.management, yang_name="management", rest_name="Management", parent=self, is_container='list', user_ordered=False, path_helper=self._path_helper, yang_keys='name', extensions={u'tailf-common': {u'info': u'The list of management interfaces.', u'cli-suppress-table': None, u'sort-priority': u'RUNNCFG_LEVEL_INTERFACE_TYPE_MGMT', u'cli-suppress-no': None, u'alt-name': u'Management', u'cli-no-match-completion': None, u'cli-full-command': None, u'callpoint': u'ipv4staticcpt'}}), is_container='list', yang_name="management", rest_name="Management", parent=self, path_helper=self._path_helper, extmethods=self._extmethods, register_paths=True, extensions={u'tailf-common': {u'info': u'The list of management interfaces.', u'cli-suppress-table': None, u'sort-priority': u'RUNNCFG_LEVEL_INTERFACE_TYPE_MGMT', u'cli-suppress-no': None, u'alt-name': u'Management', u'cli-no-match-completion': None, u'cli-full-command': None, u'callpoint': u'ipv4staticcpt'}}, namespace='urn:brocade.com:mgmt:brocade-interface', defining_module='brocade-interface', yang_type='list', is_config=True)""",
        })

    self.__management = t
    if hasattr(self, '_set'):
      self._set()
