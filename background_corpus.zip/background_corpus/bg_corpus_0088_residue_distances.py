def residue_distances(res_1_num, res_1_chain, res_2_num, res_2_chain, model):
    """Distance between the last atom of 2 residues"""

    res1 = model[res_1_chain][res_1_num].child_list[-1]
    res2 = model[res_2_chain][res_2_num].child_list[-1]
    distance = res1 - res2

    return distance
