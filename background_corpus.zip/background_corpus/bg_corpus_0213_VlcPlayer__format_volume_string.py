def _format_volume_string(self, volume_string):
        """ format vlc's volume """
        self.actual_volume = int(volume_string.split(self.volume_string)[1].split(',')[0].split()[0])
        return '[Vol: {}%] '.format(int(100 * self.actual_volume / self.max_volume))
