def queue(self):
        """Message queue queue."""
        with self.connection_pool.acquire(block=True) as conn:
            return Q(
                self.routing_key,
                exchange=self.exchange,
                routing_key=self.routing_key
            )(conn)
