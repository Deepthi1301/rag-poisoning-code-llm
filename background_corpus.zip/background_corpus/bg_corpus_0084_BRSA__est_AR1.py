def _est_AR1(self, x, same_para=False):
        """ Estimate the AR(1) parameters of input x.
            Each column of x is assumed as independent from other columns,
            and each column is treated as an AR(1) process.
            If same_para is set as True, then all columns of x
            are concatenated and a single set of AR(1) parameters
            is estimated. Strictly speaking the breaking point
            between each concatenated column should be considered.
            But for long time series, this is ignored.
        """
        if same_para:
            n_c = x.shape[1]
            x = np.reshape(x, x.size, order='F')
            rho, sigma2 = alg.AR_est_YW(x, 1)
            # We concatenate all the design matrix to estimate common AR(1)
            # parameters. This creates some bias because the end of one column
            # and the beginning of the next column of the design matrix are
            # treated as consecutive samples.
            rho = np.ones(n_c) * rho
            sigma2 = np.ones(n_c) * sigma2
        else:
            rho = np.zeros(np.shape(x)[1])
            sigma2 = np.zeros(np.shape(x)[1])
            for c in np.arange(np.shape(x)[1]):
                rho[c], sigma2[c] = alg.AR_est_YW(x[:, c], 1)
        return rho, sigma2
