def enrich_fields(cls, fields, eitem):
        """Enrich the fields property of an issue.

        Loops through al properties in issue['fields'],
        using those that are relevant to enrich eitem with new properties.
        Those properties are user defined, depending on options
        configured in Jira. For example, if SCRUM is activated,
        we have a field named "Story Points".

        :param fields: fields property of an issue
        :param eitem: enriched item, which will be modified adding more properties
        """

        for field in fields:
            if field.startswith('customfield_'):
                if type(fields[field]) is dict:
                    if 'name' in fields[field]:
                        if fields[field]['name'] == "Story Points":
                            eitem['story_points'] = fields[field]['value']
                        elif fields[field]['name'] == "Sprint":
                            value = fields[field]['value']
                            if value:
                                sprint = value[0].partition(",name=")[2].split(',')[0]
                                sprint_start = value[0].partition(",startDate=")[2].split(',')[0]
                                sprint_end = value[0].partition(",endDate=")[2].split(',')[0]
                                sprint_complete = value[0].partition(",completeDate=")[2].split(',')[0]
                                eitem['sprint'] = sprint
                                eitem['sprint_start'] = cls.fix_value_null(sprint_start)
                                eitem['sprint_end'] = cls.fix_value_null(sprint_end)
                                eitem['sprint_complete'] = cls.fix_value_null(sprint_complete)
