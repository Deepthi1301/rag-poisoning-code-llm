def gamma(phi1,phi2,theta1,theta2):
    """
    calculate third rotation angle
    inputs are angles from 2 pulsars
    returns the angle.
    
    """
    
    if phi1 == phi2 and theta1 == theta2:
        gamma = 0
    else:
        gamma = atan( sin(theta2)*sin(phi2-phi1) / \
                      (cos(theta1)*sin(theta2)*cos(phi1-phi2) - \
                       sin(theta1)*cos(theta2)) )

    dummy_arg = (cos(gamma)*cos(theta1)*sin(theta2)*cos(phi1-phi2) + \
                 sin(gamma)*sin(theta2)*sin(phi2-phi1) - \
                 cos(gamma)*sin(theta1)*cos(theta2))
        
    if dummy_arg >= 0:
        return gamma
    else:
        return pi + gamma
