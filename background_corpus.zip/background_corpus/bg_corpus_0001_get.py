def get(name, *args, **kwargs):
    """Find command class for given command name and return it's instance

    :param name: str
    :param args: additional arguments for Command
    :param kwargs: additional arguments for Command
    :return: Command
    """
    cmd = COMMAND_MAPPER.get(name)
    return cmd(*args, **kwargs)
