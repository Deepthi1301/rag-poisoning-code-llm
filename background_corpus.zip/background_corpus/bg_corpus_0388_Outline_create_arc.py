def create_arc(self, mace_type, name):
        '''
        Creates the story arc and initial tree for that arc
        for the current outline. Returns the resulting Arc
        instance.
        '''
        arc = Arc(mace_type=mace_type, outline=self, name=name)
        arc.save()
        milestone_count = arc.generate_template_arc_tree()
        if milestone_count == 7:  # pragma: no cover
            arc.refresh_from_db()
            return arc
        else:
            raise ArcIntegrityError('Something went wrong during arc template generation')
