def getStatus(self) :
        """returns a word describing the status of the collection (loaded, loading, deleted, unloaded, newborn) instead of a number, if you prefer the number it's in self.status"""
        if self.status == CONST.COLLECTION_LOADING_STATUS :
            return "loading"
        elif self.status == CONST.COLLECTION_LOADED_STATUS :
            return "loaded"
        elif self.status == CONST.COLLECTION_DELETED_STATUS :
            return "deleted"
        elif self.status == CONST.COLLECTION_UNLOADED_STATUS :
            return "unloaded"
        elif self.status == CONST.COLLECTION_NEWBORN_STATUS :
            return "newborn"
        else :
            raise ValueError("The collection has an Unknown status %s" % self.status)
