def translate(cores, files, args):
    """
    translate is used for Processing per core translation. cores[i] will translate files[i]

    :param cores: the number of cores used for translation, each core will launch a thread to translate
    :param files: file list to be translated
    :param args: input parameters
    :return: list of translated file
    """
    model = args.module
    batchsize = args.batch_size

    # split inputfile to a series of small files which number is equal cores
    file = []
    thread = []
    for i in range(cores):
        files[i].seek(0)
        temp = tempfile.NamedTemporaryFile()
        command = "taskset -c %d-%d python3 -m sockeye.translate -m %s -i %s -o %s --batch-size %d --output-type benchmark --use-cpu > /dev/null 2>&1 " % (i, i, model, files[i].name, temp.name, batchsize)
        file.append(temp)

        t = threading.Thread(target = task, args=(command,))
        thread.append(t) 
        t.start()
    #wait for all translation done
    for t in thread:
        t.join()
    
    return file
