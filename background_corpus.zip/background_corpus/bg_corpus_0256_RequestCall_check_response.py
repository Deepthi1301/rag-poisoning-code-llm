def check_response(self, resp):
        """
        Checks response after request was made.
        Checks status of the response, mainly

        :param resp:
        :return:
        """

        # For successful API call, response code will be 200 (OK)
        if resp.ok:
            json = resp.json()
            self.response = ResponseHolder()
            self.response.response = json

            # Check the code
            if 'status' not in json:
                raise InvalidResponse('No status field')

            self.response.status = self.field_to_long(json['status'])
            if self.response.status != EBConsts.STATUS_OK:
                txt_status = self.get_text_status(json)
                raise InvalidStatus('Status is %s (%04X)'
                                    % (txt_status if txt_status is not None else "", self.response.status))

            if self.response_checker is not None:
                self.response_checker(self.response)

            return self.response

        else:
            # If response code is not ok (200), print the resulting http error code with description
            resp.raise_for_status()
        pass
