def _invoke(task, args):
	'''Invoke a task with the appropriate args; return the remaining args.'''
	kwargs = task.defaults.copy()
	if task.kwargs:
		temp_kwargs, args = getopt.getopt(args, '', task.kwargs)
		temp_kwargs = _opts_to_dict(*temp_kwargs)
		kwargs.update(temp_kwargs)

	if task.args:
		for arg in task.args:
			if not len(args):
				abort(LOCALE['error_wrong_args'], task, len(task.args))
			kwargs.update({arg: args[0]})
			args = args[1:]

	if task.consume:
		task(*args, **kwargs)
		return []
	else:
		task(**kwargs)
		return args
