def fetch_as_element(self, **kw):
        """
        Fetch the results and return as a Connection element. The original
        query is not modified.
        
        :return: generator of elements
        :rtype: :class:`.Connection`
        """
        clone = self.copy()
        clone.format.field_format('id')
        for custom_field in ['field_ids', 'field_names']:
            clone.format.data.pop(custom_field, None)

        for list_of_results in clone.fetch_raw(**kw):
            for entry in list_of_results:
                yield Connection(**entry)
