def set_sdc_name(self, name, sdcObj):
        """
        Set name for SDC
        :param name: Name of SDC
        :param sdcObj: ScaleIO SDC object
        :return: POST request response
        :rtype: Requests POST response object
        """
        # TODO:
        # Check if object parameters are the correct ones, otherwise throw error
        self.conn.connection._check_login()
        sdcNameDict = {'sdcName': name}
        response = self.conn.connection._do_post("{}/{}{}/{}".format(self.conn.connection._api_url, "instances/Sdc::", sdcObj.id, 'action/setSdcName'), json=sdcNameDict)    
        return response
