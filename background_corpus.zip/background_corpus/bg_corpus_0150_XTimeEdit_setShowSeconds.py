def setShowSeconds(self, state=True):
        """
        Sets whether or not to display the seconds combo box for this widget.

        :param      state | <bool>
        """
        self._showSeconds = state
        if state:
            self._minuteSeparator.show()
            self._secondCombo.show()
        else:
            self._minuteSeparator.hide()
            self._secondCombo.hide()
