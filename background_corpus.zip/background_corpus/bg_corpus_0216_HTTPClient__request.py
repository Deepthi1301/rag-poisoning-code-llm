def _request(self, method, path, payload=None, headers=None):
        """HTTP operation.

        :param method: Operation type (e.g. post)
        :param path: URI Path
        :param payload: HTTP Body
        :param headers: HTTP Headers

        :raises ApiError: Raises if the remote server encountered an error.
        :raises ApiConnectionError: Raises if there was a connectivity issue.

        :return: Response
        """
        url = urlparse.urljoin(self._base_url, 'api/%s' % path)
        headers = headers or {}
        headers['content-type'] = 'application/json'
        try:
            response = requests.request(
                method, url,
                auth=self._auth,
                data=payload,
                headers=headers,
                cert=self._cert,
                verify=self._verify,
                timeout=self._timeout
            )
        except requests.RequestException as why:
            raise ApiConnectionError(str(why))

        json_response = self._get_json_output(response)
        self._check_for_errors(response, json_response)
        return json_response
