def _cmp(self, other):
        """
        Comparator function for two :class:`~pywbem.CIMMethod` objects.

        The comparison is based on their public attributes, in descending
        precedence:

        * `name`
        * `qualifiers`
        * `parameters`
        * `return_type`
        * `class_origin`
        * `propagated`

        The comparison takes into account any case insensitivities described
        for these attributes.
        """
        if self is other:
            return 0
        try:
            assert isinstance(other, CIMMethod)
        except AssertionError:
            raise TypeError(
                _format("other must be CIMMethod, but is: {0}", type(other)))
        return (cmpname(self.name, other.name) or
                cmpdict(self.qualifiers, other.qualifiers) or
                cmpdict(self.parameters, other.parameters) or
                cmpitem(self.return_type, other.return_type) or
                cmpname(self.class_origin, other.class_origin) or
                cmpitem(self.propagated, other.propagated))
