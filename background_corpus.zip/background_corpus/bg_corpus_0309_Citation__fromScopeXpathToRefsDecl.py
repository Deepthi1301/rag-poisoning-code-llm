def _fromScopeXpathToRefsDecl(self, scope, xpath):
        """ Update xpath and scope property when refsDecl is updated

        """
        if scope is not None and xpath is not None:
            _xpath = scope + xpath
            i = _xpath.find("?")
            ii = 1
            while i >= 0:
                _xpath = _xpath[:i] + "$" + str(ii) + _xpath[i+1:]
                i = _xpath.find("?")
                ii += 1
            self.refsDecl = _xpath
