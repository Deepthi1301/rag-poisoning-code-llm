def stop_cont(self, cont=True):
        """Send SIGSTOP/SIGCONT to processes called <name>
        """
        for proc in psutil.process_iter():
            if proc.name() == self.process_name:
                sig = psutil.signal.SIGCONT if cont else psutil.signal.SIGSTOP
                proc.send_signal(sig)
                if self.debug:
                    sig = 'CONT' if cont else 'STOP'
                    print("Sent SIG%s to process %d" % (sig, proc.pid))
