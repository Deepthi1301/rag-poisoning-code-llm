def setShowMinutes(self, state=True):
        """
        Sets whether or not to display the minutes combo box for this widget.

        :param      state | <bool>
        """
        self._showMinutes = state
        if state:
            self._minuteCombo.show()
        else:
            self._minuteCombo.hide()
