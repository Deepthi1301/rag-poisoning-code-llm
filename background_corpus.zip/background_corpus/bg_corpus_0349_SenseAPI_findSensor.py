def findSensor(self, sensors, sensor_name, device_type = None):
        """
            Find a sensor in the provided list of sensors
            
            @param sensors (list) - List of sensors to search in
            @param sensor_name (string) - Name of sensor to find
            @param device_type (string) - Device type of sensor to find, can be None
            
            @return (string) - sensor_id of sensor or None if not found
        """

        if device_type == None:
            for sensor in sensors:
                if sensor['name'] == sensor_name:
                    return sensor['id']
        else:
            for sensor in sensors:
                if sensor['name'] == sensor_name and sensor['device_type'] == device_type:
                    return sensor['id']

        return None
