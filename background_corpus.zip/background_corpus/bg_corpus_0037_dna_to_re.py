def dna_to_re(seq):
    """
    Return a compiled regular expression that will match anything described by 
    the input sequence.  For example, a sequence that contains a 'N' matched 
    any base at that position.
    """

    seq = seq.replace('K', '[GT]')
    seq = seq.replace('M', '[AC]')
    seq = seq.replace('R', '[AG]')
    seq = seq.replace('Y', '[CT]')
    seq = seq.replace('S', '[CG]')
    seq = seq.replace('W', '[AT]')
    seq = seq.replace('B', '[CGT]')
    seq = seq.replace('V', '[ACG]')
    seq = seq.replace('H', '[ACT]')
    seq = seq.replace('D', '[AGT]')
    seq = seq.replace('X', '[GATC]')
    seq = seq.replace('N', '[GATC]')

    return re.compile(seq)
