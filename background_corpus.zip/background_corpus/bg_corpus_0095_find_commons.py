def find_commons(lists):
    """Finds common values

    :param lists: List of lists
    :return: List of values that are in common between inner lists
    """
    others = lists[1:]
    return [
        val
        for val in lists[0]
        if is_in_all(val, others)
    ]
