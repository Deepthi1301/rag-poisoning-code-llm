def binarize_percent(netin, level, sign='pos', axis='time'):
    """
    Binarizes a network proprtionally. When axis='time' (only one available at the moment) then the top values for each edge time series are considered.

    Parameters
    ----------

    netin : array or dict
        network (graphlet or contact representation),
    level : float
        Percent to keep (expressed as decimal, e.g. 0.1 = top 10%)
    sign : str, default='pos'
        States the sign of the thresholding. Can be 'pos', 'neg' or 'both'. If "neg", only negative values are thresholded and vice versa.
    axis : str, default='time'
        Specify which dimension thresholding is applied against. Can be 'time' (takes top % for each edge time-series) or 'graphlet' (takes top % for each graphlet)

    Returns
    -------

    netout : array or dict (depending on input)
        Binarized network

    """
    netin, netinfo = process_input(netin, ['C', 'G', 'TO'])
    # Set diagonal to 0
    netin = set_diagonal(netin, 0)
    if axis == 'graphlet' and netinfo['nettype'][-1] == 'u':
        triu = np.triu_indices(netinfo['netshape'][0], k=1)
        netin = netin[triu[0], triu[1], :]
        netin = netin.transpose()
    if sign == 'both':
        net_sorted = np.argsort(np.abs(netin), axis=-1)
    elif sign == 'pos':
        net_sorted = np.argsort(netin, axis=-1)
    elif sign == 'neg':
        net_sorted = np.argsort(-1*netin, axis=-1)
    else:
        raise ValueError('Unknown value for parameter: sign')
    # Predefine
    netout = np.zeros(netinfo['netshape'])
    if axis == 'time':
        # These for loops can probabaly be removed for speed
        for i in range(netinfo['netshape'][0]):
            for j in range(netinfo['netshape'][1]):
                netout[i, j, net_sorted[i, j, -
                                        int(round(net_sorted.shape[-1])*level):]] = 1
    elif axis == 'graphlet':
        netout_tmp = np.zeros(netin.shape)
        for i in range(netout_tmp.shape[0]):
            netout_tmp[i, net_sorted[i, -
                                     int(round(net_sorted.shape[-1])*level):]] = 1
        netout_tmp = netout_tmp.transpose()
        netout[triu[0], triu[1], :] = netout_tmp
        netout[triu[1], triu[0], :] = netout_tmp

    netout = set_diagonal(netout, 0)

    # If input is contact, output contact
    if netinfo['inputtype'] == 'C':
        netinfo['nettype'] = 'b' + netinfo['nettype'][1]
        netout = graphlet2contact(netout, netinfo)
        netout.pop('inputtype')
        netout.pop('values')
        netout['diagonal'] = 0

    return netout
