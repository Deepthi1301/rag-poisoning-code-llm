def create_dscp_marking_rule(self, policy, body=None):
        """Creates a new DSCP marking rule."""
        return self.post(self.qos_dscp_marking_rules_path % policy,
                         body=body)
