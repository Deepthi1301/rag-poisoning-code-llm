def execute_pending_service_agreements(storage_path, account, actor_type, did_resolver_fn):
    """
     Iterates over pending service agreements recorded in the local storage,
    fetches their service definitions, and subscribes to service agreement events.

    :param storage_path: storage path for the internal db, str
    :param account:
    :param actor_type:
    :param did_resolver_fn:
    :return:
    """
    keeper = Keeper.get_instance()
    # service_agreement_id, did, service_definition_id, price, files, start_time, status
    for (agreement_id, did, _,
         price, files, start_time, _) in get_service_agreements(storage_path):

        ddo = did_resolver_fn(did)
        for service in ddo.services:
            if service.type != 'Access':
                continue

            consumer_provider_tuple = keeper.escrow_access_secretstore_template.get_agreement_data(
                agreement_id)
            if not consumer_provider_tuple:
                continue

            consumer, provider = consumer_provider_tuple
            did = ddo.did
            service_agreement = ServiceAgreement.from_service_dict(service.as_dictionary())
            condition_ids = service_agreement.generate_agreement_condition_ids(
                agreement_id, did, consumer, provider, keeper)

            if actor_type == 'consumer':
                assert account.address == consumer
                process_agreement_events_consumer(
                    provider, agreement_id, did, service_agreement,
                    price, account, condition_ids, None)
            else:
                assert account.address == provider
                process_agreement_events_publisher(
                    account, agreement_id, did, service_agreement,
                    price, consumer, condition_ids)
