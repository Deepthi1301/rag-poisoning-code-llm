def installed(cls):
        """
        Used in ``yacms.pages.views.page`` to ensure
        ``PageMiddleware`` or a subclass has been installed. We cache
        the result on the ``PageMiddleware._installed`` to only run
        this once. Short path is to just check for the dotted path to
        ``PageMiddleware`` in ``MIDDLEWARE_CLASSES`` - if not found,
        we need to load each middleware class to match a subclass.
        """
        try:
            return cls._installed
        except AttributeError:
            name = "yacms.pages.middleware.PageMiddleware"
            mw_setting = get_middleware_setting()
            installed = name in mw_setting
            if not installed:
                for name in mw_setting:
                    if issubclass(import_dotted_path(name), cls):
                        installed = True
                        break
            setattr(cls, "_installed", installed)
            return installed
