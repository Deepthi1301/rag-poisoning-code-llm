def next(self):
        """
        Returns new CharacterDataWrapper
        TODO: Don't raise offset past count - limit
        """
        self.params['offset'] = str(int(self.params['offset']) + int(self.params['limit']))
        return self.marvel.get_characters(self.marvel, (), **self.params)
