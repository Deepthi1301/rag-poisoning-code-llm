def ensure_exists(p, assume_dirs=False):
    """
    Ensures a given path *p* exists.

    If a path to a file is passed in, then the path to the file will be checked. This can be overridden by passing a
    value of ``True`` to ``assume_dirs``, in which case the paths will be assumed to be to directories, not files.
    """
    if Path(p).ext and not assume_dirs:
        Path(p).dirname().makedirs_p()
    else:
        Path(p).makedirs_p()
    return p
