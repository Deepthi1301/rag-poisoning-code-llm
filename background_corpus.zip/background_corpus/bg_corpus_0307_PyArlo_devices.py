def devices(self):
        """Return all devices on Arlo account."""
        if self._all_devices:
            return self._all_devices

        self._all_devices = {}
        self._all_devices['cameras'] = []
        self._all_devices['base_station'] = []

        url = DEVICES_ENDPOINT
        data = self.query(url)

        for device in data.get('data'):
            name = device.get('deviceName')
            if ((device.get('deviceType') == 'camera' or
                 device.get('deviceType') == 'arloq' or
                 device.get('deviceType') == 'arloqs') and
                    device.get('state') == 'provisioned'):
                camera = ArloCamera(name, device, self)
                self._all_devices['cameras'].append(camera)

            if (device.get('state') == 'provisioned' and
                    (device.get('deviceType') == 'basestation' or
                     device.get('modelId') == 'ABC1000')):
                base = ArloBaseStation(name, device, self.__token, self)
                self._all_devices['base_station'].append(base)

        return self._all_devices
