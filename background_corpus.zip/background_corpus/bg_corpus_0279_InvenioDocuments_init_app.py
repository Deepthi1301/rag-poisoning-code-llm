def init_app(self, app):
        """Flask application initialization."""
        app.extensions['invenio-documents'] = self
        app.cli.add_command(cmd)
