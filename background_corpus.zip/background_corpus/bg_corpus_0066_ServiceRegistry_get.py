def get(self, eid):
		"""
		Returns a dict with the complete record of the entity with the given eID 
		"""
		data = self._http_req('connections/%u' % eid)
		self.debug(0x01, data['decoded'])
		return data['decoded']
