def range_per(self):
    """ Range percentage
        計算最新日之漲跌幅度百分比
    """
    rp = float((self.raw_data[-1] - self.raw_data[-2]) / self.raw_data[-2] * 100)
    return rp
