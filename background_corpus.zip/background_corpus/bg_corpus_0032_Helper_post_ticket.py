def post_ticket(self, title, body):
        '''post_ticket will post a ticket to the uservoice helpdesk

           Parameters
           ==========
           title: the title (subject) of the issue
           body: the message to send

        '''

        # Populate the ticket
        ticket = {'subject': title,
                  'message': body }

        response = self.client.post("/api/v1/tickets.json", {
                                    'email': self.email,
                                    'ticket': ticket })['ticket']
        bot.info(response['url'])
