def write_json_to_file(path, data):
    """
    Writes data as json to file.

    Parameters:
        path (str): Path to write to
        data (dict, list): Data
    """
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f)
