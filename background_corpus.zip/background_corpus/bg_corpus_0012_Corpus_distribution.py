def distribution(self, **slice_kwargs):
        """
        Calculates the number of papers in each slice, as defined by
        ``slice_kwargs``.

        Examples
        --------
        .. code-block:: python

           >>> corpus.distribution(step_size=1, window_size=1)
           [5, 5]

        Parameters
        ----------
        slice_kwargs : kwargs
            Keyword arguments to be passed to :meth:`.Corpus.slice`\.

        Returns
        -------
        list
        """
        values = []
        keys = []

        for key, size in self.slice(count_only=True, **slice_kwargs):
            values.append(size)
            keys.append(key)
        return keys, values
