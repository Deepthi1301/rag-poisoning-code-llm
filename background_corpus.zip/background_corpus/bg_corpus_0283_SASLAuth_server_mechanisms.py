def server_mechanisms(self):
        """List of available :class:`ServerMechanism` objects."""
        return [mech for mech in self.mechs.values()
                if isinstance(mech, ServerMechanism)]
