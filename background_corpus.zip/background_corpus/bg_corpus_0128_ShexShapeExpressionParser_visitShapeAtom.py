def visitShapeAtomNodeConstraint(self, ctx: ShExDocParser.ShapeAtomNodeConstraintContext):
        """  shapeAtomNodeConstraint: nodeConstraint shapeOrRef?  # shapeAtomNodeConstraint """
        nc = ShexNodeExpressionParser(self.context)
        nc.visit(ctx.nodeConstraint())
        if ctx.shapeOrRef():
            self.expr = ShapeAnd(id=self.label, shapeExprs=[nc.nodeconstraint])
            sorref_parser = ShexShapeExpressionParser(self.context)
            sorref_parser.visit(ctx.shapeOrRef())
            # if isinstance(sorref_parser.expr, Shape) and self.context.is_empty_shape(sorref_parser.expr):
            #     self.expr = nc.nodeconstraint
            #     self.expr.id = self.label
            # else:
            self.expr.shapeExprs.append(sorref_parser.expr)
        else:
            self.expr = nc.nodeconstraint
            self.expr.id = self.label
