def _android_get_installed_platform_tools_version(self):
        """
        Crudely parse out the installed platform-tools version
        """

        platform_tools_dir = os.path.join(
            self.android_sdk_dir,
            'platform-tools')

        if not os.path.exists(platform_tools_dir):
            return None

        data_file = os.path.join(platform_tools_dir, 'source.properties')
        if not os.path.exists(data_file):
            return None

        with open(data_file, 'r') as fileh:
            lines = fileh.readlines()

        for line in lines:
            if line.startswith('Pkg.Revision='):
                break
        else:
            self.buildozer.error('Read {} but found no Pkg.Revision'.format(data_file))
            # Don't actually exit, in case the build env is
            # okay. Something else will fault if it's important.
            return None

        revision = line.split('=')[1].strip()

        return revision
