def _depression_adjustment(self, elevation):
        """Calculate the extra degrees of depression due to the increase in elevation.

        :param elevation: Elevation above the earth in metres
        :type  elevation: float
        """

        if elevation <= 0:
            return 0

        r = 6356900 # radius of the earth
        a1 = r
        h1 = r + elevation
        theta1 = acos(a1 / h1)

        a2 = r * sin(theta1)
        b2 = r - (r * cos(theta1))
        h2 = sqrt(pow(a2, 2) + pow(b2, 2))
        alpha = acos(a2 / h2)

        return degrees(alpha)
