def to_xml(self):
        """
        Serialize to XML.
        """
        body = ''
        for k in ['warning', 'error', 'notice']:
            for msg in self.__dict__[k + 's']:
                body += '\n  <%s>%s</%s>' % (k, msg, k)
        return '<report valid="%s">%s\n</report>' % ("true" if self.is_valid else "false", body)
