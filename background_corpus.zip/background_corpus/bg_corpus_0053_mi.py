def mi(mi, iq=None, pl=None):
    # pylint: disable=redefined-outer-name
    """
    This function is a wrapper for
    :meth:`~pywbem.WBEMConnection.ModifyInstance`.

    Modify the property values of an instance.

    Parameters:

      mi (:class:`~pywbem.CIMInstance`):
          Modified instance, also indicating its instance path.

          The properties defined in this object specify the new property
          values for the instance to be modified. Missing properties
          (relative to the class declaration) and properties provided with
          a value of `None` will be set to NULL.

      iq (:class:`py:bool`):
          IncludeQualifiers flag: Modify instance qualifiers as specified in
          the instance.

          `None` will cause the server default of `True` to be used.

          Deprecated in :term:`DSP0200`: Clients cannot rely on qualifiers to
          be modified by this operation.

      pl (:term:`string` or :term:`py:iterable` of :term:`string`):
          PropertyList: Names of properties to be modified. An empty iterable
          indicates to modify no properties. If `None`, all properties exposed
          by the instance will be modified.
    """

    CONN.ModifyInstance(mi,
                        IncludeQualifiers=iq,
                        PropertyList=pl)
