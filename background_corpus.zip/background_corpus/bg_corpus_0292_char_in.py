def char_in(string, func_name): 
  '''return current char and step if char is in string, where 
   @test: a python function with one argument, which tests on one char and return True or False
          @test must be registered with register_function'''
  function = register_function(func_name, 
                      lambda char: char in string)
  return char_on_predicate(function)
