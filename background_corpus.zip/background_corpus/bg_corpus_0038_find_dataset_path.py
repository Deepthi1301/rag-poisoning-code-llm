def find_dataset_path(dataset, data_home=None, fname=None, ext=".csv.gz", raises=True):
    """
    Looks up the path to the dataset specified in the data home directory,
    which is found using the ``get_data_home`` function. By default data home
    is colocated with the code, but can be modified with the YELLOWBRICK_DATA
    environment variable, or passing in a different directory.

    The file returned will be by default, the name of the dataset in compressed
    CSV format. Other files and extensions can be passed in to locate other data
    types or auxilliary files.

    If the dataset is not found a ``DatasetsError`` is raised by default.

    Parameters
    ----------
    dataset : str
        The name of the dataset; should either be a folder in data home or
        specified in the yellowbrick.datasets.DATASETS variable.

    data_home : str, optional
        The path on disk where data is stored. If not passed in, it is looked
        up from YELLOWBRICK_DATA or the default returned by ``get_data_home``.

    fname : str, optional
        The filename to look up in the dataset path, by default it will be the
        name of the dataset. The fname must include an extension.

    ext : str, default: ".csv.gz"
        The extension of the data to look up in the dataset path, if the fname
        is specified then the ext parameter is ignored. If ext is None then
        the directory of the dataset will be returned.

    raises : bool, default: True
        If the path does not exist, raises a DatasetsError unless this flag is set
        to False, at which point None is returned (e.g. for checking if the
        path exists or not).

    Returns
    -------
    path : str or None
        A path to the requested file, guaranteed to exist if an exception is
        not raised during processing of the request (unless None is returned).

    raises : DatasetsError
        If raise is True and the path does not exist, raises a DatasetsError.
    """
    # Figure out the root directory of the datasets
    data_home = get_data_home(data_home)

    # Figure out the relative path to the dataset
    if fname is None:
        if ext is None:
            path = os.path.join(data_home, dataset)
        else:
            path = os.path.join(data_home, dataset, "{}{}".format(dataset, ext))
    else:
        path = os.path.join(data_home, dataset, fname)

    # Determine if the path exists
    if not os.path.exists(path):

        # Suppress exceptions if required
        if not raises:
            return None

        raise DatasetsError((
            "could not find dataset at {} - does it need to be downloaded?"
        ).format(path))

    return path
