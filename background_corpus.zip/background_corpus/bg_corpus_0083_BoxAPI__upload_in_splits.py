def _upload_in_splits( self, destination_folder_id, source_path, preflight_check, verbose = True, chunked_upload_threads = 5 ):
        '''
        Since Box has a maximum file size limit (15 GB at time of writing),
        we need to split files larger than this into smaller parts, and chunk upload each part
        '''
        file_size = os.stat(source_path).st_size
        split_size = BOX_MAX_FILE_SIZE

        # Make sure that the last split piece is still big enough for a chunked upload
        while file_size % split_size < BOX_MIN_CHUNK_UPLOAD_SIZE:
            split_size -= 1000
            if split_size < BOX_MIN_CHUNK_UPLOAD_SIZE:
                raise Exception('Lazy programming error')

        split_start_byte = 0
        part_count = 0
        uploaded_file_ids = []
        while split_start_byte < file_size:
            dest_file_name = '{0}.part{1}'.format( os.path.basename(source_path), part_count)
            prev_uploaded_file_ids = self.find_file( destination_folder_id, dest_file_name )
            if len( prev_uploaded_file_ids ) == 1:
                if verbose:
                    print ( '\nSkipping upload of split {0} of {1}; already exists'.format( part_count + 1, math.ceil(file_size / split_size) ) )
                uploaded_file_ids.extend( prev_uploaded_file_ids )
            else:
                if verbose:
                    print ( '\nUploading split {0} of {1}'.format( part_count + 1, math.ceil(file_size / split_size) ) )
                uploaded_file_ids.append( self._chunked_upload(
                    destination_folder_id, source_path,
                    dest_file_name = dest_file_name,
                    split_start_byte = split_start_byte,
                    file_size = min(split_size, file_size - split_start_byte), # Take the min of file_size - split_start_byte so that the last part of a split doesn't read into the next split
                    preflight_check = preflight_check,
                    verbose = verbose,
                    upload_threads = chunked_upload_threads,
                ) )
            part_count += 1
            split_start_byte += split_size

        return uploaded_file_ids
