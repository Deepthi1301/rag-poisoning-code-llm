def book_status(self, ctrlno):
        """
        查看图书借阅情况
        :param ctrlno: 图书馆系统图书唯一标识
        :return: {
            'isbn': '',
            'status_list': [],
        }
        """
        result = {
            'isbn': '',
            'status_list': [],
        }
        html = self.__book_status_html(ctrlno)
        soup = BeautifulSoup(html)

        tds = soup.select(selector='tbody')[0].select('td')
        cursor = 1
        while cursor < len(tds) / 7:
            s = (cursor - 1) * 7
            location = tds[s].get_text().strip('\r\n ')
            index_num = tds[s + 1].get_text().strip('\r\n ')
            login_num = tds[s + 2].get_text().strip('\r\n ')
            volume = tds[s + 3].get_text().strip('\r\n ')
            year = tds[s + 4].get_text().strip('\r\n ')
            status = tds[s + 5].get_text().strip('\r\n ')
            type = tds[s + 6].get_text().strip('\r\n ')

            info = {
                'location': location,  # 馆藏地
                'index_num': index_num,  # 索取号
                'login_num': login_num,  # 登录号
                'volume': volume,  # 卷期
                'year': year,  # 年代
                'status': status,  # 状态
                'type': type,  # 借阅类型
            }
            result['status_list'].append(info)
            cursor += 1
        # isbn
        result['isbn'] = self.__get_isbn(html)
        return result
