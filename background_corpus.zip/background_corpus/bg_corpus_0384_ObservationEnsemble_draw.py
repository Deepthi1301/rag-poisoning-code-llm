def draw(self,cov,num_reals):
        """ draw realizations of observation noise and add to mean_values
        Note: only draws noise realizations for non-zero weighted observations
        zero-weighted observations are set to mean value for all realizations

        Parameters
        ----------
        cov : pyemu.Cov
            covariance matrix that describes the support volume around the
            mean values.
        num_reals : int
            number of realizations to draw

        """
        super(ObservationEnsemble,self).draw(cov,num_reals,
                                             names=self.pst.nnz_obs_names)
        self.loc[:,self.names] += self.pst.observation_data.obsval
