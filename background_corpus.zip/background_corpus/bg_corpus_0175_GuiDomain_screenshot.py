def screenshot(self, viewID, filename):
        """screenshot(string, string) -> None

        Save a screenshot for the given view to the given filename.
        The fileformat is guessed from the extension, the available
        formats differ from platform to platform but should at least
        include ps, svg and pdf, on linux probably gif, png and jpg as well.
        """
        self._connection._sendStringCmd(
            tc.CMD_SET_GUI_VARIABLE, tc.VAR_SCREENSHOT, viewID, filename)
