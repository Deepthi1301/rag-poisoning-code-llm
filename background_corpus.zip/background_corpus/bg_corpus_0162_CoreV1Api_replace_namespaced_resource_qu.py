def replace_namespaced_resource_quota_status(self, name, namespace, body, **kwargs):  # noqa: E501
        """replace_namespaced_resource_quota_status  # noqa: E501

        replace status of the specified ResourceQuota  # noqa: E501
        This method makes a synchronous HTTP request by default. To make an
        asynchronous HTTP request, please pass async_req=True
        >>> thread = api.replace_namespaced_resource_quota_status(name, namespace, body, async_req=True)
        >>> result = thread.get()

        :param async_req bool
        :param str name: name of the ResourceQuota (required)
        :param str namespace: object name and auth scope, such as for teams and projects (required)
        :param V1ResourceQuota body: (required)
        :param str pretty: If 'true', then the output is pretty printed.
        :param str dry_run: When present, indicates that modifications should not be persisted. An invalid or unrecognized dryRun directive will result in an error response and no further processing of the request. Valid values are: - All: all dry run stages will be processed
        :return: V1ResourceQuota
                 If the method is called asynchronously,
                 returns the request thread.
        """
        kwargs['_return_http_data_only'] = True
        if kwargs.get('async_req'):
            return self.replace_namespaced_resource_quota_status_with_http_info(name, namespace, body, **kwargs)  # noqa: E501
        else:
            (data) = self.replace_namespaced_resource_quota_status_with_http_info(name, namespace, body, **kwargs)  # noqa: E501
            return data
