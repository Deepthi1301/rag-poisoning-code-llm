def clean(image, mask=None, iterations = 1):
    '''Remove isolated pixels
    
    0 0 0     0 0 0
    0 1 0 ->  0 0 0
    0 0 0     0 0 0
    
    Border pixels and pixels adjoining masks are removed unless one valid
    neighbor is true.
    '''
    global clean_table
    if mask is None:
        masked_image = image
    else:
        masked_image = image.astype(bool).copy()
        masked_image[~mask] = False
    result = table_lookup(masked_image, clean_table, False, iterations)
    if not mask is None:
        result[~mask] = image[~mask]
    return result
