def _set_rstp(self, v, load=False):
    """
    Setter method for rstp, mapped from YANG variable /protocol/spanning_tree/rstp (container)
    If this variable is read-only (config: false) in the
    source YANG file, then _set_rstp is considered as a private
    method. Backends looking to populate this variable should
    do so via calling thisObj._set_rstp() directly.
    """
    if hasattr(v, "_utype"):
      v = v._utype(v)
    try:
      t = YANGDynClass(v,base=rstp.rstp, is_container='container', presence=True, yang_name="rstp", rest_name="rstp", parent=self, path_helper=self._path_helper, extmethods=self._extmethods, register_paths=True, extensions={u'tailf-common': {u'cli-full-command': None, u'cli-add-mode': None, u'callpoint': u'rstp-config', u'info': u'Rapid spanning tree', u'display-when': u'not ((/protocol/spanning-tree/stp) or (/protocol/spanning-tree/mstp) or (/protocol/spanning-tree/pvst) or (/protocol/spanning-tree/rpvst))'}}, namespace='urn:brocade.com:mgmt:brocade-xstp', defining_module='brocade-xstp', yang_type='container', is_config=True)
    except (TypeError, ValueError):
      raise ValueError({
          'error-string': """rstp must be of a type compatible with container""",
          'defined-type': "container",
          'generated-type': """YANGDynClass(base=rstp.rstp, is_container='container', presence=True, yang_name="rstp", rest_name="rstp", parent=self, path_helper=self._path_helper, extmethods=self._extmethods, register_paths=True, extensions={u'tailf-common': {u'cli-full-command': None, u'cli-add-mode': None, u'callpoint': u'rstp-config', u'info': u'Rapid spanning tree', u'display-when': u'not ((/protocol/spanning-tree/stp) or (/protocol/spanning-tree/mstp) or (/protocol/spanning-tree/pvst) or (/protocol/spanning-tree/rpvst))'}}, namespace='urn:brocade.com:mgmt:brocade-xstp', defining_module='brocade-xstp', yang_type='container', is_config=True)""",
        })

    self.__rstp = t
    if hasattr(self, '_set'):
      self._set()
