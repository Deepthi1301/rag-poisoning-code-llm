def load(filename):
        """Load a CameraIntrinsics object from a file.

        Parameters
        ----------
        filename : :obj:`str`
            The .intr file to load the object from.

        Returns
        -------
        :obj:`CameraIntrinsics`
            The CameraIntrinsics object loaded from the file.

        Raises
        ------
        ValueError
            If filename does not have the .intr extension.
        """
        file_root, file_ext = os.path.splitext(filename)
        if file_ext.lower() != INTR_EXTENSION:
            raise ValueError('Extension %s not supported for CameraIntrinsics. Must be stored with extension %s' %(file_ext, INTR_EXTENSION))

        f = open(filename, 'r')
        ci = json.load(f)
        f.close()
        return OrthographicIntrinsics(frame=ci['_frame'],
                                      vol_height=ci['_vol_height'],
                                      vol_width=ci['_vol_width'],
                                      vol_depth=ci['_vol_depth'],
                                      plane_height=ci['_plane_height'],
                                      plane_width=ci['_plane_width'],
                                      depth_scale=ci['_depth_scale'])
