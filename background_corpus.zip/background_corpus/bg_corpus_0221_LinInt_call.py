def call(self, x):
        """
        Evaluate the interpolant, assuming x is a scalar.
        """
    # if out of range, return endpoint
        if x <= self.x_vals[0]:
            return self.y_vals[0]
        if x >= self.x_vals[-1]:
            return self.y_vals[-1]

        pos = numpy.searchsorted(self.x_vals, x)

        h = self.x_vals[pos]-self.x_vals[pos-1]
        if h == 0.0:
            raise BadInput

        a = old_div((self.x_vals[pos] - x), h)
        b = old_div((x - self.x_vals[pos-1]), h)
        return a*self.y_vals[pos-1] + b*self.y_vals[pos]
