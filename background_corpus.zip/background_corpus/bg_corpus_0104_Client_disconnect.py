def disconnect(self):
        """
        Disconnect from IB connection.
        """
        self.connState = Client.DISCONNECTED
        if self.conn is not None:
            self._logger.info('Disconnecting')
            self.conn.disconnect()
            self.wrapper.connectionClosed()
            self.reset()
