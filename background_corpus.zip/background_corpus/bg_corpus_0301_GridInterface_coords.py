def coords(cls, dataset, dim, ordered=False, expanded=False, edges=False):
        """
        Returns the coordinates along a dimension.  Ordered ensures
        coordinates are in ascending order and expanded creates
        ND-array matching the dimensionality of the dataset.
        """
        dim = dataset.get_dimension(dim, strict=True)
        irregular = cls.irregular(dataset, dim)
        if irregular or expanded:
            if irregular:
                data = dataset.data[dim.name]
            else:
                data = util.expand_grid_coords(dataset, dim)
            if edges and data.shape == dataset.data[dataset.vdims[0].name].shape:
                data = cls._infer_interval_breaks(data, axis=1)
                data = cls._infer_interval_breaks(data, axis=0)
            return data

        data = dataset.data[dim.name]
        if ordered and np.all(data[1:] < data[:-1]):
            data = data[::-1]
        shape = cls.shape(dataset, True)
        if dim in dataset.kdims:
            idx = dataset.get_dimension_index(dim)
            isedges = (dim in dataset.kdims and len(shape) == dataset.ndims
                       and len(data) == (shape[dataset.ndims-idx-1]+1))
        else:
            isedges = False
        if edges and not isedges:
            data = cls._infer_interval_breaks(data)
        elif not edges and isedges:
            data = data[:-1] + np.diff(data)/2.
        return data
