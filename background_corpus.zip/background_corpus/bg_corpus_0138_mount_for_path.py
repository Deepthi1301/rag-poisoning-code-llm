def mount_for_path(path, client):
    """Returns the mountpoint for this path"""
    backend_data = client.list_secret_backends()['data']
    backends = [mnt for mnt in backend_data.keys()]
    path_bits = path.split('/')
    if len(path_bits) == 1:
        vault_path = "%s/" % path
        if vault_path in backends:
            return vault_path[0:len(vault_path) - 1]
    else:
        for i in range(1, len(path_bits) + 1):
            vault_path = "%s/" % '/'.join(path_bits[0:i])
            if vault_path in backends:
                return vault_path[0:len(vault_path) - 1]

    return None
