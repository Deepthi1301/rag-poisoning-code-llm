def main():
    """Main function"""
    # Configure the logger
    log = logging.getLogger('SIP.EC.PCI.DB')
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        '%(name)-20s | %(filename)-15s | %(levelname)-5s | %(message)s'))
    log.addHandler(handler)
    log.setLevel(os.getenv('SIP_PCI_LOG_LEVEL', 'INFO'))

    # Get the number of Scheduling Block Instances to generate
    num_blocks = int(sys.argv[1]) if len(sys.argv) == 2 else 3
    add_scheduling_blocks(num_blocks)
