def put(cont, path=None, local_file=None, profile=None):
    '''
    Create a new container, or upload an object to a container.

    CLI Example to create a container:

    .. code-block:: bash

        salt myminion swift.put mycontainer

    CLI Example to upload an object to a container:

    .. code-block:: bash

        salt myminion swift.put mycontainer remotepath local_file=/path/to/file
    '''
    swift_conn = _auth(profile)

    if path is None:
        return swift_conn.put_container(cont)
    elif local_file is not None:
        return swift_conn.put_object(cont, path, local_file)
    else:
        return False
