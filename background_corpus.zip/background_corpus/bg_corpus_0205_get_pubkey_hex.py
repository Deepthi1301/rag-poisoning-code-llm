def get_pubkey_hex( privatekey_hex ):
    """
    Get the uncompressed hex form of a private key
    """
    if not isinstance(privatekey_hex, (str, unicode)):
        raise ValueError("private key is not a hex string but {}".format(str(type(privatekey_hex))))

    # remove 'compressed' hint
    if len(privatekey_hex) > 64:
        if privatekey_hex[-2:] != '01':
            raise ValueError("private key does not end in 01")

        privatekey_hex = privatekey_hex[:64]

    # get hex public key
    privatekey_int = int(privatekey_hex, 16)
    privk = ec.derive_private_key(privatekey_int, ec.SECP256K1(), default_backend())
    pubk = privk.public_key()
    x = pubk.public_numbers().x
    y = pubk.public_numbers().y

    pubkey_hex = "04{:064x}{:064x}".format(x, y)
    return pubkey_hex
