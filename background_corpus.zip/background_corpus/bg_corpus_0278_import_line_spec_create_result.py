def create_result(self, imports, module_name, import_from, meta, val, dividers):
        """Default permissions to rw"""
        options = {"imports": imports, "module_name": module_name, "import_from": import_from}
        return ImportLine.FieldSpec(formatter=MergedOptionStringFormatter).normalise(meta, options)
