def print_results(args):
    """Print all comics that have at least the given number of minimum comic strips."""
    min_comics, filename = args
    min_comics = int(min_comics)
    with codecs.open(filename, 'a', 'utf-8') as fp:
        for name, entry in sorted(load_result(json_file).items()):
            if name in exclude_comics:
                continue
            path, num = entry
            if num >= min_comics:
                fp.write(u"add(%r, %r)\n" % (
                  str(truncate_name(name)), str(path)))
