def get_response_example(self, resp_spec):
        """Get a response example from a response spec.

        """
        if 'schema' in resp_spec.keys():
            if '$ref' in resp_spec['schema']:  # Standard definition
                definition_name = self.get_definition_name_from_ref(resp_spec['schema']['$ref'])
                return self.definitions_example[definition_name]
            elif 'items' in resp_spec['schema'] and resp_spec['schema']['type'] == 'array':  # Array
                if '$ref' in resp_spec['schema']['items']:
                    definition_name = self.get_definition_name_from_ref(resp_spec['schema']['items']['$ref'])
                else:
                    if 'type' in resp_spec['schema']['items']:
                        definition_name = self.get_definition_name_from_ref(resp_spec['schema']['items'])
                        return [definition_name]
                    else:
                        logging.warn("No item type in: " + resp_spec['schema'])
                        return ''
                return [self.definitions_example[definition_name]]
            elif 'type' in resp_spec['schema']:
                return self.get_example_from_prop_spec(resp_spec['schema'])
        else:
            return ''
