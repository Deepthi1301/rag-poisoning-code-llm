def _cmp_by_asn(local_asn, path1, path2):
    """Select the path based on source (iBGP/eBGP) peer.

    eBGP path is preferred over iBGP. If both paths are from same kind of
    peers, return None.
    """
    def get_path_source_asn(path):
        asn = None
        if path.source is None:
            asn = local_asn
        else:
            asn = path.source.remote_as
        return asn

    p1_asn = get_path_source_asn(path1)
    p2_asn = get_path_source_asn(path2)
    # If path1 is from ibgp peer and path2 is from ebgp peer.
    if (p1_asn == local_asn) and (p2_asn != local_asn):
        return path2

    # If path2 is from ibgp peer and path1 is from ebgp peer,
    if (p2_asn == local_asn) and (p1_asn != local_asn):
        return path1

    # If both paths are from ebgp or ibpg peers, we cannot decide.
    return None
