def set_axis_options_for_all(self, row_column_list=None, text=''):
        """Set point size limits of specified subplots.

        :param row_column_list: a list containing (row, column) tuples to
            specify the subplots, or None to indicate *all* subplots.
        :type row_column_list: list or None
        :param text: axis options for the given subplots or the overall plot.

        """
        if row_column_list is None:
            self.axis_options = text
        else:
            for row, column in row_column_list:
                self.set_axis_options(row, column, text)
