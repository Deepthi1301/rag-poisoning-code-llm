def update_assume_role_policy(role_name, policy_document, region=None,
                              key=None, keyid=None, profile=None):
    '''
    Update an assume role policy for a role.

    .. versionadded:: 2015.8.0

    CLI Example:

    .. code-block:: bash

        salt myminion boto_iam.update_assume_role_policy myrole '{"Statement":"..."}'
    '''
    conn = _get_conn(region=region, key=key, keyid=keyid, profile=profile)

    if isinstance(policy_document, six.string_types):
        policy_document = salt.utils.json.loads(policy_document,
                                     object_pairs_hook=odict.OrderedDict)
    try:
        _policy_document = salt.utils.json.dumps(policy_document)
        conn.update_assume_role_policy(role_name, _policy_document)
        log.info('Successfully updated assume role policy for IAM role %s.', role_name)
        return True
    except boto.exception.BotoServerError as e:
        log.error(e)
        log.error('Failed to update assume role policy for IAM role %s.', role_name)
        return False
