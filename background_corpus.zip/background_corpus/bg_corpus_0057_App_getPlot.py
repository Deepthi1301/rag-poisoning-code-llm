def getPlot(self, params):
        """Override this function

        arguments:
        params (dict)

        returns:
        matplotlib.pyplot figure
        """
        try:
            return eval("self." + str(params['output_id']) + "(params)")
        except AttributeError:
            df = self.getData(params)
            if df is None:
                return None
            return df.plot()
