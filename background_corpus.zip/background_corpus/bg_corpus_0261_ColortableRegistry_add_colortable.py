def add_colortable(self, fobj, name):
        r"""Add a color table from a file to the registry.

        Parameters
        ----------
        fobj : file-like object
            The file to read the color table from
        name : str
            The name under which the color table will be stored

        """
        self[name] = read_colortable(fobj)
        self[name + '_r'] = self[name][::-1]
