def offset(self, date, n_days):
        '''
        Return the date n_days after (or before if n_days < 0) <date>
        note: not calender days, but self days!
        '''
#CONSIDER: raise an exception if a date is not in self
        index = self.index(date) + n_days
        if index < 0:
            index = 0
        if index > len(self) - 1:
            index = len(self) - 1
        return self[index]
