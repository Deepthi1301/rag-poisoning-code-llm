def remove_connection(self, connection):
        """Called by the connections themselves when they have been closed."""
        if not self._closing:
            self.connections.remove(connection)
            logger.debug("removed connection")
