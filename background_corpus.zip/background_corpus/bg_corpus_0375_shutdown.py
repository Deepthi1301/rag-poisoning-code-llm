def shutdown(opts):
    '''
    For this proxy shutdown is a no-op
    '''
    log.debug('dummy proxy shutdown() called...')
    DETAILS = _load_state()
    if 'filename' in DETAILS:
        os.unlink(DETAILS['filename'])
