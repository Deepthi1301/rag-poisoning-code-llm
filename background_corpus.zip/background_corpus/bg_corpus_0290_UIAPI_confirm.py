def confirm(self, msg, _timeout=-1):
        ''' Send a confirm prompt to the GUI
        
        Arguments:
            msg (string):
                The message to display to the user.

            _timeout (int):
                The optional amount of time for which the prompt
                should be displayed to the user before a timeout occurs.
                Defaults to -1 which indicates there is no timeout limit.
        '''
        return self.msgBox('confirm', _timeout=_timeout, msg=msg)
