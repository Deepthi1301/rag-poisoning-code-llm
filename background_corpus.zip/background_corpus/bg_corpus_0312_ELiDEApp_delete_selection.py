def delete_selection(self):
        """Delete both the selected widget and whatever it represents."""
        selection = self.selection
        if selection is None:
            return
        if isinstance(selection, ArrowWidget):
            self.mainscreen.boardview.board.rm_arrow(
                selection.origin.name,
                selection.destination.name
            )
            selection.portal.delete()
        elif isinstance(selection, Spot):
            self.mainscreen.boardview.board.rm_spot(selection.name)
            selection.proxy.delete()
        else:
            assert isinstance(selection, Pawn)
            self.mainscreen.boardview.board.rm_pawn(selection.name)
            selection.proxy.delete()
        self.selection = None
