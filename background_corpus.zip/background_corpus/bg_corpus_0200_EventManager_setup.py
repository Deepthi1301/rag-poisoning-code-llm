def setup(self, builder):
        """Performs this components simulation setup.

        Parameters
        ----------
        builder : vivarium.framework.engine.Builder
            Object giving access to core framework functionality.
        """
        self.clock = builder.time.clock()
        self.step_size = builder.time.step_size()
