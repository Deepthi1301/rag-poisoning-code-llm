def z_rotate(rotationAmt):
        """Create a matrix that rotates around the z axis."""
        ma4 = Matrix4((math.cos(rotationAmt), -math.sin(rotationAmt), 0, 0),
                      (math.sin(rotationAmt), math.cos(rotationAmt), 0, 0),
                      (0, 0, 1, 0),
                      (0, 0, 0, 1))

        return ma4
