def fhp_from_json_dict(
        json_dict  # type: Dict[str, Any]
    ):
    # type: (...) -> FieldHashingProperties
    """
    Make a :class:`FieldHashingProperties` object from a dictionary.

        :param dict json_dict:
            The dictionary must have have an 'ngram' key
            and one of k or num_bits. It may have
            'positional' key; if missing a default is used.
            The encoding is
            always set to the default value.
        :return: A :class:`FieldHashingProperties` instance.
    """
    h = json_dict.get('hash', {'type': 'blakeHash'})
    num_bits = json_dict.get('numBits')
    k = json_dict.get('k')
    if not num_bits and not k:
        num_bits = 200 # default for v2 schema
    return FieldHashingProperties(
        ngram=json_dict['ngram'],
        positional=json_dict.get(
            'positional', FieldHashingProperties._DEFAULT_POSITIONAL),
        hash_type=h['type'],
        prevent_singularity=h.get('prevent_singularity'),
        num_bits=num_bits,
        k=k,
        missing_value=MissingValueSpec.from_json_dict(
            json_dict[
                'missingValue']) if 'missingValue' in json_dict else None
    )
