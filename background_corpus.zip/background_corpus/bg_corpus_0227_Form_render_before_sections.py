def render_before_sections(self):
        """Render the form up to the first section.  This will open the form tag but not close it."""
        return Markup(env.get_template('form.html').render(form=self,
                                                           render_open_tag=True,
                                                           render_close_tag=False,
                                                           render_before=True,
                                                           render_sections=False,
                                                           render_after=False,
                                                           generate_csrf_token=None if self.action else _csrf_generation_function))
