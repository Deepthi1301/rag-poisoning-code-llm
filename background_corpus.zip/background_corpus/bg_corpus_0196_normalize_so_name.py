def normalize_so_name(name):
    """
    Handle different types of python installations
    """
    if "cpython" in name:
        return os.path.splitext(os.path.splitext(name)[0])[0]
    # XXX: Special handling for Fedora python2 distribution
    # See: https://github.com/python-rope/rope/issues/211
    if name == "timemodule.so":
        return "time"
    return os.path.splitext(name)[0]
