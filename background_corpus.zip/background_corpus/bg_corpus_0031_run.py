def run(extension=None, name=None, description=None, salt_dir=None, merge=False, temp_dir=None):
    '''
    A template factory for extending the salt ecosystem

    :param extension: The extension type, e.g. 'module', 'state', if omitted, user will be prompted
    :type  extension: ``str``

    :param name: Python-friendly name for the module, if omitted, user will be prompted
    :type  name: ``str``

    :param description: A description of the extension, if omitted, user will be prompted
    :type  description: ``str``

    :param salt_dir: The targeted Salt source directory
    :type  salt_dir: ``str``

    :param merge: Merge with salt directory, `False` to keep separate, `True` to merge trees.
    :type  merge: ``bool``

    :param temp_dir: The directory for generated code, if omitted, system temp will be used
    :type  temp_dir: ``str``
    '''
    if not HAS_CLICK:
        print("click is not installed, please install using pip")
        sys.exit(1)

    if salt_dir is None:
        salt_dir = '.'

    MODULE_OPTIONS = _fetch_templates(os.path.join(salt_dir, 'templates'))

    if extension is None:
        print('Choose which type of extension you are developing for SaltStack')
        extension_type = 'Extension type'
        chosen_extension = _prompt_choice(extension_type, MODULE_OPTIONS)
    else:
        if extension not in list(zip(*MODULE_OPTIONS))[0]:
            print("Module extension option not valid")
            sys.exit(1)

        chosen_extension = [m for m in MODULE_OPTIONS if m[0] == extension][0]

    extension_type = chosen_extension[0]
    extension_context = chosen_extension[2]

    if name is None:
        print('Enter the short name for the module (e.g. mymodule)')
        name = _prompt_user_variable('Module name', '')

    if description is None:
        description = _prompt_user_variable('Short description of the module', '')

    template_dir = 'templates/{0}'.format(extension_type)
    module_name = name

    param_dict = {
        "version": salt.version.SaltStackVersion.next_release().name,
        "module_name": module_name,
        "short_description": description,
        "release_date": date.today().strftime('%Y-%m-%d'),
        "year": date.today().strftime('%Y'),
    }

    # get additional questions from template
    additional_context = {}
    for key, val in extension_context.get('questions', {}).items():
        # allow templates to be used in default values.
        default = Template(val.get('default', '')).render(param_dict)

        prompt_var = _prompt_user_variable(val['question'], default)
        additional_context[key] = prompt_var

    context = param_dict.copy()
    context.update(extension_context)
    context.update(additional_context)

    if temp_dir is None:
        temp_dir = tempfile.mkdtemp()

    apply_template(
        template_dir,
        temp_dir,
        context)

    if not merge:
        path = temp_dir
    else:
        _mergetree(temp_dir, salt_dir)
        path = salt_dir

    log.info('New module stored in %s', path)
    return path
