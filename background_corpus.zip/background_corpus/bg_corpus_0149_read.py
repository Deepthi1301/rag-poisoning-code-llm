def read(*components, **kwargs):
    """
    Read file and return a list of lines. If comment_char is set, ignore the
    contents of lines following the comment_char.

    Raises:

        IOError: if reading path fails
    """
    rstrip = kwargs.get("rstrip", True)
    comment_char = kwargs.get("comment_char", None)

    ignore_comments = comment_char is not None

    file = open(path(*components))
    lines = file.readlines()
    file.close()

    # Multiple definitions to handle all cases.
    if ignore_comments:
        comment_line_re = re.compile("^\s*{char}".format(char=comment_char))
        not_comment_re = re.compile("[^{char}]+".format(char=comment_char))

        if rstrip:
            # Ignore comments, and right strip results.
            return [re.match(not_comment_re, line).group(0).rstrip()
                    for line in lines
                    if not re.match(comment_line_re, line)]
        else:
            # Ignore comments, and don't strip results.
            return [re.match(not_comment_re, line).group(0)
                    for line in lines
                    if not re.match(comment_line_re, line)]
    elif rstrip:
        # No comments, and right strip results.
        return [line.rstrip() for line in lines]
    else:
        # Just a good old-fashioned read!
        return lines
