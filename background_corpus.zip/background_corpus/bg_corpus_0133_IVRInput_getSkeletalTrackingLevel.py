def getSkeletalTrackingLevel(self, action):
        """Reads the level of accuracy to which the controller is able to track the user to recreate a skeletal pose"""

        fn = self.function_table.getSkeletalTrackingLevel
        pSkeletalTrackingLevel = EVRSkeletalTrackingLevel()
        result = fn(action, byref(pSkeletalTrackingLevel))
        return result, pSkeletalTrackingLevel
