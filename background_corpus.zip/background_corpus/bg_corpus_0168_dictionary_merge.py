def dictionary_merge(a, b):
    """merges dictionary b into a
       Like dict.update, but recursive
    """
    for key, value in b.items():
        if key in a and isinstance(a[key], dict) and isinstance(value, dict):
            dictionary_merge(a[key], b[key])
            continue
        a[key] = b[key]
    return a
