def get(args):
    """
    Get a template by name.
    """
    m = TemplateManager(args.hosts)
    t = m.get(args.name)
    if t:
        print(json.dumps(t, indent=2))
    else:
        sys.exit(1)
