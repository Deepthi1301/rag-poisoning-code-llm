def gen_locale(locale, **kwargs):
    '''
    Generate a locale. Options:

    .. versionadded:: 2014.7.0

    :param locale: Any locale listed in /usr/share/i18n/locales or
        /usr/share/i18n/SUPPORTED for Debian and Gentoo based distributions,
        which require the charmap to be specified as part of the locale
        when generating it.

    verbose
        Show extra warnings about errors that are normally ignored.

    CLI Example:

    .. code-block:: bash

        salt '*' locale.gen_locale en_US.UTF-8
        salt '*' locale.gen_locale 'en_IE.UTF-8 UTF-8'    # Debian/Gentoo only
    '''
    on_debian = __grains__.get('os') == 'Debian'
    on_ubuntu = __grains__.get('os') == 'Ubuntu'
    on_gentoo = __grains__.get('os_family') == 'Gentoo'
    on_suse = __grains__.get('os_family') == 'Suse'
    on_solaris = __grains__.get('os_family') == 'Solaris'

    if on_solaris:  # all locales are pre-generated
        return locale in __salt__['locale.list_avail']()

    locale_info = salt.utils.locales.split_locale(locale)
    locale_search_str = '{0}_{1}'.format(locale_info['language'], locale_info['territory'])

    # if the charmap has not been supplied, normalize by appening it
    if not locale_info['charmap'] and not on_ubuntu:
        locale_info['charmap'] = locale_info['codeset']
        locale = salt.utils.locales.join_locale(locale_info)

    if on_debian or on_gentoo:  # file-based search
        search = '/usr/share/i18n/SUPPORTED'
        valid = __salt__['file.search'](search,
                                        '^{0}$'.format(locale),
                                        flags=re.MULTILINE)
    else:  # directory-based search
        if on_suse:
            search = '/usr/share/locale'
        else:
            search = '/usr/share/i18n/locales'

        try:
            valid = locale_search_str in os.listdir(search)
        except OSError as ex:
            log.error(ex)
            raise CommandExecutionError(
                "Locale \"{0}\" is not available.".format(locale))

    if not valid:
        log.error(
            'The provided locale "%s" is not found in %s', locale, search)
        return False

    if os.path.exists('/etc/locale.gen'):
        __salt__['file.replace'](
            '/etc/locale.gen',
            r'^\s*#\s*{0}\s*$'.format(locale),
            '{0}\n'.format(locale),
            append_if_not_found=True
        )
    elif on_ubuntu:
        __salt__['file.touch'](
            '/var/lib/locales/supported.d/{0}'.format(locale_info['language'])
        )
        __salt__['file.replace'](
            '/var/lib/locales/supported.d/{0}'.format(locale_info['language']),
            locale,
            locale,
            append_if_not_found=True
        )

    if salt.utils.path.which('locale-gen'):
        cmd = ['locale-gen']
        if on_gentoo:
            cmd.append('--generate')
        if on_ubuntu:
            cmd.append(salt.utils.locales.normalize_locale(locale))
        else:
            cmd.append(locale)
    elif salt.utils.path.which('localedef'):
        cmd = ['localedef', '--force', '-i', locale_search_str, '-f', locale_info['codeset'],
               '{0}.{1}'.format(locale_search_str,
                                locale_info['codeset']),
               kwargs.get('verbose', False) and '--verbose' or '--quiet']
    else:
        raise CommandExecutionError(
            'Command "locale-gen" or "localedef" was not found on this system.')

    res = __salt__['cmd.run_all'](cmd)
    if res['retcode']:
        log.error(res['stderr'])

    if kwargs.get('verbose'):
        return res
    else:
        return res['retcode'] == 0
