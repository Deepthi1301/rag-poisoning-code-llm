def validate_redis(self, db_data, user_data, oper):
        """Validate data in Redis.

        Args:
            db_data (str): The data store in Redis.
            user_data (str): The user provided data.
            oper (str): The comparison operator.

        Returns:
            bool: True if the data passed validation.
        """
        passed = True
        # convert any int to string since playbooks don't support int values
        if isinstance(db_data, int):
            db_data = str(db_data)
        if isinstance(user_data, int):
            user_data = str(user_data)

        # try to sort list of strings for simple comparisons
        # if list has a more complex data structure the sort will fail
        if isinstance(db_data, (list)):
            try:
                db_data = sorted(db_data)
            except TypeError:
                # self.log.debug('[validate] could not sort list')
                pass
        if isinstance(user_data, (list)):
            try:
                user_data = sorted(user_data)
            except TypeError:
                # self.log.debug('[validate] could not sort list')
                pass

        if oper not in self.operators:
            self.log.error('Invalid operator provided ({})'.format(oper))
            return False

        # compare the data
        if self.operators.get(oper)(db_data, user_data):
            self.reports.profile_validation(True)
        else:
            self.reports.profile_validation(False)
            passed = False

        # log validation data in a readable format
        self.validate_log_output(passed, db_data, user_data, oper)

        return passed
