def MI_associators(self,
                       env,
                       objectName,
                       assocClassName,
                       resultClassName,
                       role,
                       resultRole,
                       propertyList):
        # pylint: disable=invalid-name
        """Return instances associated to a given object.

        Implements the WBEM operation Associators in terms
        of the references method.  A derived class will not normally
        override this method.

        """

        # NOTE: This should honor the parameters resultClassName, role,
        #       resultRole, and propertyList
        logger = env.get_logger()
        logger.log_debug('CIMProvider MI_associators called. ' \
                         'assocClass: %s' % (assocClassName))
        ch = env.get_cimom_handle()
        if not assocClassName:
            raise pywbem.CIMError(
                pywbem.CIM_ERR_FAILED,
                "Empty assocClassName passed to Associators")
        assocClass = ch.GetClass(assocClassName, objectName.namespace,
                                 LocalOnly=False,
                                 IncludeQualifiers=True)
        plist = pywbem.NocaseDict()
        [plist.__setitem__(p.name, p) for p in assocClass.properties.values()
         if 'key' in p.qualifiers or p.type == 'reference']
        _strip_quals(plist)
        model = pywbem.CIMInstance(classname=assocClass.classname,
                                   properties=plist)
        model.path = pywbem.CIMInstanceName(classname=assocClass.classname,
                                            namespace=objectName.namespace)
        for inst in self.references(env=env,
                                    object_name=objectName,
                                    model=model,
                                    assoc_class=assocClass,
                                    result_class_name=resultClassName,
                                    role=role,
                                    result_role=None,
                                    keys_only=False):
            for prop in inst.properties.values():
                lpname = prop.name.lower()
                if prop.type != 'reference':
                    continue
                if role and role.lower() == lpname:
                    continue
                if resultRole and resultRole.lower() != lpname:
                    continue
                if _path_equals_ignore_host(prop.value, objectName):
                    continue
                if resultClassName and self.filter_results and \
                    not pywbem.is_subclass(ch, objectName.namespace,
                                           sub=prop.value.classname,
                                           super=resultClassName):
                    continue
                try:
                    if prop.value.namespace is None:
                        prop.value.namespace = objectName.namespace
                    inst = ch.GetInstance(prop.value,
                                          IncludeQualifiers=True,
                                          IncludeClassOrigin=True,
                                          PropertyList=propertyList)
                except pywbem.CIMError as exc:
                    num, msg = exc.args
                    if num == pywbem.CIM_ERR_NOT_FOUND:
                        continue
                    else:
                        raise
                if inst.path is None:
                    inst.path = prop.value
                yield inst
        logger.log_debug('CIMProvider MI_associators returning')
