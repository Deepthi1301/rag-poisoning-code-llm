def add_to(self, parent, name=None, index=None):
        """Add element to a parent."""
        parent.add_child(self, name=name, index=index)
        return self
