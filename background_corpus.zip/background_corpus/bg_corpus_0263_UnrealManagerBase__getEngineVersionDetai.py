def _getEngineVersionDetails(self):
		"""
		Parses the JSON version details for the latest installed version of UE4
		"""
		versionFile = os.path.join(self.getEngineRoot(), 'Engine', 'Build', 'Build.version')
		return json.loads(Utility.readFile(versionFile))
