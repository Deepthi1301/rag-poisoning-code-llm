def ljust(text, width, fillchar=' '):
    """Left-justify text to a total of `width`

    The `width` is based on graphemes::

        >>> s = 'Â'
        >>> s.ljust(2)
        'Â'
        >>> ljust(s, 2)
        'Â '
    """
    len_text = grapheme_len(text)
    return text + fillchar * (width - len_text)
