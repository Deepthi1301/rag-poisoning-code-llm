def request_token(self):
        """ Returns url, request_token, request_secret"""
        logging.debug("Getting request token from %s:%d",
                      self.server, self.port)
        token, secret = self._token("/oauth/requestToken")
        return "{}/oauth/authorize?oauth_token={}".format(self.host, token), \
            token, secret
