def cmd(send, _, args):
    """Pull changes.

    Syntax: {command} <branch>

    """
    try:
        if exists(join(args['handler'].confdir, '.git')):
            send(do_pull(srcdir=args['handler'].confdir))
        else:
            send(do_pull(repo=args['config']['api']['githubrepo']))
    except subprocess.CalledProcessError as ex:
        for line in ex.output.strip().splitlines():
            logging.error(line)
        raise ex
