def from_csv(input_csv_pattern, headers=None, schema_file=None):
    """Create a Metrics instance from csv file pattern.

    Args:
      input_csv_pattern: Path to Csv file pattern (with no header). Can be local or GCS path.
      headers: Csv headers.
      schema_file: Path to a JSON file containing BigQuery schema. Used if "headers" is None.

    Returns:
      a Metrics instance.

    Raises:
      ValueError if both headers and schema_file are None.
    """

    if headers is not None:
      names = headers
    elif schema_file is not None:
      with _util.open_local_or_gcs(schema_file, mode='r') as f:
        schema = json.load(f)
      names = [x['name'] for x in schema]
    else:
      raise ValueError('Either headers or schema_file is needed')

    metrics = Metrics(input_csv_pattern=input_csv_pattern, headers=names)
    return metrics
