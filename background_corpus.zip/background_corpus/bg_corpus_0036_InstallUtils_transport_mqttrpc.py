def transport_mqttrpc(self):
        """
        Installs the MQTT-RPC transport bundles and instantiates components
        """
        # Install the bundle
        self.context.install_bundle("pelix.remote.transport.mqtt_rpc").start()

        with use_waiting_list(self.context) as ipopo:
            # Instantiate the discovery
            ipopo.add(
                rs.FACTORY_TRANSPORT_MQTTRPC_EXPORTER,
                "pelix-mqttrpc-exporter",
                {
                    "mqtt.host": self.arguments.mqtt_host,
                    "mqtt.port": self.arguments.mqtt_port,
                },
            )
            ipopo.add(
                rs.FACTORY_TRANSPORT_MQTTRPC_IMPORTER,
                "pelix-mqttrpc-importer",
                {
                    "mqtt.host": self.arguments.mqtt_host,
                    "mqtt.port": self.arguments.mqtt_port,
                },
            )
