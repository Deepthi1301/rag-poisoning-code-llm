def hamsterday_time_to_datetime(hamsterday, time):
    """Return the civil datetime corresponding to a given hamster day and time.

    The hamster day start is taken into account.
    """

    # work around cyclic imports
    from hamster.lib.configuration import conf

    if time < conf.day_start:
        # early morning, between midnight and day_start
        # => the hamster day is the previous civil day
        civil_date = hamsterday + dt.timedelta(days=1)
    else:
        civil_date = hamsterday
    return dt.datetime.combine(civil_date, time)
