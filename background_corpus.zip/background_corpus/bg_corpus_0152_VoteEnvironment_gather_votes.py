def gather_votes(self, candidates):
        """Gather votes for the given candidates from the agents in the
        environment.

        Returned votes are anonymous, i.e. they cannot be tracked to any
        individual agent afterwards.

        :returns:
            A list of votes. Each vote is a list of ``(artifact, preference)``
            -tuples sorted in a preference order of a single agent.
        """
        votes = []
        for a in self.get_agents(addr=False):
            vote = a.vote(candidates)
            votes.append(vote)
        return votes
