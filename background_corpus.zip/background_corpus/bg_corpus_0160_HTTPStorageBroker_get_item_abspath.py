def get_item_abspath(self, identifier):
        """Return absolute path at which item content can be accessed.

        :param identifier: item identifier
        :returns: absolute path from which the item content can be accessed
        """

        dataset_cache_abspath = os.path.join(
            self._cache_abspath,
            self.uuid
        )
        mkdir_parents(dataset_cache_abspath)

        manifest = self.get_manifest()
        relpath = manifest['items'][identifier]['relpath']
        _, ext = os.path.splitext(relpath)

        local_item_abspath = os.path.join(
            dataset_cache_abspath,
            identifier + ext
        )

        if not os.path.isfile(local_item_abspath):

            url = self.http_manifest["item_urls"][identifier]

            r = self._get_request(url, stream=True)
            tmp_local_item_abspath = local_item_abspath + ".tmp"
            with open(tmp_local_item_abspath, 'wb') as f:
                shutil.copyfileobj(r.raw, f)
            os.rename(tmp_local_item_abspath, local_item_abspath)

        return local_item_abspath
