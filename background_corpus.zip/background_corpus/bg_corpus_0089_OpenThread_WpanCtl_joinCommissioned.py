def joinCommissioned(self, strPSKd='threadjpaketest', waitTime=20):
        """start joiner

        Args:
            strPSKd: Joiner's PSKd

        Returns:
            True: successful to start joiner
            False: fail to start joiner
        """
        print '%s call joinCommissioned' % self.port
        cmd = WPANCTL_CMD + 'joiner --start %s %s' %(strPSKd, self.provisioningUrl)
        print cmd
        if self.__sendCommand(cmd)[0] != "Fail":
            if self.__getJoinerState():
                self.__sendCommand(WPANCTL_CMD + 'joiner --attach')
                time.sleep(30)
                return True
            else:
                return False
        else:
            return False
