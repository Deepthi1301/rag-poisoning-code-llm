def get_next_sibling_tags(mention):
    """Return the HTML tag of the Mention's next siblings.

    Next siblings are Mentions which are at the same level in the HTML tree as
    the given mention, but are declared after the given mention.
    If a candidate is passed in, only the next siblings of its last Mention
    are considered in the calculation.

    :param mention: The Mention to evaluate
    :rtype: list of strings
    """
    span = _to_span(mention)
    next_sibling_tags = []
    i = _get_node(span.sentence)
    while i.getnext() is not None:
        next_sibling_tags.append(str(i.getnext().tag))
        i = i.getnext()
    return next_sibling_tags
