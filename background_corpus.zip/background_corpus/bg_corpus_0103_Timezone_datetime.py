def datetime(
        self, year, month, day, hour=0, minute=0, second=0, microsecond=0
    ):  # type: (int, int, int, int, int, int, int) -> datetime
        """
        Return a normalized datetime for the current timezone.
        """
        if _HAS_FOLD:
            return self.convert(
                datetime(year, month, day, hour, minute, second, microsecond, fold=1)
            )

        return self.convert(
            datetime(year, month, day, hour, minute, second, microsecond),
            dst_rule=POST_TRANSITION,
        )
