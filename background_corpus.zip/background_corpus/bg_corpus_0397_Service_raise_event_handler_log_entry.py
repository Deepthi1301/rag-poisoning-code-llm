def raise_event_handler_log_entry(self, command):
        """Raise SERVICE EVENT HANDLER entry (critical level)
        Format is : "SERVICE EVENT HANDLER: *host_name*;*self.get_name()*;*state*;*state_type*
                    ;*attempt*;*command.get_name()*"
        Example : "SERVICE EVENT HANDLER: server;Load;UP;HARD;1;notify-by-rss"

        :param command: Handler launched
        :type command: alignak.objects.command.Command
        :return: None
        """
        if not self.__class__.log_event_handlers:
            return

        log_level = 'info'
        if self.state == 'WARNING':
            log_level = 'warning'
        if self.state == 'CRITICAL':
            log_level = 'error'
        brok = make_monitoring_log(
            log_level, "SERVICE EVENT HANDLER: %s;%s;%s;%s;%s;%s" % (
                self.host_name, self.get_name(),
                self.state, self.state_type,
                self.attempt, command.get_name()
            )
        )
        self.broks.append(brok)
