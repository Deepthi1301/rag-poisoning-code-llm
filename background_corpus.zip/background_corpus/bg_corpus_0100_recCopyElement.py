def recCopyElement(oldelement):
    """Generates a copy of an xml element and recursively of all
    child elements.

    :param oldelement: an instance of lxml.etree._Element

    :returns: a copy of the "oldelement"

    .. warning::
        doesn't copy ``.text`` or ``.tail`` of xml elements
    """
    newelement = ETREE.Element(oldelement.tag, oldelement.attrib)
    if len(oldelement.getchildren()) > 0:
        for childelement in oldelement.getchildren():
            newelement.append(recCopyElement(childelement))
    return newelement
