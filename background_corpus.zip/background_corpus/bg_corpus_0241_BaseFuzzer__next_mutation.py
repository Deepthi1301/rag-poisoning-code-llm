def _next_mutation(self):
        '''
        :return: True if mutated, False otherwise
        '''
        if self._keep_running():
            current_idx = self.model.current_index()
            self.session_info.current_index = current_idx
            next_idx = self._test_list.current()
            if next_idx is None:
                return False
            skip = next_idx - current_idx - 1
            if skip > 0:
                self.model.skip(skip)
            self._test_list.next()
            resp = self.model.mutate()
            return resp
        return False
