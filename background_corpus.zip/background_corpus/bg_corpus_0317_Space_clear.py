def clear(self, obj):
        """Clear allowances/expectations set on an object.

        :param object obj: The object to clear.
        """
        self.proxy_for(obj).restore_original_object()
        del self._proxies[id(obj)]
