def read_user(self, username, mount_point=DEFAULT_MOUNT_POINT):
        """Read the properties of an existing username.

        Supported methods:
            GET: /auth/{mount_point}/users/{username}. Produces: 200 application/json

        :param username: Username for this user.
        :type username: str | unicode
        :param mount_point: The "path" the method/backend was mounted on.
        :type mount_point: str | unicode
        :return: The JSON response of the request.
        :rtype: dict
        """
        params = {
            'username': username,
        }
        api_path = '/v1/auth/{mount_point}/users/{username}'.format(
            mount_point=mount_point,
            username=username,
        )
        response = self._adapter.get(
            url=api_path,
            json=params,
        )
        return response.json()
