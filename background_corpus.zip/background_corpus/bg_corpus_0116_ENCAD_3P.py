def ENCAD_3P(residue):
    """
    Reduces complexity of protein residue to a 3 points coarse grained model:
    CA, O, Bead in specific atom location.
    
    Based on Michael Levitt's ENCAD coarse graining model (2010).
    """
    
    conversion_table = {
                        "LEU": ["CG"],
                        "ALA": ["CB"],  
                        "GLY": [],  
                        "VAL": ["CB"],
                        "GLU": ["CD"],
                        "ASP": ["CG"],
                        "THR": ["CB"],
                        "LYS": ["CD"],
                        "ILE": ["CG1"],
                        "ARG": ["NE"],
                        "ASN": ["CG"],
                        "PRO": ["CG"],
                        "PHE": ["CG"],
                        "GLN": ["CD"],
                        "SER": ["CB", "OG"],
                        "HIS": ["CG"],
                        "MET": ["CG"],
                        "TYR": ["CD1", "CD2"],
                        "TRP": ["CD2"],
                        "CYS": ["CB", "SG"],
                        }
    
    cg_residue = deepcopy(residue)
    sc_atoms = []
    
    residue_name = cg_residue.resname
    
    if residue_name not in conversion_table:
        raise ValueError("Residue %s not recognized" %residue_name)
        
    for atom in cg_residue.child_dict.keys():
        if cg_residue[atom].name in conversion_table[residue_name]:
            sc_atoms.append(cg_residue[atom])
            cg_residue.detach_child(cg_residue[atom].name)            
        elif not cg_residue[atom].name in ["CA", "O"]:
            cg_residue.detach_child(cg_residue[atom].name)    

    # Side chain bead
    if len(sc_atoms):
        dummy = sorted(sc_atoms)[-1]
        if len(sc_atoms) > 1: # Merge - C.o.M        
            bead_coord = center_of_mass(sc_atoms, geometric=True)
        else:
            bead_coord = dummy.coord
            
        sc_bead = Atom( 'CMA', 
                        bead_coord, 
                        dummy.bfactor,
                        dummy.occupancy,
                        dummy.altloc,
                        ' CMA',
                        dummy.serial_number,
                        dummy.element,
                        dummy.hetatm)

        cg_residue.add(sc_bead)
        
    return cg_residue
