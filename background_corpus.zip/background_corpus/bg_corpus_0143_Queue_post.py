def post(self, *messages):
        """Executes an HTTP request to create message on the queue.
        Creates queue if not existed.

        Arguments:
        messages -- An array of messages to be added to the queue.
        """
        url = "queues/%s/messages" % self.name

        msgs = [{'body': msg} if isinstance(msg, basestring) else msg
                for msg in messages]
        data = json.dumps({'messages': msgs})

        result = self.client.post(url=url, body=data,
                                  headers={'Content-Type': 'application/json'})

        return result['body']
