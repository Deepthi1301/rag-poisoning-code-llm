def set_status(self, id, status, timeout, update_time, history=None):
        """
        Set status and update history.
        """
        query = {'_id': {'$regex': '^' + id}}

        update = {
            '$set': {'status': status, 'timeout': timeout, 'updateTime': update_time},
            '$push': {
                'history': {
                    '$each': [history.serialize],
                    '$slice': -abs(current_app.config['HISTORY_LIMIT'])
                }
            }
        }
        return self.get_db().alerts.find_one_and_update(
            query,
            update=update,
            projection={'history': 0},
            return_document=ReturnDocument.AFTER
        )
