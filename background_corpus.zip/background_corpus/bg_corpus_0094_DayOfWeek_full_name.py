def full_name(self):
        """Get the name of the day of the week.

        Returns
        -------
        StringValue
            The name of the day of the week
        """
        import ibis.expr.operations as ops

        return ops.DayOfWeekName(self.op().arg).to_expr()
