def _checkIfClusterExists(self):
        """
        Try deleting the resource group. This will fail if it exists and raise an exception.
        """
        ansibleArgs = {
            'resgrp': self.clusterName,
            'region': self._zone
        }
        try:
            self.callPlaybook(self.playbook['check-cluster'], ansibleArgs, wait=True)
        except RuntimeError:
            logger.info("The cluster could not be created. Try deleting the cluster if it already exits.")
            raise
