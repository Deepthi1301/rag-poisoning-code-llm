def add_line_if_absent(filename: str, line: str) -> None:
    """
    Adds a line (at the end) if it's not already in the file somewhere.

    Args:
        filename: filename to modify (in place)
        line: line to append (which must not have a newline in)
    """
    assert "\n" not in line
    if not is_line_in_file(filename, line):
        log.info("Appending line {!r} to file {!r}", line, filename)
        with open(filename, "a") as file:
            file.writelines([line])
