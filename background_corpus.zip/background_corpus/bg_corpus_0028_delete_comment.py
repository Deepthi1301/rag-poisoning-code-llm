def delete_comment(repo: GithubRepository, comment_id: int) -> None:
    """
    References:
        https://developer.github.com/v3/issues/comments/#delete-a-comment
    """
    url = ("https://api.github.com/repos/{}/{}/issues/comments/{}"
           "?access_token={}".format(repo.organization,
                                     repo.name,
                                     comment_id,
                                     repo.access_token))
    response = requests.delete(url)
    if response.status_code != 204:
        raise RuntimeError(
            'Comment delete failed. Code: {}. Content: {}.'.format(
                response.status_code, response.content))
