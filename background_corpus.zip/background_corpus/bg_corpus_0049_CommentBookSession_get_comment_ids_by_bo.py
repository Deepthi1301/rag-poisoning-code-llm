def get_comment_ids_by_book(self, book_id):
        """Gets the list of Comment Ids associated with a ``Book``.

        arg:    book_id (osid.id.Id): ``Id`` of a ``Book``.
        return: (osid.id.IdList) - list of related comment ``Ids``
        raise:  NotFound - ``book_id`` is not found
        raise:  NullArgument - ``book_id`` is ``null``
        raise:  OperationFailed - unable to complete request
        raise:  PermissionDenied - authorization failure
        *compliance: mandatory -- This method must be implemented.*

        """
        # Implemented from template for
        # osid.resource.ResourceBinSession.get_resource_ids_by_bin
        id_list = []
        for comment in self.get_comments_by_book(book_id):
            id_list.append(comment.get_id())
        return IdList(id_list)
