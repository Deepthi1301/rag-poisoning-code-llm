def can_finalise(self, step, exhausted, status):
        """
        The step is running and the inputs are exhausted
        :param step:
        :param exhausted:
        :return:
        """
        return step in status and step in exhausted and status[step] == 'running' and all(in_ in exhausted[step] for in_ in step.ins)
