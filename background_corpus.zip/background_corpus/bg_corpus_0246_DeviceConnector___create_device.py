def __create_device(self):
        """
        creates device, internal use only
        """
        # retrieve netengine dictionary from memory or from network
        device_dict = getattr(self, 'netengine_dict', self.netengine.to_dict())
        device = Device()
        device.node_id = self.node_id
        device.name = device_dict['name']
        device.type = device_dict['type']
        device.status = DEVICE_STATUS.get('reachable')
        device.os = device_dict['os']
        device.os_version = device_dict['os_version']
        # this is the first time the device is seen by the system because we are just adding it
        device.first_seen = now()
        # and is also the latest
        device.last_seen = now()
        device.full_clean()
        device.save()

        # add routing protocols
        for routing_protocol in device_dict['routing_protocols']:
            # retrieve routing protocol from DB
            try:
                rp = RoutingProtocol.objects.filter(
                    name__iexact=routing_protocol['name'],
                    version__iexact=routing_protocol['version']
                )[0]
            # create if doesn't exist yet
            except IndexError:
                rp = RoutingProtocol(
                    name=routing_protocol['name'],
                    version=routing_protocol['version']
                )
                rp.full_clean()
                rp.save()
            # add to device
            device.routing_protocols.add(rp)

        for interface in device_dict['interfaces']:
            interface_object = False
            vap_object = False
            # create interface depending on type
            if interface['type'] == 'ethernet':
                interface_object = Ethernet(**{
                    'device': device,
                    'name': interface['name'],
                    'mac': interface['mac_address'],
                    'mtu': interface['mtu'],
                    'standard': interface['standard'],
                    'duplex': interface['duplex'],
                    'tx_rate': interface['tx_rate'],
                    'rx_rate': interface['rx_rate']
                })
            elif interface['type'] == 'wireless':
                interface_object = Wireless(**{
                    'device': device,
                    'name': interface['name'],
                    'mac': interface['mac_address'],
                    'mtu': interface['mtu'],
                    'mode': interface['mode'],
                    'standard': interface['standard'],
                    'channel': interface['channel'],
                    'channel_width': interface['channel_width'],
                    'output_power': interface['output_power'],
                    'dbm': interface['dbm'],
                    'noise': interface['noise'],
                    'tx_rate': interface['tx_rate'],
                    'rx_rate': interface['rx_rate']
                })

                for vap in interface['vap']:
                    vap_object = Vap(
                        essid=vap['essid'],
                        bssid=vap['bssid'],
                        encryption=vap['encryption']
                    )

            if interface_object:
                interface_object.full_clean()
                interface_object.save()

                if vap_object:
                    vap_object.interface = interface_object
                    vap_object.full_clean()
                    vap_object.save()

                for ip in interface['ip']:
                    ip_object = Ip(**{
                        'interface': interface_object,
                        'address': ip['address'],
                    })
                    ip_object.full_clean()
                    ip_object.save()

        if HARDWARE_INSTALLED:
            # try getting device model from db
            try:
                device_model = DeviceModel.objects.filter(name__iexact=device_dict['model'])[0]
            # if it does not exist create it
            except IndexError as e:
                # try getting manufacturer from DB
                try:
                    manufacturer = Manufacturer.objects.filter(name__iexact=device_dict['manufacturer'])[0]
                # or create
                except IndexError as e:
                    manufacturer = Manufacturer(name=device_dict['manufacturer'])
                    manufacturer.full_clean()
                    manufacturer.save()

                device_model = DeviceModel(
                    manufacturer=manufacturer,
                    name=device_dict['model']
                )
                device_model.ram = device_dict['RAM_total']

            device_model.full_clean()
            device_model.save()

            # create relation between device model and device
            rel = DeviceToModelRel(device=device, model=device_model)
            rel.full_clean()
            rel.save()

        return device
