def process(self, response):
        """ Returns HTTP backend agnostic ``Response`` data. """

        try:
            code = response.status_code

            # 204 - No Content
            if code == 204:
                body = None
            # add an error message to 402 errors
            elif code == 402:
                body = {
                    "message": "Payment Required",
                    "status": "error"
                }
            else:
                body = response.json()

            return Response(code, body, response.content, response)
        except ValueError:
            raise ZencoderResponseError(response, response.content)
