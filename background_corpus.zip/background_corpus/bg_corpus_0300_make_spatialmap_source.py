def make_spatialmap_source(name, Spatial_Filename, spectrum):
    """Construct and return a `fermipy.roi_model.Source` object
    """
    data = dict(Spatial_Filename=Spatial_Filename, 
                ra=0.0, dec=0.0,
                SpatialType='SpatialMap',
                Source_Name=name)
    if spectrum is not None:
        data.update(spectrum)

    return roi_model.Source(name, data)
