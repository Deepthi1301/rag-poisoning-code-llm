def get_instances(self):
        """Create, init and then returns the list of module instances that the caller needs.

        This method is called once the Python modules are loaded to initialize the modules.

        If an instance can't be created or initialized then only log is doneand that
        instance is skipped. The previous modules instance(s), if any, are all cleaned.

        :return: module instances list
        :rtype: list
        """
        self.clear_instances()

        for (alignak_module, python_module) in self.modules_assoc:
            alignak_module.properties = python_module.properties.copy()
            alignak_module.my_daemon = self.daemon
            logger.info("Alignak starting module '%s'", alignak_module.get_name())
            if getattr(alignak_module, 'modules', None):
                modules = []
                for module_uuid in alignak_module.modules:
                    if module_uuid in self.modules:
                        modules.append(self.modules[module_uuid])
                alignak_module.modules = modules
            logger.debug("Module '%s', parameters: %s",
                         alignak_module.get_name(), alignak_module.__dict__)
            try:
                instance = python_module.get_instance(alignak_module)
                if not isinstance(instance, BaseModule):  # pragma: no cover, simple protection
                    self.configuration_errors.append("Module %s instance is not a "
                                                     "BaseModule instance: %s"
                                                     % (alignak_module.get_name(),
                                                        type(instance)))
                    raise AttributeError
            # pragma: no cover, simple protection
            except Exception as exp:  # pylint: disable=broad-except
                logger.error("The module %s raised an exception on loading, I remove it!",
                             alignak_module.get_name())
                logger.exception("Exception: %s", exp)
                self.configuration_errors.append("The module %s raised an exception on "
                                                 "loading: %s, I remove it!"
                                                 % (alignak_module.get_name(), str(exp)))
            else:
                # Give the module the data to which daemon/module it is loaded into
                instance.set_loaded_into(self.daemon.name)
                self.instances.append(instance)

        for instance in self.instances:
            # External instances are not initialized now, but only when they are started
            if not instance.is_external and not self.try_instance_init(instance):
                # If the init failed, we put in in the restart queue
                logger.warning("The module '%s' failed to initialize, "
                               "I will try to restart it later", instance.name)
                self.set_to_restart(instance)

        return self.instances
