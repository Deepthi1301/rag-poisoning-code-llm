def get_by_signature(user_id, app_id):
        '''
        get by user ID, and app ID.
        '''
        try:
            return TabEvaluation.get(
                (TabEvaluation.user_id == user_id) & (TabEvaluation.post_id == app_id)
            )
        except:
            return None
