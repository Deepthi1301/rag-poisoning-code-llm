def _wait_for_tasks(tasks, service_instance):
    '''
    Wait for tasks created via the VSAN API
    '''
    log.trace('Waiting for vsan tasks: {0}',
              ', '.join([six.text_type(t) for t in tasks]))
    try:
        vsanapiutils.WaitForTasks(tasks, service_instance)
    except vim.fault.NoPermission as exc:
        log.exception(exc)
        raise VMwareApiError('Not enough permissions. Required privilege: '
                             '{0}'.format(exc.privilegeId))
    except vim.fault.VimFault as exc:
        log.exception(exc)
        raise VMwareApiError(exc.msg)
    except vmodl.RuntimeFault as exc:
        log.exception(exc)
        raise VMwareRuntimeError(exc.msg)
    log.trace('Tasks %s finished successfully',
              ', '.join([six.text_type(t) for t in tasks]))
