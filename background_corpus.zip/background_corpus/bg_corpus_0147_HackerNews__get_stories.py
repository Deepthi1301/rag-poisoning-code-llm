def _get_stories(self, page, limit):
        """
        Hacker News has different categories (i.e. stories) like
        'topstories', 'newstories', 'askstories', 'showstories', 'jobstories'.
        This method, first fetches the relevant story ids of that category

        The URL is: https://hacker-news.firebaseio.com/v0/<story_name>.json

        e.g. https://hacker-news.firebaseio.com/v0/topstories.json

        Then, asynchronously it fetches each story and returns the Item objects

        The URL for individual story is:
            https://hacker-news.firebaseio.com/v0/item/<item_id>.json

        e.g. https://hacker-news.firebaseio.com/v0/item/69696969.json

        """
        url = urljoin(self.base_url, F"{page}.json")
        story_ids = self._get_sync(url)[:limit]
        return self.get_items_by_ids(item_ids=story_ids)
