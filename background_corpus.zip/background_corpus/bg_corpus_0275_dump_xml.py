def dump_xml(props, fp, comment=None, encoding='UTF-8', sort_keys=False):
    """
    Write a series ``props`` of key-value pairs to a binary filehandle ``fp``
    in the format of an XML properties file.  The file will include both an XML
    declaration and a doctype declaration.

    :param props: A mapping or iterable of ``(key, value)`` pairs to write to
        ``fp``.  All keys and values in ``props`` must be text strings.  If
        ``sort_keys`` is `False`, the entries are output in iteration order.
    :param fp: a file-like object to write the values of ``props`` to
    :type fp: binary file-like object
    :param comment: if non-`None`, ``comment`` will be output as a
        ``<comment>`` element before the ``<entry>`` elements
    :type comment: text string or `None`
    :param string encoding: the name of the encoding to use for the XML
        document (also included in the XML declaration)
    :param bool sort_keys: if true, the elements of ``props`` are sorted
        lexicographically by key in the output
    :return: `None`
    """
    fp = codecs.lookup(encoding).streamwriter(fp, errors='xmlcharrefreplace')
    print('<?xml version="1.0" encoding={0} standalone="no"?>'
          .format(quoteattr(encoding)), file=fp)
    for s in _stream_xml(props, comment, sort_keys):
        print(s, file=fp)
