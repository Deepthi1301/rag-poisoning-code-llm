def get_jwt_dict(jwt_bu64):
    """Parse Base64 encoded JWT and return as a dict.

    - JWTs contain a set of values serialized to a JSON dict. This decodes the JWT and
      returns it as a dict containing Unicode strings.
    - In addition, a SHA1 hash is added to the dict for convenience.

    Args:
      jwt_bu64: bytes
        JWT, encoded using a a URL safe flavor of Base64.

    Returns:
      dict: Values embedded in and derived from the JWT.

    """
    jwt_tup = get_jwt_tup(jwt_bu64)
    try:
        jwt_dict = json.loads(jwt_tup[0].decode('utf-8'))
        jwt_dict.update(json.loads(jwt_tup[1].decode('utf-8')))
        jwt_dict['_sig_sha1'] = hashlib.sha1(jwt_tup[2]).hexdigest()
    except TypeError as e:
        raise JwtException('Decode failed. error="{}"'.format(e))
    return jwt_dict
