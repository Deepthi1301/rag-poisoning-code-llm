def flush_stream_threads(process, out_formatter=None,
                                  err_formatter=terminal.fg.red, size=1):
    """
    Context manager that creates 2 threads, one for each standard
    stream (stdout/stderr), updating in realtime the piped data.
    The formatters are callables that receives manipulates the data,
    e.g. coloring it before writing to a ``sys`` stream. See
    ``FlushStreamThread`` for more information.
    """
    out = FlushStreamThread(process=process, stream_name="stdout",
                            formatter=out_formatter, size=size)
    err = FlushStreamThread(process=process, stream_name="stderr",
                            formatter=err_formatter, size=size)
    out.start()
    err.start()
    yield out, err
    out.join()
    err.join()
