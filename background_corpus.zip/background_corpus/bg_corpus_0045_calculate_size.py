def calculate_size(name, from_, to):
    """ Calculates the request payload size"""
    data_size = 0
    data_size += calculate_size_str(name)
    data_size += INT_SIZE_IN_BYTES
    data_size += INT_SIZE_IN_BYTES
    return data_size
