def clientConnectionFailed(self, err, address: Address):
        """
        Called when we fail to connect to an endpoint
        Args:
            err: Twisted Failure instance
            address: the address we failed to connect to
        """
        if type(err.value) == error.TimeoutError:
            logger.debug(f"Failed connecting to {address} connection timed out")
        elif type(err.value) == error.ConnectError:
            ce = err.value
            if len(ce.args) > 0:
                logger.debug(f"Failed connecting to {address} {ce.args[0].value}")
            else:
                logger.debug(f"Failed connecting to {address}")
        else:
            logger.debug(f"Failed connecting to {address} {err.value}")
        self.peers_connecting -= 1
        self.RemoveKnownAddress(address)
        self.RemoveFromQueue(address)
        # if we failed to connect to new addresses, we should always add them to the DEAD_ADDRS list
        self.AddDeadAddress(address)

        # for testing
        return err.type
