def do_rm(self, subcmd, opts, message):
        """${cmd_name}: remove the specified message

        ${cmd_usage}
        """
        maildir = self.maildir
        client = MdClient(maildir, filesystem=self.filesystem)
        try:
            client.remove(message)
        except KeyError:
            return 1
