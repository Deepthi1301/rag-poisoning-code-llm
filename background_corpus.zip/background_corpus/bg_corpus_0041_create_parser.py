def create_parser():
    """
    construct the program options
    """
    parser = argparse.ArgumentParser(
        prog=constants.PROGRAM_NAME, description=constants.PROGRAM_DESCRIPTION
    )
    parser.add_argument(
        "-cd",
        "--%s" % constants.LABEL_CONFIG_DIR,
        help="the directory for configuration file lookup",
    )
    parser.add_argument(
        "-c", "--%s" % constants.LABEL_CONFIG, help="the dictionary file"
    )
    parser.add_argument(
        "-td",
        "--%s" % constants.LABEL_TMPL_DIRS,
        nargs="*",
        help="the directories for template file lookup",
    )
    parser.add_argument(
        "-t", "--%s" % constants.LABEL_TEMPLATE, help="the template file"
    )
    parser.add_argument(
        "-o", "--%s" % constants.LABEL_OUTPUT, help="the output file"
    )
    parser.add_argument(
        "--%s" % constants.LABEL_TEMPLATE_TYPE,
        help="the template type, default is jinja2",
    )
    parser.add_argument(
        "-f",
        action="store_true",
        dest=constants.LABEL_FORCE,
        default=False,
        help="force moban to template all files despite of .moban.hashes",
    )
    parser.add_argument(
        "--%s" % constants.LABEL_EXIT_CODE,
        action="store_true",
        dest=constants.LABEL_EXIT_CODE,
        default=False,
        help="tell moban to change exit code",
    )
    parser.add_argument(
        "-m", "--%s" % constants.LABEL_MOBANFILE, help="custom moban file"
    )
    parser.add_argument(
        "-g", "--%s" % constants.LABEL_GROUP, help="a subset of targets"
    )
    parser.add_argument(
        constants.POSITIONAL_LABEL_TEMPLATE,
        metavar="template",
        type=str,
        nargs="?",
        help="string templates",
    )
    parser.add_argument(
        "-v",
        "--%s" % constants.LABEL_VERSION,
        action="version",
        version="%(prog)s {v}".format(v=__version__),
    )
    return parser
