def select(self, nowait=True, cb=None):
        '''
        Set this channel to use publisher confirmations.
        '''
        nowait = nowait and self.allow_nowait() and not cb

        if not self._enabled:
            self._enabled = True
            self.channel.basic._msg_id = 0
            self.channel.basic._last_ack_id = 0
            args = Writer()
            args.write_bit(nowait)

            self.send_frame(MethodFrame(self.channel_id, 85, 10, args))

            if not nowait:
                self._select_cb.append(cb)
                self.channel.add_synchronous_cb(self._recv_select_ok)
