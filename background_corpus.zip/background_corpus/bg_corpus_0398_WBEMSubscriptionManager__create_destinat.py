def _create_destination(self, server_id, dest_url, owned):
        """
        Create a listener destination instance in the Interop namespace of a
        WBEM server and return that instance.

        In order to catch any changes the server applies, the instance is
        retrieved again using the instance path returned by instance creation.

        Parameters:

          server_id (:term:`string`):
            The server ID of the WBEM server, returned by
            :meth:`~pywbem.WBEMSubscriptionManager.add_server`.

          dest_url (:term:`string`):
            URL of the listener that is used by the WBEM server to send any
            indications to.

            The URL scheme (e.g. http/https) determines whether the WBEM server
            uses HTTP or HTTPS for sending the indication. Host and port in the
            URL specify the target location to be used by the WBEM server.

          owned (:class:`py:bool`):
            Defines whether or not the created instance is *owned* by the
            subscription manager.

        Returns:

            :class:`~pywbem.CIMInstance`: The created instance, as retrieved
            from the server.

        Raises:

            Exceptions raised by :class:`~pywbem.WBEMConnection`.
        """

        # Validate server_id
        server = self._get_server(server_id)

        # validate the URL by reconstructing it. Do not allow defaults
        host, port, ssl = parse_url(dest_url, allow_defaults=False)
        schema = 'https' if ssl else 'http'
        listener_url = '{0}://{1}:{2}'.format(schema, host, port)

        this_host = getfqdn()
        ownership = "owned" if owned else "permanent"

        dest_path = CIMInstanceName(DESTINATION_CLASSNAME,
                                    namespace=server.interop_ns)

        dest_inst = CIMInstance(DESTINATION_CLASSNAME)
        dest_inst.path = dest_path
        dest_inst['CreationClassName'] = DESTINATION_CLASSNAME
        dest_inst['SystemCreationClassName'] = SYSTEM_CREATION_CLASSNAME
        dest_inst['SystemName'] = this_host
        dest_inst['Name'] = _format(
            'pywbemdestination:{0}:{1}:{2}',
            ownership, self._subscription_manager_id, uuid.uuid4())
        dest_inst['Destination'] = listener_url

        if owned:
            for i, inst in enumerate(self._owned_destinations[server_id]):
                if inst.path == dest_path:
                    # It already exists, now check its properties
                    if inst != dest_inst:
                        server.conn.ModifyInstance(dest_inst)
                        dest_inst = server.conn.GetInstance(dest_path)
                        self._owned_destinations[server_id][i] = dest_inst
                    return dest_inst
            dest_path = server.conn.CreateInstance(dest_inst)
            dest_inst = server.conn.GetInstance(dest_path)
            self._owned_destinations[server_id].append(dest_inst)
        else:
            # Responsibility to ensure it does not exist yet is with the user
            dest_path = server.conn.CreateInstance(dest_inst)
            dest_inst = server.conn.GetInstance(dest_path)

        return dest_inst
