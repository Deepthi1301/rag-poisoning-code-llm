def command(self, command):
        """
        Run a command on the currently active container.

        :rtype: CommandReply
        """
        return self._conn.command('[con_id="{}"] {}'.format(self.id, command))
