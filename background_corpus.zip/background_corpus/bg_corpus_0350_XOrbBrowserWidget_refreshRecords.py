def refreshRecords( self ):
        """
        Refreshes the records being loaded by this browser.
        """
        table_type = self.tableType()
        if ( not table_type ):
            self._records = RecordSet()
            return False
        
        search = nativestring(self.uiSearchTXT.text())
        
        query = self.query().copy()
        terms, search_query = Q.fromSearch(search)
        
        if ( search_query ):
            query &= search_query
        
        self._records = table_type.select(where = query).search(terms)
        return True
