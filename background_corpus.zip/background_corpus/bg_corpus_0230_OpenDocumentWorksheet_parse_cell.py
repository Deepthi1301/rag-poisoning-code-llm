def parse_cell(self, cell, coords, cell_mode=CellMode.cooked):
    """Parses a cell according to its cell.value_type."""
    # pylint: disable=too-many-return-statements
    if cell_mode == CellMode.cooked:
      if cell.covered or cell.value_type is None or cell.value is None:
        return None

      vtype = cell.value_type

      if vtype == 'string':
        return cell.value

      if vtype == 'float' or vtype == 'percentage' or vtype == 'currency':
        return cell.value

      if vtype == 'boolean':
        return cell.value

      if vtype == 'date':
        date_tuple = tuple([int(i) if i is not None else 0 \
                            for i in _DATE_REGEX.match(cell.value).groups()])
        return self.tuple_to_datetime(date_tuple)

      if vtype == 'time':
        hour, minute, second = _TIME_REGEX.match(cell.value).groups()
        # TODO: This kills off the microseconds
        date_tuple = (0, 0, 0, int(hour), int(minute), round(float(second)))
        return self.tuple_to_datetime(date_tuple)

      raise ValueError("Unhandled cell type: {0}".format(vtype))
    else:
      return cell
