def flatten(list_of_lists):
    """Flatten a list of lists but maintain strings and ints as entries."""
    flat_list = []
    for sublist in list_of_lists:
        if isinstance(sublist, string_types) or isinstance(sublist, int):
            flat_list.append(sublist)
        elif sublist is None:
            continue
        elif not isinstance(sublist, string_types) and len(sublist) == 1:
            flat_list.append(sublist[0])
        else:
            flat_list.append(tuple(sublist))
    return flat_list
