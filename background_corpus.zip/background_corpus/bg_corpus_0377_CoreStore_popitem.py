def popitem(self):
        """D.popitem() -> (k, v)
        
        Remove and return some (key, value) pair
        as a 2-tuple; but raise KeyError if D is empty.
        """
        try:
            value = next(iter(self))
            key = value[self._keycol]
        except StopIteration:
            raise KeyError
        del self[key]
        return key, value
